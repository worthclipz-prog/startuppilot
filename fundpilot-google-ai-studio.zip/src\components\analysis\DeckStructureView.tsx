import React from 'react';
import { 
  RecommendedSlide, 
  ImprovementStep, 
  MissingSlideInfo, 
  RedFlag 
} from '../../types/index';
import { 
  CheckCircle2, 
  AlertOctagon, 
  AlertTriangle, 
  Layers, 
  ListOrdered, 
  ShieldAlert,
  ArrowRight
} from 'lucide-react';

interface DeckStructureViewProps {
  idealDeck: RecommendedSlide[];
  improvementPlan: ImprovementStep[];
  missingSlides: MissingSlideInfo[];
  redFlags: RedFlag[];
}

export const DeckStructureView: React.FC<DeckStructureViewProps> = ({
  idealDeck,
  improvementPlan,
  missingSlides,
  redFlags
}) => {
  return (
    <div className="space-y-8">
      {/* 1. Missing Slides (Section 10) */}
      <div className="bg-white rounded-xl border border-zinc-200 p-6 space-y-4 shadow-2xs">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <AlertOctagon className="w-5 h-5 text-rose-600" />
            <h3 className="text-base font-bold text-zinc-900 tracking-tight">
              Missing From Your Deck
            </h3>
          </div>
          <span className="text-xs font-mono text-zinc-500">
            {missingSlides.length} items flagged
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
          {missingSlides.map((missing, idx) => {
            const isCritical = missing.category === 'critical';
            const isImportant = missing.category === 'important';
            return (
              <div
                key={idx}
                className={`p-3.5 rounded-lg border ${
                  isCritical
                    ? 'bg-rose-50/50 border-rose-200 text-rose-950'
                    : isImportant
                    ? 'bg-amber-50/50 border-amber-200 text-amber-950'
                    : 'bg-zinc-50 border-zinc-200 text-zinc-900'
                }`}
              >
                <div className="flex items-center justify-between gap-2 mb-1">
                  <span className="font-semibold text-sm">
                    {missing.title}
                  </span>
                  <span
                    className={`text-[10px] font-mono uppercase font-bold px-1.5 py-0.5 rounded ${
                      isCritical
                        ? 'bg-rose-200 text-rose-900'
                        : isImportant
                        ? 'bg-amber-200 text-amber-900'
                        : 'bg-zinc-200 text-zinc-800'
                    }`}
                  >
                    {missing.category}
                  </span>
                </div>
                <p className="text-zinc-600 leading-relaxed">
                  {missing.explanation}
                </p>
              </div>
            );
          })}
        </div>
      </div>

      {/* 2. VC Red Flags (Section 11) */}
      <div className="bg-white rounded-xl border border-zinc-200 p-6 space-y-4 shadow-2xs">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-amber-600" />
            <h3 className="text-base font-bold text-zinc-900 tracking-tight">
              VC Red Flags
            </h3>
          </div>
          <span className="text-xs font-mono text-zinc-500">
            Partner Diligence Filters
          </span>
        </div>

        <div className="space-y-3">
          {redFlags.map((flag, idx) => {
            const isHigh = flag.risk === 'high';
            return (
              <div
                key={idx}
                className="p-4 rounded-lg border border-zinc-200 bg-zinc-50 flex flex-col md:flex-row md:items-start justify-between gap-3 text-xs"
              >
                <div className="space-y-1 max-w-2xl">
                  <div className="flex items-center gap-2">
                    <span
                      className={`text-[10px] font-mono uppercase font-bold px-2 py-0.5 rounded ${
                        isHigh
                          ? 'bg-rose-100 text-rose-800 border border-rose-200'
                          : 'bg-amber-100 text-amber-800 border border-amber-200'
                      }`}
                    >
                      {flag.risk === 'high' ? 'High Risk' : 'Medium Risk'}
                    </span>
                    <h4 className="font-semibold text-zinc-900 text-sm">
                      {flag.title}
                    </h4>
                  </div>
                  <p className="text-zinc-600 leading-relaxed">
                    {flag.description}
                  </p>
                </div>

                <div className="p-2.5 rounded bg-white border border-zinc-200 shrink-0 md:w-64">
                  <span className="text-[10px] uppercase font-mono text-zinc-400 block mb-0.5">
                    VC Impact
                  </span>
                  <p className="text-zinc-800 font-medium">
                    {flag.impact}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 3. Deck Improvement Plan (Section 12) */}
      <div className="bg-white rounded-xl border border-zinc-200 p-6 space-y-4 shadow-2xs">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ListOrdered className="w-5 h-5 text-zinc-800" />
            <h3 className="text-base font-bold text-zinc-900 tracking-tight">
              Improve Your Deck — Ordered Action Plan
            </h3>
          </div>
          <span className="text-xs font-mono text-zinc-500">
            Priority Ranked
          </span>
        </div>

        <div className="space-y-2.5">
          {improvementPlan.map((step) => (
            <div
              key={step.step}
              className="p-3.5 rounded-lg border border-zinc-200 bg-white flex items-start gap-3 text-xs hover:border-zinc-300 transition-all"
            >
              <div className="w-6 h-6 rounded-full bg-zinc-900 text-white font-mono font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                {step.step}
              </div>

              <div className="flex-1 space-y-1">
                <div className="flex items-center justify-between">
                  <h4 className="font-semibold text-zinc-900 text-sm">
                    {step.action}
                  </h4>
                  <span
                    className={`text-[10px] font-mono px-2 py-0.5 rounded font-semibold ${
                      step.priority === 'High'
                        ? 'bg-rose-100 text-rose-800'
                        : 'bg-zinc-100 text-zinc-700'
                    }`}
                  >
                    {step.priority} Priority
                  </span>
                </div>
                <p className="text-zinc-600">
                  {step.rationale}
                </p>
                {step.targetSlide && (
                  <span className="inline-block text-[11px] font-mono text-zinc-500 pt-0.5">
                    Target Slide: #{step.targetSlide}
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 4. Ideal Deck Structure (Section 13) */}
      <div className="bg-white rounded-xl border border-zinc-200 p-6 space-y-4 shadow-2xs">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Layers className="w-5 h-5 text-zinc-800" />
            <div>
              <h3 className="text-base font-bold text-zinc-900 tracking-tight">
                Recommended Pitch Deck Structure
              </h3>
              <p className="text-xs text-zinc-500">
                Tailored slide order and narrative pacing for early-stage venture rounds.
              </p>
            </div>
          </div>
          <span className="text-xs font-mono px-2 py-1 rounded bg-zinc-100 text-zinc-700">
            {idealDeck.length} Slides
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
          {idealDeck.map((slide) => (
            <div
              key={slide.slideNumber}
              className="p-3.5 rounded-lg border border-zinc-200 bg-zinc-50/50 space-y-2 hover:bg-white hover:border-zinc-300 transition-all"
            >
              <div className="flex items-center justify-between">
                <span className="font-mono font-bold text-zinc-900 text-sm">
                  {slide.title}
                </span>
                <span className="text-[10px] font-mono text-zinc-400">
                  Slide {slide.slideNumber.toString().padStart(2, '0')}
                </span>
              </div>

              <p className="text-zinc-600 font-medium">
                {slide.purpose}
              </p>

              <div className="flex flex-wrap gap-1.5 pt-1">
                {slide.keyElements.map((el, i) => (
                  <span
                    key={i}
                    className="text-[10px] px-2 py-0.5 rounded bg-white border border-zinc-200 text-zinc-700 font-mono"
                  >
                    {el}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
