import React from 'react';
import { CategoryScores } from '../../types/index';

interface CategoryScoreGridProps {
  scores: CategoryScores;
}

interface CategoryDef {
  key: keyof CategoryScores;
  label: string;
  weight: string;
}

const CATEGORIES: CategoryDef[] = [
  { key: 'problem', label: 'Problem', weight: 'Core' },
  { key: 'solution', label: 'Solution', weight: 'Core' },
  { key: 'product', label: 'Product', weight: 'High' },
  { key: 'market', label: 'Market (TAM)', weight: 'Core' },
  { key: 'traction', label: 'Traction', weight: 'Critical' },
  { key: 'businessModel', label: 'Business Model', weight: 'High' },
  { key: 'gtm', label: 'Go-To-Market', weight: 'High' },
  { key: 'competition', label: 'Competition', weight: 'Medium' },
  { key: 'defensibility', label: 'Defensibility', weight: 'High' },
  { key: 'team', label: 'Team', weight: 'Critical' },
  { key: 'storytelling', label: 'Storytelling', weight: 'Medium' },
  { key: 'designClarity', label: 'Design & Clarity', weight: 'Medium' },
  { key: 'fundingAsk', label: 'Funding Ask', weight: 'High' },
];

export const CategoryScoreGrid: React.FC<CategoryScoreGridProps> = ({ scores }) => {
  const getScoreColor = (val: number) => {
    if (val >= 85) return 'text-emerald-700 bg-emerald-50 border-emerald-200';
    if (val >= 70) return 'text-zinc-800 bg-zinc-50 border-zinc-200';
    if (val >= 50) return 'text-amber-800 bg-amber-50 border-amber-200';
    return 'text-rose-800 bg-rose-50 border-rose-200';
  };

  const getBarColor = (val: number) => {
    if (val >= 85) return 'bg-emerald-500';
    if (val >= 70) return 'bg-zinc-800';
    if (val >= 50) return 'bg-amber-500';
    return 'bg-rose-500';
  };

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-7 gap-2.5">
      {CATEGORIES.map((cat) => {
        const val = scores[cat.key] || 70;
        return (
          <div
            key={cat.key}
            className={`p-3 rounded-lg border flex flex-col justify-between transition-all ${getScoreColor(val)}`}
          >
            <div className="flex items-center justify-between gap-1 mb-1">
              <span className="text-xs font-semibold tracking-tight truncate text-zinc-900">
                {cat.label}
              </span>
              <span className="text-[9px] font-mono uppercase tracking-wider text-zinc-400">
                {cat.weight}
              </span>
            </div>

            <div className="flex items-baseline justify-between mt-1">
              <span className="text-base font-bold font-mono tracking-tight text-zinc-900">
                {val}
              </span>
              <span className="text-[10px] text-zinc-400 font-mono">/100</span>
            </div>

            {/* Micro Progress Bar */}
            <div className="w-full bg-zinc-200/70 h-1 rounded-full overflow-hidden mt-1.5">
              <div
                className={`h-full rounded-full ${getBarColor(val)}`}
                style={{ width: `${Math.min(val, 100)}%` }}
              />
            </div>
          </div>
        );
      })}
    </div>
  );
};
