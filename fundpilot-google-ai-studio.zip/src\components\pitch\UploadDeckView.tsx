import React, { useState, useRef, useEffect } from 'react';
import { 
  FileUp, 
  FileText, 
  Sparkles, 
  AlertCircle, 
  CheckCircle2, 
  Loader2,
  RefreshCw,
  Edit3
} from 'lucide-react';
import { SAMPLE_DECKS } from '../../lib/pitch/sampleDecks';

interface UploadDeckViewProps {
  onFileUpload?: (file: File) => Promise<void> | void;
  onUpload?: (file: File) => Promise<void> | void;
  onAnalyzeRawText?: (slideTexts: string[], fileName: string) => Promise<void> | void;
  onLoadSample?: (sampleId: string) => Promise<void> | void;
  onSelectSample?: (sampleId: string) => Promise<void> | void;
  isLoading?: boolean;
  isAnalyzing?: boolean;
  currentStepIndex?: number;
  progress?: number;
  statusText?: string;
  error?: string | null;
  onClearError?: () => void;
}

const ANALYSIS_STEPS = [
  'Uploading deck file...',
  'Extracting slide texts & structures...',
  'Inferring startup profile & metrics...',
  'Running VC readiness & slide-by-slide scoring...',
  'Generating investor match recommendations...'
];

export const UploadDeckView: React.FC<UploadDeckViewProps> = ({
  onFileUpload,
  onUpload,
  onAnalyzeRawText,
  onLoadSample,
  onSelectSample,
  isLoading = false,
  isAnalyzing = false,
  currentStepIndex = 0,
  progress = 0,
  statusText,
  error = null,
  onClearError
}) => {
  const isBusy = Boolean(isLoading || isAnalyzing);
  const [isDragOver, setIsDragOver] = useState(false);
  const [showPasteMode, setShowPasteMode] = useState(false);
  const [pastedContent, setPastedContent] = useState('');
  const [deckNameInput, setDeckNameInput] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Global window drop safety to prevent browser navigating away on stray drops
  useEffect(() => {
    const handleWindowDragOver = (e: DragEvent) => {
      e.preventDefault();
    };
    const handleWindowDrop = (e: DragEvent) => {
      e.preventDefault();
    };
    window.addEventListener('dragover', handleWindowDragOver);
    window.addEventListener('drop', handleWindowDrop);
    return () => {
      window.removeEventListener('dragover', handleWindowDragOver);
      window.removeEventListener('drop', handleWindowDrop);
    };
  }, []);

  const clearErr = () => {
    if (onClearError) onClearError();
  };

  const handleUploadFn = async (file: File) => {
    if (onUpload) {
      await onUpload(file);
    } else if (onFileUpload) {
      await onFileUpload(file);
    }
  };

  const handleSampleFn = async (sampleId: string) => {
    if (onSelectSample) {
      await onSelectSample(sampleId);
    } else if (onLoadSample) {
      await onLoadSample(sampleId);
    }
  };

  const handleDragEnter = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(true);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.dataTransfer) {
      e.dataTransfer.dropEffect = 'copy';
    }
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    // Only turn off drag state if leaving the outer dropzone
    if (e.currentTarget.contains(e.relatedTarget as Node)) {
      return;
    }
    setIsDragOver(false);
  };

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(false);
    clearErr();

    const files = e.dataTransfer?.files;
    if (files && files.length > 0) {
      await handleUploadFn(files[0]);
    }
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      const file = files[0];
      e.target.value = ''; // Reset so uploading same file name again triggers onChange
      clearErr();
      await handleUploadFn(file);
    }
  };

  const handlePastedSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!pastedContent.trim()) return;
    
    // Split by slide breaks or empty lines
    const slides = pastedContent
      .split(/(?:---|\n{3,}|Slide \d+:)/i)
      .map(s => s.trim())
      .filter(s => s.length > 10);

    const validSlides = slides.length > 0 ? slides : [pastedContent];
    if (onAnalyzeRawText) {
      await onAnalyzeRawText(validSlides, deckNameInput.trim() || 'custom-deck.pdf');
    }
  };

  return (
    <div className="max-w-3xl mx-auto py-10 px-6 space-y-8">
      {/* Title */}
      <div className="text-center space-y-2">
        <h2 className="text-2xl font-bold tracking-tight text-zinc-900">
          Upload Pitch Deck
        </h2>
        <p className="text-sm text-zinc-500 max-w-md mx-auto">
          Upload your PDF or PPTX deck to extract startup metrics and receive a Tier-1 VC critique.
        </p>
      </div>

      {/* Error state */}
      {error && (
        <div className="p-4 rounded-lg bg-rose-50 border border-rose-200 text-rose-800 flex items-start gap-3">
          <AlertCircle className="w-5 h-5 shrink-0 mt-0.5 text-rose-600" />
          <div className="space-y-1 text-xs flex-1">
            <p className="font-semibold text-rose-900">We couldn't finish the analysis.</p>
            <p className="text-rose-700">{error}</p>
            <div className="pt-2 flex items-center gap-3">
              <button
                type="button"
                onClick={clearErr}
                className="inline-flex items-center gap-1 font-semibold text-rose-900 hover:underline cursor-pointer"
              >
                <RefreshCw className="w-3 h-3" />
                <span>Retry Upload</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Container */}
      {!isBusy ? (
        <div className="space-y-6">
          {!showPasteMode ? (
            /* Upload Drag & Drop Zone */
            <div
              id="pitch-deck-dropzone"
              onDragEnter={handleDragEnter}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`p-10 border-2 border-dashed rounded-xl text-center cursor-pointer transition-all flex flex-col items-center justify-center space-y-4 select-none ${
                isDragOver
                  ? 'border-zinc-900 bg-zinc-100/80 scale-[0.99] ring-4 ring-zinc-900/10'
                  : 'border-zinc-300 bg-white hover:border-zinc-500 hover:bg-zinc-50/70 shadow-2xs'
              }`}
            >
              <input
                ref={fileInputRef}
                type="file"
                accept=".pdf,.pptx,.txt,.md"
                onChange={handleFileSelect}
                onClick={(e) => e.stopPropagation()}
                className="hidden"
                id="file-upload-input"
              />

              <div className="w-12 h-12 rounded-full bg-zinc-100 flex items-center justify-center text-zinc-800">
                <FileUp className={`w-6 h-6 ${isDragOver ? 'animate-bounce text-zinc-950' : 'text-zinc-700'}`} />
              </div>

              <div className="space-y-1">
                <p className="text-base font-semibold text-zinc-900">
                  {isDragOver ? 'Drop file here to analyze' : 'Drop your pitch deck here'}
                </p>
                <p className="text-xs text-zinc-500">
                  or <span className="text-zinc-900 font-semibold underline">Choose a file</span> from your computer
                </p>
              </div>

              <div className="flex items-center gap-2 pt-2">
                <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-zinc-100 text-zinc-600 border border-zinc-200">
                  PDF
                </span>
                <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-zinc-100 text-zinc-600 border border-zinc-200">
                  PPTX
                </span>
                <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-zinc-100 text-zinc-600 border border-zinc-200">
                  TXT / MD · 4 MB max
                </span>
              </div>
            </div>
          ) : (
            /* Manual Slide Paste Mode */
            <form onSubmit={handlePastedSubmit} className="space-y-4 p-6 bg-white rounded-xl border border-zinc-200">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-zinc-700">Company or Deck Name</label>
                <input
                  type="text"
                  placeholder="e.g. ApexAI Series Seed Deck"
                  value={deckNameInput}
                  onChange={(e) => setDeckNameInput(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-md border border-zinc-300 focus:outline-hidden focus:border-zinc-900"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-zinc-700">Paste Slide Texts or Presentation Script</label>
                <textarea
                  rows={8}
                  placeholder="Paste your slide contents here. Separate slides with --- or Slide 1, Slide 2 headers..."
                  value={pastedContent}
                  onChange={(e) => setPastedContent(e.target.value)}
                  className="w-full p-3 text-xs font-mono rounded-md border border-zinc-300 focus:outline-hidden focus:border-zinc-900"
                  required
                />
              </div>

              <div className="flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowPasteMode(false)}
                  className="px-3 py-1.5 rounded-md text-xs text-zinc-600 hover:bg-zinc-100 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-md bg-zinc-900 text-white text-xs font-semibold hover:bg-zinc-800 cursor-pointer"
                >
                  Analyze Text
                </button>
              </div>
            </form>
          )}

          {/* Toggle Paste vs Upload & Sample Decks */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-2 text-xs text-zinc-500">
            <button
              type="button"
              onClick={() => setShowPasteMode(!showPasteMode)}
              className="inline-flex items-center gap-1.5 text-zinc-700 hover:text-zinc-900 font-medium cursor-pointer"
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>{showPasteMode ? 'Switch to File Upload' : 'Paste Deck Text Manually'}</span>
            </button>

            <div className="flex items-center gap-2">
              <span>Or test sample:</span>
              {SAMPLE_DECKS.map((sample) => (
                <button
                  key={sample.id}
                  type="button"
                  onClick={() => handleSampleFn(sample.id)}
                  className="px-2 py-1 rounded border border-zinc-200 bg-zinc-50 hover:bg-zinc-100 text-zinc-800 font-mono text-[11px] cursor-pointer"
                >
                  {sample.name.split('—')[0].trim()}
                </button>
              ))}
            </div>
          </div>
        </div>
      ) : (
        /* Real Progress Loading State */
        <div className="p-10 rounded-xl bg-white border border-zinc-200 text-center space-y-6 shadow-xs">
          <div className="w-12 h-12 rounded-full bg-zinc-100 flex items-center justify-center mx-auto text-zinc-900">
            <Loader2 className="w-6 h-6 animate-spin text-zinc-900" />
          </div>

          <div className="space-y-1">
            <h3 className="text-base font-semibold text-zinc-900">
              Analyzing Pitch Deck
            </h3>
            <p className="text-xs text-zinc-500 font-mono">
              {statusText || 'Running early-stage venture capital diligence protocol...'}
            </p>
          </div>

          {/* Step Sequence */}
          <div className="max-w-sm mx-auto text-left space-y-2.5 pt-2">
            {ANALYSIS_STEPS.map((step, idx) => {
              const isDone = idx < (currentStepIndex || Math.floor((progress / 100) * ANALYSIS_STEPS.length));
              const isCurrent = idx === (currentStepIndex || Math.floor((progress / 100) * ANALYSIS_STEPS.length));
              return (
                <div key={step} className="flex items-center gap-3 text-xs">
                  {isDone ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  ) : isCurrent ? (
                    <div className="w-4 h-4 rounded-full border-2 border-zinc-900 border-t-transparent animate-spin shrink-0" />
                  ) : (
                    <div className="w-4 h-4 rounded-full border border-zinc-300 shrink-0" />
                  )}
                  <span
                    className={`font-medium ${
                      isDone
                        ? 'text-zinc-900'
                        : isCurrent
                        ? 'text-zinc-900 font-semibold'
                        : 'text-zinc-400'
                    }`}
                  >
                    {step}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
