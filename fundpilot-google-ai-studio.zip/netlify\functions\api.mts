import path from 'node:path';
import {
  analyzePitchDeck,
  generateDeckScore,
  generateOutreachMessage
} from '../../src/lib/ai/minimax';
import { matchInvestors } from '../../src/lib/investors/matching';
import { VC_DATABASE } from '../../src/lib/investors/database';
import { SAMPLE_DECKS } from '../../src/lib/pitch/sampleDecks';
import type { Investor, SlideAnalysis, StartupProfile } from '../../src/types/index';
import { parsePDFBuffer, parsePPTXBuffer } from '../../server/parser';

const MAX_UPLOAD_BYTES = 4 * 1024 * 1024;

interface NetlifyFunctionConfig {
  path: string;
  method: Array<'GET' | 'POST'>;
}

class HttpError extends Error {
  constructor(public readonly status: number, message: string) {
    super(message);
  }
}

function json(data: unknown, status = 200): Response {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      'cache-control': 'no-store',
      'content-type': 'application/json; charset=utf-8'
    }
  });
}

async function bodyAs<T>(request: Request): Promise<T> {
  try {
    return await request.json() as T;
  } catch {
    throw new HttpError(400, 'Request body must be valid JSON.');
  }
}

function validateSlides(slides: unknown): string[] {
  if (!Array.isArray(slides) || slides.length === 0 || !slides.every(slide => typeof slide === 'string')) {
    throw new HttpError(400, 'Slide texts array required.');
  }
  if (slides.length > 100 || slides.some(slide => slide.length > 50_000)) {
    throw new HttpError(413, 'Deck text is too large (maximum 100 slides and 50,000 characters per slide).');
  }

  const normalized = slides.map(slide => slide.trim()).filter(Boolean);
  if (normalized.length === 0) {
    throw new HttpError(400, 'At least one slide must contain text.');
  }
  return normalized;
}

async function parseDeckUpload(request: Request): Promise<{ fileName: string; slides: string[] }> {
  const form = await request.formData();
  const upload = form.get('deck');
  if (!(upload instanceof File)) {
    throw new HttpError(400, 'No pitch deck file provided.');
  }
  if (upload.size > MAX_UPLOAD_BYTES) {
    throw new HttpError(413, 'The uploaded file exceeds Netlify\'s effective 4 MB binary upload limit.');
  }

  const fileName = path.basename(upload.name || 'pitch-deck.pdf').slice(0, 255);
  const extension = path.extname(fileName).toLowerCase();
  const buffer = Buffer.from(await upload.arrayBuffer());
  let slides: string[];

  if (extension === '.pdf') {
    slides = (await parsePDFBuffer(buffer)).map(slide => slide.text);
  } else if (extension === '.pptx') {
    slides = (await parsePPTXBuffer(buffer)).map(slide => slide.text);
  } else if (extension === '.txt' || extension === '.md') {
    const text = buffer.toString('utf8');
    slides = text.split(/\n{3,}|---/).map(value => value.trim()).filter(value => value.length > 10);
    if (slides.length === 0 && text.trim()) slides = [text.trim()];
  } else {
    throw new HttpError(415, 'Unsupported file type. Upload a PDF, PPTX, TXT, or Markdown file.');
  }

  if (slides.length === 0) {
    throw new HttpError(
      422,
      'No readable slide text was found. If the deck is image-only, export it with selectable text or upload a PPTX.'
    );
  }
  return { fileName, slides };
}

async function route(request: Request): Promise<Response> {
  const { pathname } = new URL(request.url);

  if (request.method === 'GET' && pathname === '/api/config') {
    return json({
      status: 'ok',
      aiEngine: 'NVIDIA NIM',
      configured: Boolean(
        process.env.NVIDIA_API_KEY?.trim() || process.env.NVIDIA_FALLBACK_API_KEY?.trim()
      ),
      models: [
        process.env.NVIDIA_PRIMARY_MODEL || 'minimaxai/minimax-m3',
        process.env.NVIDIA_FALLBACK_MODEL || 'meta/llama-3.1-8b-instruct'
      ],
      runtime: 'Netlify Functions'
    });
  }

  if (request.method === 'POST' && pathname === '/api/deck/upload') {
    const { fileName, slides } = await parseDeckUpload(request);
    return json(await analyzePitchDeck(slides, fileName));
  }

  const sampleMatch = pathname.match(/^\/api\/deck\/sample\/([^/]+)$/);
  if ((request.method === 'GET' || request.method === 'POST') && sampleMatch) {
    const sample = SAMPLE_DECKS.find(item => item.id === decodeURIComponent(sampleMatch[1]));
    if (!sample) throw new HttpError(404, 'Sample deck not found.');
    const slides = sample.slides.map(slide => `${slide.title}\n${slide.text}`);
    return json(await analyzePitchDeck(slides, `${sample.id}-deck.pdf`));
  }

  if (request.method === 'POST' && pathname === '/api/deck/analyze-text') {
    const body = await bodyAs<{ slides?: unknown; fileName?: unknown }>(request);
    const slides = validateSlides(body.slides);
    const fileName = typeof body.fileName === 'string' && body.fileName.trim()
      ? path.basename(body.fileName.trim()).slice(0, 255)
      : 'custom-deck.txt';
    return json(await analyzePitchDeck(slides, fileName));
  }

  if (request.method === 'POST' && pathname === '/api/deck/recalculate') {
    const body = await bodyAs<{ startupProfile?: StartupProfile; slides?: SlideAnalysis[] }>(request);
    if (!body.startupProfile || !Array.isArray(body.slides)) {
      throw new HttpError(400, 'startupProfile and slides required.');
    }
    return json({ pitchScore: await generateDeckScore(body.startupProfile, body.slides) });
  }

  if (request.method === 'GET' && pathname === '/api/investors') {
    return json({ database: VC_DATABASE });
  }

  if (request.method === 'POST' && pathname === '/api/investors/match') {
    const body = await bodyAs<{ startupProfile?: StartupProfile; criteria?: Parameters<typeof matchInvestors>[1] }>(request);
    if (!body.startupProfile) throw new HttpError(400, 'startupProfile required for investor matching.');
    const investors = matchInvestors(body.startupProfile, body.criteria);
    return json({ investors, total: investors.length });
  }

  if (request.method === 'POST' && pathname === '/api/investors/outreach') {
    const body = await bodyAs<{
      investor?: Investor;
      startupProfile?: StartupProfile;
      format?: 'coldEmail' | 'linkedIn' | 'warmIntro';
    }>(request);
    if (!body.investor || !body.startupProfile || !body.format) {
      throw new HttpError(400, 'Missing investor, startupProfile, or format parameter.');
    }
    const message = await generateOutreachMessage(body.investor, body.startupProfile, body.format);
    return json({ format: body.format, message });
  }

  throw new HttpError(404, 'API route not found.');
}

export default async (request: Request): Promise<Response> => {
  try {
    return await route(request);
  } catch (error) {
    if (error instanceof HttpError) return json({ error: error.message }, error.status);
    console.error('[FundPilot] Netlify function error:', error);
    return json({ error: 'The request could not be completed. Please retry.' }, 500);
  }
};

export const config: NetlifyFunctionConfig = {
  path: '/api/*',
  method: ['GET', 'POST']
};
