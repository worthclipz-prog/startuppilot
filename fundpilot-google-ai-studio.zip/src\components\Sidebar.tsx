import React from 'react';
import { NavigationTab } from '../types/index';
import { 
  BarChart3, 
  Search, 
  Bookmark, 
  Settings, 
  FileText,
  Compass,
  UploadCloud,
  Layers
} from 'lucide-react';

interface SidebarProps {
  activeTab?: NavigationTab;
  currentTab?: NavigationTab;
  onNavigate?: (tab: NavigationTab) => void;
  onSelectTab?: (tab: NavigationTab) => void;
  hasReport?: boolean;
  hasAnalyzedDeck?: boolean;
  savedCount?: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  currentTab,
  onNavigate,
  onSelectTab,
  hasReport,
  hasAnalyzedDeck,
  savedCount = 0
}) => {
  const current = activeTab || currentTab || 'landing';
  const handleNav = (tabId: NavigationTab) => {
    if (onNavigate) {
      onNavigate(tabId);
    } else if (onSelectTab) {
      onSelectTab(tabId);
    }
  };

  const hasDeck = Boolean(hasReport || hasAnalyzedDeck);

  const navItems: Array<{
    id: NavigationTab;
    label: string;
    icon: typeof Compass;
    badge?: string;
    count?: number;
  }> = [
    { id: 'landing', label: 'Overview', icon: Compass },
    { id: 'upload', label: 'Upload Deck', icon: UploadCloud },
    { 
      id: 'analysis', 
      label: 'Deck Analysis', 
      icon: BarChart3,
      badge: hasDeck ? 'Ready' : undefined
    },
    { id: 'investors', label: 'Find Investors', icon: Search },
    { 
      id: 'saved', 
      label: 'Saved Pipeline', 
      icon: Bookmark,
      count: savedCount > 0 ? savedCount : undefined
    }
  ];

  return (
    <aside 
      id="main-sidebar"
      className="w-60 bg-zinc-900 border-r border-zinc-800 flex flex-col justify-between min-h-[calc(100vh-3.5rem)] sticky top-14 shrink-0 select-none z-10"
    >
      <div>
        {/* Brand Header inside sidebar */}
        <div className="p-4 border-b border-zinc-800 flex items-center justify-between">
          <div 
            onClick={() => handleNav('landing')} 
            className="flex items-center gap-2.5 cursor-pointer"
          >
            <div className="w-7 h-7 rounded-md bg-zinc-100 flex items-center justify-center text-zinc-950 font-bold text-xs tracking-tight shadow-sm">
              FP
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-zinc-100 text-sm tracking-tight">FundPilot</span>
                <span className="text-[9px] uppercase font-mono px-1 py-0.2 rounded bg-zinc-800 text-zinc-300 font-medium">
                  AI
                </span>
              </div>
              <p className="text-[10px] text-zinc-400 font-normal">Fundraising Copilot</p>
            </div>
          </div>
        </div>

        {/* Navigation List */}
        <nav className="p-3 space-y-1">
          <div className="px-3 py-1.5 text-[10px] font-mono font-medium text-zinc-500 uppercase tracking-wider">
            Workspace
          </div>
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = current === item.id || (item.id === 'analysis' && current === 'profile');
            return (
              <button
                key={item.id}
                id={`nav-item-${item.id}`}
                onClick={() => handleNav(item.id)}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-md text-xs font-medium transition-colors ${
                  isActive
                    ? 'bg-zinc-800 text-zinc-50 font-semibold shadow-xs'
                    : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/60'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Icon className={`w-4 h-4 ${isActive ? 'text-zinc-100' : 'text-zinc-400'}`} />
                  <span>{item.label}</span>
                </div>
                {item.badge && (
                  <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800/50">
                    {item.badge}
                  </span>
                )}
                {item.count !== undefined && (
                  <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-zinc-800 text-zinc-300">
                    {item.count}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Footer / Engine Status */}
      <div className="p-3 border-t border-zinc-800 space-y-2">
        <div className="px-3 py-1.5 bg-zinc-800/50 rounded-md border border-zinc-800 flex items-center justify-between text-[11px] text-zinc-400">
          <span>AI Engine</span>
          <span className="font-mono text-emerald-400 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 inline-block animate-pulse" />
            NVIDIA NIM
          </span>
        </div>
      </div>
    </aside>
  );
};
