export interface SampleDeck {
  id: string;
  name: string;
  industry: string;
  stage: string;
  slideCount: number;
  description: string;
  slides: {
    title: string;
    text: string;
  }[];
}

export const SAMPLE_DECKS: SampleDeck[] = [
  {
    id: 'nova-ai',
    name: 'NovaAI — Enterprise Workflow Automation',
    industry: 'Artificial Intelligence & B2B SaaS',
    stage: 'Seed',
    slideCount: 12,
    description: 'Autonomous multi-agent orchestration for enterprise operations. Raising $2.5M Seed.',
    slides: [
      {
        title: 'Company / Vision',
        text: 'NovaAI: Autonomous Agent Orchestration for Enterprise Operations.\nReplace manual cross-department reconciliation with self-healing AI workflows.\nConfidential Investor Presentation 2026.'
      },
      {
        title: 'The Problem',
        text: 'Problem: Enterprises lose $2.4M annually to operational context switching and manual data reconciliation.\nTeams spend 16+ hours a week copying data across Salesforce, SAP, and internal databases.\nLegacy RPA is fragile, breaking on even minor UI changes.'
      },
      {
        title: 'The Solution',
        text: 'Solution: NovaAI provides resilient, goal-directed autonomous agents that integrate directly into APIs and internal tools.\nAutomates complex multi-step workflows with 99.4% precision and built-in human-in-the-loop governance.'
      },
      {
        title: 'Product Architecture',
        text: 'Proprietary reasoning engine connected via secure on-prem / cloud VPC connectors.\nZero-shot action planning with self-correcting error loops.\nFull audit logs and enterprise SOC2 Type II compliant.'
      },
      {
        title: 'Why Now?',
        text: 'Catalysts: LLM reasoning costs have dropped 10x while accuracy surged.\nEnterprises have budget fatigue for point solutions and demand consolidated workflow automation.'
      },
      {
        title: 'Traction & Metrics',
        text: 'Traction: 24,000 registered user accounts.\n$48,000 Monthly Recurring Revenue (MRR), up 28% MoM.\n19 enterprise design partners including Fortune 500 logistics and retail teams.'
      },
      {
        title: 'Market Opportunity (TAM)',
        text: 'TAM: $68 Billion global enterprise workflow and robotic process automation market.\nSAM: $9.2 Billion mid-to-large enterprise IT automation.\nSOM: $750 Million initial focus on fintech and logistics operations.'
      },
      {
        title: 'Business Model & Unit Economics',
        text: 'B2B SaaS with usage-based expansion.\nTiered annual contracts: Starter ($24k/yr), Enterprise ($75k/yr), Custom Platform ($150k+/yr).\n82% gross margins with 128% Net Revenue Retention (NRR).'
      },
      {
        title: 'Go-To-Market Engine',
        text: 'Hybrid strategy: Bottom-up developer sandbox paired with high-touch outbound sales to VPs of Engineering.\nAverage sales cycle: 34 days. CAC payback: 5.8 months.'
      },
      {
        title: 'Competitive Landscape',
        text: 'Competitors: UiPath (Legacy RPA, high maintenance), Zapier (SMB only, lacks enterprise security), LangChain (Dev framework, not end-to-end).\nNovaAI Advantage: Zero-code enterprise security with self-healing execution.'
      },
      {
        title: 'Founding Team',
        text: 'Elena Rostova (CEO) — Ex-Product Lead at Palantir, Stanford CS.\nDavid Chen (CTO) — Former Staff ML Engineer at Databricks, MIT PhD.\nMarcus Vance (Head of Growth) — Scaled HashiCorp enterprise pipeline from $5M to $40M.'
      },
      {
        title: 'The Ask & Use of Funds',
        text: 'Raising $2.5M Seed round on SAFE.\nUse of funds: 65% Core ML and infrastructure engineering, 25% Enterprise sales expansion, 10% Ops & legal.\nRunway: 20 months to scale from $580k ARR to $2.2M ARR and 65 enterprise clients.'
      }
    ]
  },
  {
    id: 'pulse-pay',
    name: 'PulsePay — Global Cross-Border B2B Settlement',
    industry: 'Fintech & B2B Payments',
    stage: 'Series A',
    slideCount: 10,
    description: 'Instant multi-currency settlement rails for global supply chains. Raising $6M Series A.',
    slides: [
      {
        title: 'Overview',
        text: 'PulsePay: Instant real-time settlement rails for global B2B supply chains.\nEliminating SWIFT delays and 4% FX markups for cross-border commerce.'
      },
      {
        title: 'The Friction',
        text: 'Cross-border B2B trade incurs $120B in annual hidden banking fees.\nTransactions take 3-5 business days to clear, locking up critical working capital for importers and exporters.'
      },
      {
        title: 'Our Solution',
        text: 'PulsePay provides instant local payout rails in 42 currencies with guaranteed foreign exchange rates and automated customs invoice reconciliation.'
      },
      {
        title: 'Traction',
        text: '$140M annualized gross payment volume (GPV).\n$1.2M Annual Recurring Revenue (ARR) with 3.4x YoY growth.\n140 active B2B importers across US, Europe, and LATAM.'
      },
      {
        title: 'Market Size',
        text: 'Global B2B cross-border payments volume exceeds $35 Trillion annually.\nPulsePay target addressable market in SME trade corridors: $18.5 Billion revenue potential.'
      },
      {
        title: 'Unit Economics',
        text: 'Take rate: 0.45% per transaction + $15 fixed fee.\nGross margins: 74%.\nLTV / CAC ratio: 6.2x with negative net revenue churn.'
      },
      {
        title: 'Regulatory Moat & Licenses',
        text: 'Authorized Payment Institution licenses secured in UK, EU (Lithuania), and registered MSB across 48 US states.'
      },
      {
        title: 'Team',
        text: 'Alexander Wright (CEO) — Ex-Adyen VP Payments.\nSophia Becker (COO) — Former Head of Compliance at Revolut.\nTariq Al-Mansoor (CTO) — Ex-Lead Architect at Wise.'
      },
      {
        title: 'Competition',
        text: 'Legacy banks (Slow, 4% fees), Payoneer (Consumer/Freelancer focused), Airwallex (Mid-market).\nPulsePay differentiation: Direct ERP auto-clearing and instant supplier financing.'
      },
      {
        title: 'Series A Funding Ask',
        text: 'Raising $6.0M Series A.\nAllocation: 40% Tier-1 banking rails integration, 35% US & LATAM sales team, 25% working capital liquidity.'
      }
    ]
  }
];
