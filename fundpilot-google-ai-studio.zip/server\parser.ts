import JSZip from 'jszip';
import { PDFParse } from 'pdf-parse';

export interface ParsedSlide {
  slideNumber: number;
  text: string;
}

/**
 * Robust extraction of text streams from raw binary buffers
 */
function extractAsciiStrings(buffer: Buffer): string[] {
  try {
    const str = buffer.toString('binary');
    // Extract readable text chunks (length >= 12)
    const matches = str.match(/[\x20-\x7E\t\n\r]{12,}/g) || [];
    const filtered = matches
      .map(m => m.trim())
      .filter(m => !m.startsWith('/Filter') && !m.startsWith('/Font') && !m.startsWith('xref') && m.length > 20);
    return filtered;
  } catch {
    return [];
  }
}

/**
 * Parse PDF buffer into array of slides (pages) with multi-level fallbacks
 */
export async function parsePDFBuffer(buffer: Buffer): Promise<ParsedSlide[]> {
  let parser: PDFParse | undefined;
  try {
    // pdf-parse v2 uses PDFParse rather than the callable v1 default export.
    // A copied Uint8Array also avoids worker-transfer issues with pooled Buffers.
    parser = new PDFParse({ data: Uint8Array.from(buffer) });
    const result = await parser.getText();
    const parsedPages = result.pages
      .map(page => page.text.trim())
      .filter(text => text.length > 0);

    if (parsedPages.length > 0) {
      return parsedPages.map((text, index) => ({
        slideNumber: index + 1,
        text
      }));
    }
  } catch (error) {
    console.warn('[PDF Parser] Structured extraction failed; attempting stream recovery:', error);
  } finally {
    await parser?.destroy().catch(() => undefined);
  }

  // Last-resort recovery for malformed PDFs that still contain readable text.
  const chunks = extractAsciiStrings(buffer);
  if (chunks.length > 0) {
    // Group extracted chunks into virtual slides
    const slideSize = Math.max(1, Math.ceil(chunks.length / 8));
    const slides: ParsedSlide[] = [];
    for (let i = 0; i < chunks.length; i += slideSize) {
      const group = chunks.slice(i, i + slideSize).join('\n\n');
      slides.push({
        slideNumber: slides.length + 1,
        text: group
      });
    }
    return slides;
  }

  return [];
}

function decodeXmlText(value: string): string {
  return value
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&amp;/g, '&')
    .replace(/&#(\d+);/g, (_match, decimal: string) => String.fromCodePoint(Number(decimal)))
    .replace(/&#x([0-9a-f]+);/gi, (_match, hex: string) => String.fromCodePoint(parseInt(hex, 16)));
}

/**
 * Parse PPTX buffer into array of slides with error resilience
 */
export async function parsePPTXBuffer(buffer: Buffer): Promise<ParsedSlide[]> {
  try {
    const zip = await JSZip.loadAsync(buffer);
    const slideFiles: { name: string; num: number; file: any }[] = [];

    zip.forEach((relativePath, file) => {
      const match = relativePath.match(/^ppt\/slides\/slide(\d+)\.xml$/i);
      if (match) {
        slideFiles.push({
          name: relativePath,
          num: parseInt(match[1], 10),
          file
        });
      }
    });

    slideFiles.sort((a, b) => a.num - b.num);

    if (slideFiles.length > 0) {
      const slides: ParsedSlide[] = [];
      for (let i = 0; i < slideFiles.length; i++) {
        const xml = await slideFiles[i].file.async('text');
        const textMatches = xml.match(/<a:t>([\s\S]*?)<\/a:t>/gi) || [];
        const slideText = textMatches
          .map((m: string) => decodeXmlText(m.replace(/<\/?a:t>/gi, '').trim()))
          .filter(Boolean)
          .join(' ');

        slides.push({
          slideNumber: i + 1,
          text: slideText || `Slide ${i + 1}: Presentation Slide`
        });
      }
      return slides;
    }
  } catch (err) {
    console.warn('[PPTX Parser] Error unzipping presentation, using stream extraction:', err);
  }

  // Fallback stream extractor for PPT/PPTX
  const chunks = extractAsciiStrings(buffer);
  if (chunks.length > 0) {
    const slideSize = Math.max(1, Math.ceil(chunks.length / 8));
    const slides: ParsedSlide[] = [];
    for (let i = 0; i < chunks.length; i += slideSize) {
      slides.push({
        slideNumber: slides.length + 1,
        text: chunks.slice(i, i + slideSize).join('\n\n')
      });
    }
    return slides;
  }

  return [];
}
