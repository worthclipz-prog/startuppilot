import { 
  StartupProfile, 
  PitchScore, 
  SlideAnalysis, 
  Investor, 
  OutreachAngle 
} from '../../types/index';

/**
 * AI Service Layer for FundPilot
 * Powered by NVIDIA NIM (MiniMax-M3 by default) with an optional direct
 * MiniMax fallback.
 * with robust schema extraction, per-slide scoring, and partner-level VC critiques.
 */

const NVIDIA_BASE_URL = (process.env.NVIDIA_BASE_URL || 'https://integrate.api.nvidia.com/v1')
  .replace(/\/+$/, '');
const NVIDIA_PRIMARY_MODEL = process.env.NVIDIA_PRIMARY_MODEL || 'minimaxai/minimax-m3';
const NVIDIA_FALLBACK_MODEL = process.env.NVIDIA_FALLBACK_MODEL || 'meta/llama-3.1-8b-instruct';
const configuredTimeout = Number(process.env.NVIDIA_REQUEST_TIMEOUT_MS) || 90_000;
const IS_NETLIFY = process.env.NETLIFY === 'true';
const IS_CLOUD_RUN = Boolean(process.env.K_SERVICE);
const NVIDIA_REQUEST_TIMEOUT_MS = IS_NETLIFY
  ? Math.min(configuredTimeout, 50_000)
  : configuredTimeout;

interface ChatMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

interface ChatCompletionResponse {
  choices?: Array<{
    message?: {
      content?: string | null;
      reasoning_content?: string | null;
    };
  }>;
  detail?: string | { message?: string };
  message?: string;
}

interface NvidiaModelConfig {
  name: string;
  key: string;
}

async function mapWithConcurrency<T, R>(
  items: T[],
  limit: number,
  mapper: (item: T, index: number) => Promise<R>
): Promise<R[]> {
  const results = new Array<R>(items.length);
  let nextIndex = 0;

  const worker = async () => {
    while (nextIndex < items.length) {
      const currentIndex = nextIndex++;
      results[currentIndex] = await mapper(items[currentIndex], currentIndex);
    }
  };

  await Promise.all(
    Array.from({ length: Math.min(Math.max(limit, 1), items.length) }, () => worker())
  );
  return results;
}

function configuredNvidiaModels(): NvidiaModelConfig[] {
  const primaryKey = process.env.NVIDIA_API_KEY?.trim() || '';
  const fallbackKey = process.env.NVIDIA_FALLBACK_API_KEY?.trim() || primaryKey;

  return [
    { name: NVIDIA_PRIMARY_MODEL, key: primaryKey },
    { name: NVIDIA_FALLBACK_MODEL, key: fallbackKey }
  ].filter((config, index, configs) =>
    Boolean(config.key) &&
    configs.findIndex(candidate => candidate.name === config.name && candidate.key === config.key) === index
  );
}

function responseErrorMessage(data: ChatCompletionResponse | undefined, status: number): string {
  if (typeof data?.detail === 'string') return data.detail;
  if (data?.detail && typeof data.detail.message === 'string') return data.detail.message;
  if (typeof data?.message === 'string') return data.message;
  return `request failed with HTTP ${status}`;
}

/**
 * Core caller for NVIDIA NIM API with model fallback
 */
export async function callNvidiaNIM(
  messages: ChatMessage[],
  temperature = 0.2,
  maxTokens = 8192
): Promise<string> {
  const models = configuredNvidiaModels();
  const failures: string[] = [];
  // Keep all retries inside Netlify's 60-second synchronous-function limit.
  // Outside Netlify, each provider attempt receives the configured timeout.
  const requestDeadline = IS_NETLIFY ? Date.now() + NVIDIA_REQUEST_TIMEOUT_MS : undefined;
  const attemptTimeout = () => requestDeadline === undefined
    ? NVIDIA_REQUEST_TIMEOUT_MS
    : Math.max(0, requestDeadline - Date.now());

  if (models.length === 0 && !process.env.MINIMAX_API_KEY?.trim()) {
    throw new Error('No AI API key is configured. Set NVIDIA_API_KEY in .env.local.');
  }

  for (const modelConfig of models) {
    const attemptTimeoutMs = attemptTimeout();
    if (attemptTimeoutMs <= 0) {
      failures.push('Netlify AI request budget exhausted');
      break;
    }
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), attemptTimeoutMs);

    try {
      const response = await fetch(`${NVIDIA_BASE_URL}/chat/completions`, {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${modelConfig.key}`
        },
        body: JSON.stringify({
          model: modelConfig.name,
          messages,
          temperature,
          top_p: 0.95,
          max_tokens: Math.min(Math.max(maxTokens, 1), 16_384),
          stream: false
        }),
        signal: controller.signal
      });

      const data = await response.json().catch(() => undefined) as ChatCompletionResponse | undefined;
      if (response.ok) {
        const text = data?.choices?.[0]?.message?.content;
        if (text && text.trim().length > 0) {
          return text;
        }
        failures.push(`${modelConfig.name}: empty response`);
      } else {
        const message = responseErrorMessage(data, response.status);
        failures.push(`${modelConfig.name}: ${message}`);
        console.warn(`NVIDIA NIM error with model ${modelConfig.name} (${response.status}): ${message}`);
      }
    } catch (error) {
      const message = error instanceof Error
        ? (error.name === 'AbortError' ? `timed out after ${attemptTimeoutMs}ms` : error.message)
        : 'unknown request error';
      failures.push(`${modelConfig.name}: ${message}`);
      console.warn(`NVIDIA NIM fetch error for ${modelConfig.name}: ${message}`);
    } finally {
      clearTimeout(timeout);
    }
  }

  // If MiniMax key configured, attempt MiniMax
  const MINIMAX_API_KEY = process.env.MINIMAX_API_KEY?.trim() || '';
  if (MINIMAX_API_KEY) {
    const attemptTimeoutMs = attemptTimeout();
    if (attemptTimeoutMs <= 0) {
      failures.push('MiniMax direct: Netlify AI request budget exhausted');
      throw new Error(`All AI endpoints failed. ${failures.join('; ')}`);
    }
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), attemptTimeoutMs);
    try {
      const mmRes = await fetch('https://api.minimax.chat/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${MINIMAX_API_KEY}`
        },
        body: JSON.stringify({
          model: 'abab6.5s-chat',
          messages,
          temperature,
          max_tokens: maxTokens
        }),
        signal: controller.signal
      });
      if (mmRes.ok) {
        const data = await mmRes.json() as ChatCompletionResponse;
        const content = data?.choices?.[0]?.message?.content;
        if (content) return content;
      }
      failures.push(`MiniMax direct: HTTP ${mmRes.status}`);
    } catch (error) {
      const message = error instanceof Error ? error.message : 'unknown request error';
      failures.push(`MiniMax direct: ${message}`);
      console.warn(`MiniMax fallback failed: ${message}`);
    } finally {
      clearTimeout(timeout);
    }
  }

  throw new Error(`All AI endpoints failed. ${failures.join('; ')}`);
}

/**
 * Robust JSON extraction & cleanup helper
 */
export function cleanAndParseJSON<T>(rawText: string, fallback: T): T {
  try {
    let clean = rawText.trim();
    // Strip reasoning thinking tags
    clean = clean.replace(/<think>[\s\S]*?<\/think>/gi, '').trim();
    
    // Strip markdown tags
    if (clean.includes('```json')) {
      clean = clean.replace(/```json\s*([\s\S]*?)\s*```/g, '$1');
    } else if (clean.includes('```')) {
      clean = clean.replace(/```\s*([\s\S]*?)\s*```/g, '$1');
    }

    const firstBrace = clean.indexOf('{');
    const lastBrace = clean.lastIndexOf('}');
    if (firstBrace !== -1 && lastBrace !== -1 && lastBrace > firstBrace) {
      clean = clean.substring(firstBrace, lastBrace + 1);
    }

    return JSON.parse(clean) as T;
  } catch (err) {
    console.error('JSON parsing error in cleanAndParseJSON:', err);
    return fallback;
  }
}

function createDefaultStartupProfile(): StartupProfile {
  return {
    startupName: 'Not provided',
    description: 'Not provided',
    industry: 'Not provided',
    subIndustry: 'Not provided',
    stage: 'Seed',
    geography: 'Global / US',
    targetCustomer: 'Not provided',
    businessModel: 'B2B SaaS',
    product: 'Not provided',
    problem: 'Not provided',
    solution: 'Not provided',
    revenue: 'Not provided',
    arr: 'Not provided',
    mrr: 'Not provided',
    growth: 'Not provided',
    numberOfUsers: 'Not provided',
    numberOfCustomers: 'Not provided',
    amountRaising: 'Not provided',
    previousFunding: 'Not provided',
    marketSize: 'Not provided',
    team: 'Not provided',
    competitors: 'Not provided',
    useOfFunds: 'Not provided',
    whyNow: 'Not provided',
    leadInvestorNeeded: true
  };
}

/**
 * 1. Extract Startup Profile from Pitch Deck text
 */
export async function extractStartupProfile(deckText: string): Promise<StartupProfile> {
  const systemPrompt = `You are an elite early-stage venture capital analyst. Extract key startup information from this pitch deck.
Never invent missing data. If a field cannot be verified from the text, return exactly "Not provided".
Return valid JSON adhering strictly to this schema:
{
  "startupName": string,
  "description": string,
  "industry": string,
  "subIndustry": string,
  "stage": string,
  "geography": string,
  "targetCustomer": string,
  "businessModel": string,
  "product": string,
  "problem": string,
  "solution": string,
  "revenue": string,
  "arr": string,
  "mrr": string,
  "growth": string,
  "numberOfUsers": string,
  "numberOfCustomers": string,
  "amountRaising": string,
  "previousFunding": string,
  "marketSize": string,
  "team": string,
  "competitors": string,
  "useOfFunds": string,
  "whyNow": string,
  "leadInvestorNeeded": boolean
}`;

  const defaultProfile = createDefaultStartupProfile();

  try {
    const raw = await callNvidiaNIM([
      { role: 'system', content: systemPrompt },
      { role: 'user', content: `Pitch Deck Contents:\n\n${deckText.slice(0, 20000)}` }
    ], 0.1, 3000);
    return cleanAndParseJSON<StartupProfile>(raw, defaultProfile);
  } catch (err) {
    console.warn('AI call failed for extractStartupProfile, using local heuristic:', err);
    return parseStartupProfileLocally(deckText, defaultProfile);
  }
}

/**
 * 2. Analyze an individual slide with comprehensive score, strengths, problems, investor reaction, and revised content
 */
export async function analyzeSlide(
  slideText: string,
  slideIndex: number,
  totalSlides: number,
  startupProfile?: Partial<StartupProfile>
): Promise<SlideAnalysis> {
  const systemPrompt = `You are a ruthless, highly experienced Tier-1 venture capital partner (Benchmark/Sequoia style) reviewing slide ${slideIndex + 1} of ${totalSlides}.
Be critical, specific, evidence-based, and practical. Look for vanity metrics, unsupported TAM, weak retention, unclear unit economics, and lack of differentiation.

Return valid JSON with:
{
  "slideNumber": ${slideIndex + 1},
  "title": string (e.g. "Traction & Metrics", "Problem Statement", "Market Size", "Go-To-Market Engine", "Business Model", "Competitive Moat"),
  "score": number (0 to 100 integer reflecting fundraising readiness for this slide),
  "whatsGood": string[] (2-3 concrete strengths or positive signals),
  "problems": string[] (2-4 specific dealbreakers, missing proofs, or weaknesses),
  "investorReaction": string (1-2 sentence candid partner reaction during a Monday partner meeting),
  "howToImprove": string (Direct, highly actionable advice on what data or framing to fix),
  "suggestedContent": {
    "headline": string (Punchy, metric-driven headline replacing generic titles like 'Our Traction'),
    "bulletPoints": string[] (2-3 specific revised bullet points with realistic numbers/frameworks),
    "visualOrDataAdvice": string (Clear advice on chart type, layout, or table to present)
  }
}`;

  const defaultSlide = generateSlideAnalysisLocally(slideText, slideIndex, totalSlides);

  try {
    const raw = await callNvidiaNIM([
      { role: 'system', content: systemPrompt },
      { role: 'user', content: `Slide #${slideIndex + 1} of ${totalSlides} Text Content:\n${slideText}\n\nStartup Context: ${JSON.stringify(startupProfile || {})}` }
    ], 0.2, 3000);
    
    const parsed = cleanAndParseJSON<SlideAnalysis>(raw, defaultSlide);
    parsed.slideNumber = slideIndex + 1;
    parsed.rawText = slideText;
    if (!parsed.title) parsed.title = defaultSlide.title;
    if (!parsed.score) parsed.score = defaultSlide.score;
    return parsed;
  } catch (err) {
    console.warn(`AI call failed for slide ${slideIndex + 1}, using local VC analyzer:`, err);
    return defaultSlide;
  }
}

/**
 * 3. Generate Deck Score and In-Depth VC Critique
 */
export async function generateDeckScore(
  startupProfile: StartupProfile,
  slides: SlideAnalysis[]
): Promise<PitchScore> {
  const systemPrompt = `You are an elite Tier-1 VC partner evaluating a startup pitch deck for an investment committee.
Analyze the deck critically. Do NOT sugarcoat weaknesses.
Use one of four readiness levels:
- "fundraise_ready" (Overall 85+)
- "almost_ready" (Overall 70-84)
- "major_improvements_needed" (Overall 50-69)
- "not_investor_ready" (Overall <50)

Return valid JSON with:
{
  "overallScore": number (0-100),
  "readiness": "fundraise_ready" | "almost_ready" | "major_improvements_needed" | "not_investor_ready",
  "readinessLabel": string,
  "categoryScores": {
    "problem": number (0-100),
    "solution": number,
    "product": number,
    "market": number,
    "traction": number,
    "businessModel": number,
    "gtm": number,
    "competition": number,
    "defensibility": number,
    "team": number,
    "storytelling": number,
    "designClarity": number,
    "fundingAsk": number
  },
  "topProblems": [
    {
      "rank": number,
      "title": string,
      "diagnosis": string,
      "howToFix": string,
      "category": string
    }
  ] (Top 3-5 biggest dealbreaker problems),
  "investorPerspective": {
    "positive": string,
    "concern": string,
    "question": string
  },
  "rejectionReasons": string[] (3 to 5 realistic partner rejection reasons),
  "missingSlides": [
    {
      "category": "critical" | "important" | "optional",
      "title": string,
      "explanation": string
    }
  ],
  "redFlags": [
    {
      "risk": "high" | "medium" | "low",
      "title": string,
      "description": string,
      "impact": string
    }
  ],
  "improvementPlan": [
    {
      "step": number,
      "action": string,
      "priority": "High" | "Medium" | "Low",
      "targetSlide": number,
      "rationale": string
    }
  ],
  "idealDeckStructure": [
    {
      "slideNumber": number,
      "title": string,
      "purpose": string,
      "keyElements": string[]
    }
  ] (12-15 slide recommended flow tailored to this startup)
}`;

  const defaultScores = generateDefaultPitchScore(startupProfile, slides);

  try {
    const summaryText = `Startup: ${JSON.stringify(startupProfile)}\nSlide Reviews (${slides.length}): ${slides.map(s => `Slide ${s.slideNumber}: ${s.title} (Score ${s.score}/100)\nStrengths: ${s.whatsGood.join(', ')}\nWeaknesses: ${s.problems.join(', ')}`).join('\n\n')}`;
    
    const raw = await callNvidiaNIM([
      { role: 'system', content: systemPrompt },
      { role: 'user', content: summaryText }
    ], 0.2, 4500);

    return cleanAndParseJSON<PitchScore>(raw, defaultScores);
  } catch (err) {
    console.warn('AI call failed for generateDeckScore, using local scoring model:', err);
    return defaultScores;
  }
}

/**
 * 4. Generate Deck Improvements Action Plan
 */
export async function generateImprovements(
  pitchScore: PitchScore,
  slides: SlideAnalysis[]
) {
  return pitchScore.improvementPlan;
}

/**
 * 5. Full Pitch Deck Analysis Orchestration
 */
export async function analyzePitchDeck(
  slideTexts: string[],
  initialFileName = 'pitch-deck.pdf'
) {
  const fullText = slideTexts.join('\n\n--- SLIDE BREAK ---\n\n');
  
  const compactMode = IS_NETLIFY || IS_CLOUD_RUN || process.env.AI_COMPACT_MODE === 'true';
  const startupProfile = compactMode
    ? parseStartupProfileLocally(fullText, createDefaultStartupProfile())
    : await extractStartupProfile(fullText);

  // Hosted runtimes use deterministic per-slide review and reserve one AI call
  // for the consolidated investment-committee critique. This keeps uploads
  // responsive and avoids multiplying third-party inference requests.
  const slideAnalyses = compactMode
    ? slideTexts.map((text, idx) => generateSlideAnalysisLocally(text, idx, slideTexts.length))
    : await mapWithConcurrency(
        slideTexts,
        Number(process.env.AI_CONCURRENCY) || 3,
        (text, idx) => analyzeSlide(text, idx, slideTexts.length, startupProfile)
      );

  // 3. Generate comprehensive deck score & VC critique
  const pitchScore = await generateDeckScore(startupProfile, slideAnalyses);

  return {
    id: `deck-${Date.now()}`,
    fileName: initialFileName,
    uploadedAt: new Date().toISOString(),
    slideCount: slideTexts.length,
    startupProfile,
    pitchScore,
    slides: slideAnalyses
  };
}

/**
 * 6. Generate Investor Match Reason
 */
export async function generateInvestorMatchReason(
  investor: Partial<Investor>,
  startupProfile: StartupProfile
): Promise<string> {
  try {
    const res = await callNvidiaNIM([
      { role: 'system', content: 'In 2 direct, founder-focused sentences, explain exactly why this VC firm matches this specific startup. No fluff.' },
      { role: 'user', content: `VC: ${investor.name}, Thesis: ${investor.thesisSummary}, Sectors: ${investor.sectors?.join(', ')}. Startup: ${startupProfile.startupName}, ${startupProfile.industry}, ${startupProfile.stage}, Raising ${startupProfile.amountRaising}.` }
    ], 0.3, 300);
    return res.trim();
  } catch {
    return `${investor.name} actively targets ${startupProfile.stage} stage startups in the ${startupProfile.industry} space, with typical check sizes aligning directly with your target raise of ${startupProfile.amountRaising}.`;
  }
}

/**
 * 7. Generate Investor Objections
 */
export async function generateInvestorObjections(
  investor: Partial<Investor>,
  startupProfile: StartupProfile
): Promise<string> {
  try {
    const res = await callNvidiaNIM([
      { role: 'system', content: 'In 1 concise sentence, identify the most likely partner objection or portfolio conflict this specific VC might raise.' },
      { role: 'user', content: `VC: ${investor.name}. Startup: ${startupProfile.startupName}, ${startupProfile.industry}, raising ${startupProfile.amountRaising}.` }
    ], 0.3, 200);
    return res.trim();
  } catch {
    return `Partner skepticism regarding moat durability and sales cycle length for ${startupProfile.industry}.`;
  }
}

/**
 * 8. Generate Outreach Messages (Cold email, LinkedIn, Warm intro blurb)
 */
export async function generateOutreachMessage(
  investor: Investor,
  startupProfile: StartupProfile,
  format: 'coldEmail' | 'linkedIn' | 'warmIntro'
): Promise<any> {
  const promptMap = {
    coldEmail: `Generate a concise, punchy cold email from the founder to a partner at ${investor.name}.
Strict Rules:
- NEVER say "I hope this email finds you well" or any generic greeting.
- Max 100-140 words.
- Highlight specific traction, problem, and why ${investor.name}'s thesis/portfolio is relevant.
- Clear, low-friction ask (e.g. 15-min chat next Tuesday).
Return JSON: { "subject": string, "body": string }`,
    linkedIn: `Generate a crisp LinkedIn connection request or InMail (under 280 characters). Direct, relevant to their portfolio, no fluff. Return plain string.`,
    warmIntro: `Generate a forwardable warm intro blurb for a mutual connection to introduce ${startupProfile.startupName} to ${investor.name}. Include high-signal 2-bullet traction highlights and concise raise details. Return JSON: { "requestSubject": string, "blurb": string }`
  };

  try {
    const res = await callNvidiaNIM([
      { role: 'system', content: promptMap[format] },
      { role: 'user', content: `Investor: ${investor.name}, Portfolio: ${investor.relevantInvestments.join(', ')}. Startup: ${JSON.stringify(startupProfile)}` }
    ], 0.3, 500);

    if (format === 'linkedIn') return res.replace(/"/g, '').trim();
    return cleanAndParseJSON(res, {});
  } catch (err) {
    console.warn(`Outreach generation error for ${format}:`, err);
  }

  // Fallbacks
  if (format === 'coldEmail') {
    return {
      subject: `${startupProfile.startupName || 'Startup'} (${startupProfile.industry || 'B2B'}) / ${investor.name}`,
      body: `Hi [Partner Name],\n\nI’ve been following ${investor.name}’s investments in ${investor.relevantInvestments[0] || startupProfile.industry || 'the category'} and thought our progress at ${startupProfile.startupName || 'our company'} would align with your thesis.\n\nWe built ${startupProfile.solution || 'an automated workflow engine'} for ${startupProfile.targetCustomer || 'enterprise teams'}. In the last 6 months, we reached ${startupProfile.mrr || startupProfile.revenue || '$35k MRR'} (${startupProfile.growth || '25% MoM'}) with ${startupProfile.numberOfCustomers || '18 paying customers'}.\n\nWe are opening our ${startupProfile.stage || 'Seed'} round (${startupProfile.amountRaising || '$2M'}) and would welcome the chance to share our deck. Do you have 15 minutes next week?`
    };
  }

  if (format === 'linkedIn') {
    return `Hi [Partner], saw your thesis on ${startupProfile.industry || 'B2B infrastructure'}. We're scaling ${startupProfile.startupName} (${startupProfile.revenue || '$30k MRR'}, ${startupProfile.growth || '25% MoM'}) and opening our ${startupProfile.stage || 'Seed'} round. Would love to share our deck.`;
  }

  return {
    requestSubject: `Intro: ${startupProfile.startupName} <> ${investor.name}`,
    blurb: `Hey [Mutual Contact], would you feel comfortable connecting me with [Partner] at ${investor.name}? Given their focus on ${investor.relevantInvestments[0] || startupProfile.industry}, I believe ${startupProfile.startupName} is a strong fit. Quick snapshot: ${startupProfile.description || 'Enterprise AI workflows'}, ${startupProfile.growth || '25% MoM growth'}, raising ${startupProfile.amountRaising || '$2M'} ${startupProfile.stage || 'Seed'}.`
  };
}

/* =========================================================================
   Local VC Analyst Heuristics & Deterministic Fallbacks
   ========================================================================= */

function inferSlideTitle(text: string, index: number): string {
  const lower = text.toLowerCase();
  if (index === 0) return 'Vision & Company Overview';
  if (lower.includes('problem') || lower.includes('pain point') || lower.includes('friction')) return 'Problem Statement';
  if (lower.includes('solution') || lower.includes('our answer') || lower.includes('value prop')) return 'Solution & Value Proposition';
  if (lower.includes('product') || lower.includes('architecture') || lower.includes('demo') || lower.includes('features')) return 'Product & Technology';
  if (lower.includes('traction') || lower.includes('growth') || lower.includes('revenue') || lower.includes('arr') || lower.includes('mrr')) return 'Traction & Key Metrics';
  if (lower.includes('market') || lower.includes('tam') || lower.includes('sam') || lower.includes('som')) return 'Market Opportunity (TAM)';
  if (lower.includes('business model') || lower.includes('pricing') || lower.includes('unit economics') || lower.includes('monetization')) return 'Business Model & Unit Economics';
  if (lower.includes('go to market') || lower.includes('gtm') || lower.includes('sales pipeline') || lower.includes('acquisition')) return 'Go-To-Market Strategy';
  if (lower.includes('competition') || lower.includes('landscape') || lower.includes('competitors') || lower.includes('matrix')) return 'Competitive Landscape & Moat';
  if (lower.includes('moat') || lower.includes('defensibility') || lower.includes('ip') || lower.includes('retention')) return 'Defensibility & Moats';
  if (lower.includes('team') || lower.includes('founders') || lower.includes('advisors')) return 'Founding Team';
  if (lower.includes('raise') || lower.includes('ask') || lower.includes('round') || lower.includes('funds') || lower.includes('milestones')) return 'The Ask & Use of Funds';
  if (lower.includes('why now') || lower.includes('catalyst') || lower.includes('tailwinds')) return 'Why Now';
  return `Slide ${index + 1}: Overview`;
}

function parseStartupProfileLocally(text: string, fallback: StartupProfile): StartupProfile {
  const profile = { ...fallback };
  const lines = text.split('\n').map(l => l.trim()).filter(Boolean);

  if (lines.length > 0) {
    const firstLine = lines[0].replace(/pitch deck|confidential|investor presentation/gi, '').trim();
    if (firstLine && firstLine.length < 40) {
      profile.startupName = firstLine;
    }
  }

  const arrMatch = text.match(/\$([0-9.,]+[kKmMbB]?)\s*(ARR|annual recurring revenue)/i);
  if (arrMatch) profile.arr = `$${arrMatch[1]} ARR`;

  const mrrMatch = text.match(/\$([0-9.,]+[kKmMbB]?)\s*(MRR|monthly recurring revenue)/i);
  if (mrrMatch) profile.mrr = `$${mrrMatch[1]} MRR`;

  const raiseMatch = text.match(/raising\s*\$([0-9.,]+[kKmMbB]?)/i) || text.match(/\$([0-9.,]+[kKmMbB]?)\s*(seed|series a|pre-seed|round)/i);
  if (raiseMatch) profile.amountRaising = `$${raiseMatch[1]}`;

  const tamMatch = text.match(/\$([0-9.,]+[kKmMbB]?)\s*(TAM|market|total addressable)/i);
  if (tamMatch) profile.marketSize = `$${tamMatch[1]} TAM`;

  const lower = text.toLowerCase();
  if (lower.includes('ai') || lower.includes('machine learning') || lower.includes('llm')) {
    profile.industry = 'Artificial Intelligence';
    profile.subIndustry = 'Enterprise AI & Workflow Automation';
  } else if (lower.includes('fintech') || lower.includes('payment') || lower.includes('banking')) {
    profile.industry = 'Fintech';
    profile.subIndustry = 'B2B Payments & Infrastructure';
  } else if (lower.includes('health') || lower.includes('medical')) {
    profile.industry = 'Healthcare';
    profile.subIndustry = 'Digital Health';
  } else {
    profile.industry = 'B2B SaaS';
    profile.subIndustry = 'Vertical Software';
  }

  if (lower.includes('series a')) profile.stage = 'Series A';
  else if (lower.includes('pre-seed')) profile.stage = 'Pre-Seed';
  else if (lower.includes('series b')) profile.stage = 'Series B';
  else profile.stage = 'Seed';

  return profile;
}

function generateSlideAnalysisLocally(
  slideText: string,
  index: number,
  total: number
): SlideAnalysis {
  const title = inferSlideTitle(slideText, index);
  const lower = slideText.toLowerCase();

  let score = 74;
  const whatsGood: string[] = [];
  const problems: string[] = [];
  let investorReaction = "Clear context, but requires deeper proof.";
  let howToImprove = "Quantify claims with verifiable baseline data.";
  let headline = `Defensible ${title}`;
  let bulletPoints = ["Specify target ICP and core differentiators", "Add supporting metrics with clear timelines"];
  let visualAdvice = "Structure in a clean 3-part column layout with clear data callouts.";

  if (title.includes('Traction')) {
    score = lower.includes('mrr') || lower.includes('arr') ? 78 : 62;
    whatsGood.push("Demonstrates active market engagement and early revenue trajectory.");
    if (!lower.includes('retention') && !lower.includes('cohort')) {
      problems.push("Does not show user cohort retention (30/60/90 day curves).");
      problems.push("Total registered users without MAU/DAU breakdown is treated as a vanity metric.");
    }
    if (!lower.includes('cac') && !lower.includes('payback')) {
      problems.push("Customer acquisition cost (CAC) and payback period are missing.");
    }
    investorReaction = "I see early signs of usage, but cannot tell if customers stick around or churn.";
    howToImprove = "Replace cumulative signups with net revenue retention (NRR), monthly active users, and gross margins.";
    headline = "Proven Cohort Retention & Capital-Efficient Growth";
    bulletPoints = [
      "Show MoM revenue expansion and Net Revenue Retention (>115%)",
      "Display CAC payback period under 8 months across primary outbound channels"
    ];
    visualAdvice = "Use a retention heat map or clean cohort line chart rather than cumulative bars.";
  } else if (title.includes('Market')) {
    score = 68;
    whatsGood.push("Identifies a large aggregate addressable space.");
    problems.push("TAM calculation relies on top-down industry reports rather than bottom-up unit economics.");
    problems.push("SAM and SOM boundaries are loosely defined without clear filtering by ICP.");
    investorReaction = "Every deck shows a $50B market. How many accounts can this team actually close in 24 months?";
    howToImprove = "Build a bottom-up TAM: (Total # of Qualified ICP Accounts in Target Geos) × (Annual Contract Value / ACV).";
    headline = "Bottom-Up $4.2B Serviceable Addressable Market";
    bulletPoints = [
      "120,000 mid-market enterprises × $35,000 average annual contract value",
      "High urgency driver: regulatory compliance mandates and 3x cost savings"
    ];
    visualAdvice = "Present a 3-tier nested concentric circle diagram with explicit calculation equations.";
  } else if (title.includes('Problem')) {
    score = 82;
    whatsGood.push("Pain point is articulated with high user empathy.");
    problems.push("Lacks quantification of financial loss incurred by the customer from this problem.");
    investorReaction = "Is this a vitamin or an urgent painkiller with allocated budget?";
    howToImprove = "Highlight the exact dollar loss, hours wasted, or regulatory risk the customer faces today.";
    headline = "Enterprise Teams Lose $180k/Year to Manual Reconciliation";
    bulletPoints = [
      "65% of operations staff spend >14 hours/week on fragmented spreadsheet verification",
      "High error rates result in compliance fines and delayed financial close"
    ];
  } else if (title.includes('Ask') || title.includes('Funds')) {
    score = 65;
    whatsGood.push("States target capital amount.");
    problems.push("Fails to clearly map capital expenditure to 18-month key derisking milestones.");
    problems.push("Hiring plan and runway duration are not explicitly tied to Series A graduation metrics.");
    investorReaction = "What exact metrics will this $2M buy before they need to raise their next round?";
    howToImprove = "Tie the raise amount to 18-24 months of runway reaching specific ARR milestones (e.g. $1.5M ARR).";
    headline = "$2.0M Seed to Reach $1.8M ARR & Series A Graduation";
    bulletPoints = [
      "Capital allocation: 60% Engineering/Product, 30% GTM & Sales, 10% Ops/Legal",
      "18-month runway targeting 85 enterprise customers and $150k MRR"
    ];
  } else {
    whatsGood.push("Logical narrative structure and concise messaging.");
    problems.push("Requires deeper differentiation against incumbent workflows.");
    investorReaction = "Needs more concrete proof points to stand out in partner meetings.";
    howToImprove = "Focus on unfair advantages, customer quotes, or technical moats.";
  }

  return {
    slideNumber: index + 1,
    title,
    score,
    rawText: slideText,
    whatsGood: whatsGood.length > 0 ? whatsGood : ["Clear overview."],
    problems: problems.length > 0 ? problems : ["Needs deeper quantitative validation."],
    investorReaction,
    howToImprove,
    suggestedContent: {
      headline,
      bulletPoints,
      visualOrDataAdvice: visualAdvice
    }
  };
}

function generateDefaultPitchScore(
  profile: StartupProfile,
  slides: SlideAnalysis[]
): PitchScore {
  const avgSlideScore = slides.length > 0
    ? Math.round(slides.reduce((acc, s) => acc + s.score, 0) / slides.length)
    : 72;

  const overallScore = Math.min(Math.max(avgSlideScore, 58), 88);

  let readiness: PitchScore['readiness'] = 'almost_ready';
  let readinessLabel = 'Almost Fundraise Ready';

  if (overallScore >= 85) {
    readiness = 'fundraise_ready';
    readinessLabel = 'Fundraise Ready';
  } else if (overallScore >= 70) {
    readiness = 'almost_ready';
    readinessLabel = 'Almost Ready (Traction & GTM Fixes Needed)';
  } else if (overallScore >= 50) {
    readiness = 'major_improvements_needed';
    readinessLabel = 'Major Improvements Needed';
  } else {
    readiness = 'not_investor_ready';
    readinessLabel = 'Not Investor Ready';
  }

  return {
    overallScore,
    readiness,
    readinessLabel,
    categoryScores: {
      problem: 86,
      solution: 84,
      product: 80,
      market: 72,
      traction: 64,
      businessModel: 76,
      gtm: 68,
      competition: 71,
      defensibility: 69,
      team: 88,
      storytelling: 82,
      designClarity: 79,
      fundingAsk: 65
    },
    topProblems: [
      {
        rank: 1,
        title: "Weak traction evidence & missing cohort retention",
        diagnosis: "The deck mentions early users/signups but does not show active retention curves, churn rate, or MoM net revenue retention.",
        howToFix: "Add 30/60/90-day cohort retention, Monthly Active Users (MAU), and customer logo expansion data.",
        category: "Traction"
      },
      {
        rank: 2,
        title: "Market size lacks bottom-up calculation",
        diagnosis: "TAM is stated with a generic multi-billion dollar macro figure without showing the formula: (Total target accounts) × (Annual contract value).",
        howToFix: "Present a bottom-up SAM/SOM calculation filtered specifically by your Ideal Customer Profile (ICP).",
        category: "Market"
      },
      {
        rank: 3,
        title: "Fundraising ask is disconnected from milestone milestones",
        diagnosis: "The amount being raised does not specify the exact runway timeline or the quantifiable ARR targets required for Series A graduation.",
        howToFix: "Explicitly state: '$2M gives 18-24 months of runway to grow from $35k MRR to $150k MRR with 45 enterprise clients'.",
        category: "Funding Ask"
      },
      {
        rank: 4,
        title: "Go-to-market engine appears unproven",
        diagnosis: "Customer acquisition relies heavily on vague 'organic word-of-mouth and outbound' without channel payback economics or CAC data.",
        howToFix: "Detail your primary acquisition channel, cost per lead, sales cycle duration (e.g. 28 days), and current sales pipeline value.",
        category: "Go-To-Market"
      }
    ],
    investorPerspective: {
      positive: "Strong founder-market fit, clear problem articulation, and an intuitive product interface.",
      concern: "I still don't know whether customers retain after month 3 or what it actually costs to acquire an enterprise contract.",
      question: "How will this startup defend against well-funded incumbents building copycat features into their existing suites?"
    },
    rejectionReasons: [
      "Limited quantitative evidence of repeatable, scalable product-market fit.",
      "Customer acquisition strategy and unit economics are not yet proven.",
      "Market opportunity calculations lack rigorous bottom-up validation.",
      "Competitive moat against incumbent feature expansion appears vulnerable."
    ],
    missingSlides: [
      {
        category: "critical",
        title: "Unit Economics & Cohort Retention",
        explanation: "Tier-1 VCs will request CAC, LTV/CAC ratio, and 6-month retention data before scheduling second-round partner meetings."
      },
      {
        category: "important",
        title: "Why Now (Market Catalyst)",
        explanation: "Explain what technological or regulatory shift makes this the exact right moment for this company to exist."
      },
      {
        category: "important",
        title: "Detailed 18-Month Use of Funds & Milestones",
        explanation: "Break down headcounts, engineering spend, and Series A inflection milestones funded by this round."
      },
      {
        category: "optional",
        title: "Customer Case Study / ROI Proof",
        explanation: "A single quantified quote showing customer time saved or revenue gained significantly boosts credibility."
      }
    ],
    redFlags: [
      {
        risk: "high",
        title: "Vanity Metrics Over Retention",
        description: "Focusing on cumulative registered accounts instead of active engaged cohorts creates skepticism among technical investors.",
        impact: "Partners assume high churn rates when active engagement isn't highlighted."
      },
      {
        risk: "medium",
        title: "Top-Down TAM Reliance",
        description: "Quoting a $50B Gartner report instead of showing ACV x realistic qualified buyers.",
        impact: "Signals lack of deep financial modeling rigor."
      },
      {
        risk: "medium",
        title: "Unclear Defensibility Moat",
        description: "Relying purely on 'first mover advantage' rather than proprietary data, high switching costs, or network effects.",
        impact: "Fosters fear that incumbents will replicate functionality in their next release."
      }
    ],
    improvementPlan: [
      {
        step: 1,
        action: "Rebuild Traction Slide with Cohorts & Expansion Metrics",
        priority: "High",
        targetSlide: 6,
        rationale: "Traction is the primary filter in modern early-stage venture rounds."
      },
      {
        step: 2,
        action: "Recalculate Bottom-Up Market Size with Explicit ACV Math",
        priority: "High",
        targetSlide: 7,
        rationale: "Shows investors you understand commercial scaling and account density."
      },
      {
        step: 3,
        action: "Clarify 18-Month Runway & Series A Milestone Metrics",
        priority: "High",
        targetSlide: 14,
        rationale: "Instills confidence that capital won't be depleted before next valuation inflection."
      },
      {
        step: 4,
        action: "Add Defensible Competitive Grid with Proprietary Moats",
        priority: "Medium",
        targetSlide: 10,
        rationale: "Addresses the inevitable partner question: 'What stops incumbents from doing this?'"
      },
      {
        step: 5,
        action: "Detail Primary GTM Channel Payback & Sales Cycle",
        priority: "Medium",
        targetSlide: 9,
        rationale: "Demonstrates an efficient, repeatable customer acquisition engine."
      }
    ],
    idealDeckStructure: [
      { slideNumber: 1, title: "01 Company / Vision", purpose: "One-sentence crystal clear hook and mission", keyElements: ["Tagline", "Category definition", "Value proposition"] },
      { slideNumber: 2, title: "02 The Problem", purpose: "Quantified enterprise pain point & financial loss", keyElements: ["Who suffers", "$ wasted / hours lost", "Why status quo fails"] },
      { slideNumber: 3, title: "03 The Solution", purpose: "Your unfair approach and workflow transformation", keyElements: ["Core value", "10x improvement over legacy", "Key benefit"] },
      { slideNumber: 4, title: "04 Product & Tech", purpose: "Visual product proof and architecture highlights", keyElements: ["UI screenshot", "Key workflow steps", "Integration ecosystem"] },
      { slideNumber: 5, title: "05 Why Now?", purpose: "Macro catalysts enabling this solution today", keyElements: ["Tech breakthrough", "Regulatory shift", "Market inflection"] },
      { slideNumber: 6, title: "06 Traction & Metrics", purpose: "Definitive proof of real adoption and growth", keyElements: ["MRR/ARR growth", "Cohort retention", "Paying customer count", "Net revenue retention"] },
      { slideNumber: 7, title: "07 Market Size (TAM/SAM)", purpose: "Bottom-up calculation of addressable revenue", keyElements: ["Qualified ICP accounts", "Average contract value", "Expansion paths"] },
      { slideNumber: 8, title: "08 Business Model", purpose: "Pricing tiers, unit economics and ACV", keyElements: ["Pricing structure", "Gross margin", "LTV/CAC ratio"] },
      { slideNumber: 9, title: "09 Go-To-Market Engine", purpose: "Repeatable customer acquisition channels", keyElements: ["Outbound/Inbound mix", "CAC payback period", "Sales cycle length (days)"] },
      { slideNumber: 10, title: "10 Competitive Landscape", purpose: "Clear 2x2 or feature grid proving superiority", keyElements: ["Direct & indirect competitors", "Legacy vs. Modern", "Speed & ROI advantages"] },
      { slideNumber: 11, title: "11 Defensibility & Moat", purpose: "Long-term structural barriers to entry", keyElements: ["Proprietary data flywheels", "High switching costs", "Integration lock-in"] },
      { slideNumber: 12, title: "12 Founding Team", purpose: "Why this team is destined to win this market", keyElements: ["Founder backgrounds", "Relevant exits or domain expertise", "Key technical advisors"] },
      { slideNumber: 13, title: "13 Financial Plan", purpose: "High-level 2-year revenue and expense projection", keyElements: ["Key hiring milestones", "Target ARR growth", "Burn rate"] },
      { slideNumber: 14, title: "14 The Ask & Runway", purpose: "Round size, target runway, and use of funds", keyElements: ["Round size ($M)", "18-24 month runway", "Key milestone goals for Series A"] }
    ]
  };
}
