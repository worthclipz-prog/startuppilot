# FundPilot

FundPilot analyzes pitch decks, extracts startup metrics, scores fundraising readiness, and matches startups with investors. Its server calls NVIDIA NIM through the OpenAI-compatible chat-completions API.

## Google AI Studio / Cloud Run

This project is configured as a full-stack Node.js application. Google Cloud buildpacks run `npm run gcp-build`, then start the compiled Express server with `npm start`.

1. Push or import the project into a GitHub repository.
2. In Google AI Studio Build mode, choose **Add files → Import from GitHub**.
3. Open **Settings → Secrets** and add `NVIDIA_API_KEY` with a newly generated NVIDIA key.
4. Do not add the key to React source files or commit it to GitHub.
5. Preview the app and open `/api/health`, which should return `{"status":"ok"}`.
6. Open `/api/config`, which should report `"configured": true` and MiniMax M3 as the first model.
7. Deploy the app to Cloud Run from Google AI Studio.

Optional server-side variables:

- `NVIDIA_FALLBACK_API_KEY` — a separate fallback credential; when omitted, the primary key is reused.
- `NVIDIA_BASE_URL` — defaults to `https://integrate.api.nvidia.com/v1`.
- `NVIDIA_PRIMARY_MODEL` — defaults to `minimaxai/minimax-m3`.
- `NVIDIA_FALLBACK_MODEL` — defaults to `meta/llama-3.1-8b-instruct`.
- `NVIDIA_REQUEST_TIMEOUT_MS` — defaults to 90000 milliseconds.
- `AI_COMPACT_MODE` — Cloud Run enables compact hosted analysis automatically.

See [GOOGLE_AI_STUDIO.md](./GOOGLE_AI_STUDIO.md) for the deployment checklist and troubleshooting steps.

## Local setup

Prerequisite: Node.js 20.16 or newer.

1. Run `npm install`.
2. Copy `.env.example` to `.env.local`.
3. Add `NVIDIA_API_KEY` to `.env.local`.
4. Run `npm run dev`.
5. Open `http://localhost:3000`.

## Netlify compatibility

The existing `netlify.toml` and `netlify/functions/api.mts` are retained for Netlify deployments. Configure `NVIDIA_API_KEY` in Netlify environment variables; never upload `.env.local`.

## Commands

- `npm run lint` — TypeScript check.
- `npm run build` — client build.
- `npm run build:server` — client plus standalone Express server bundle.
- `npm run gcp-build` — Google Cloud build hook.
- `npm start` — production server on the platform-provided `PORT`.

Supported deck formats are PDF, PPTX, TXT, and Markdown, up to 4 MB. Image-only PDFs must first be exported with selectable text.
