# Google AI Studio deployment checklist

## Import

Google AI Studio imports existing projects from GitHub. Upload this project to a private GitHub repository, then select **Add files → Import from GitHub** in Build mode.

The app is a full-stack Node.js service:

- React/Vite serves the browser interface.
- Express serves the compiled frontend and all `/api/*` routes.
- NVIDIA credentials are read only by the server through `process.env`.
- `gcp-build` compiles both the frontend and production server for Cloud Run.

## Secrets

In **Settings → Secrets**, add:

```text
NVIDIA_API_KEY = your newly generated NVIDIA API key
```

Do not use a `VITE_` prefix. Vite-prefixed variables can be embedded in browser code.

Optional overrides:

```text
NVIDIA_PRIMARY_MODEL = minimaxai/minimax-m3
NVIDIA_FALLBACK_MODEL = meta/llama-3.1-8b-instruct
NVIDIA_BASE_URL = https://integrate.api.nvidia.com/v1
NVIDIA_REQUEST_TIMEOUT_MS = 90000
```

## Verify before publishing

Open these paths in the preview or deployed service:

```text
/api/health
/api/config
```

Expected health response:

```json
{"status":"ok","service":"FundPilot","runtime":"Google Cloud Run"}
```

Expected configuration indicators:

```json
{
  "status": "ok",
  "configured": true,
  "models": [
    "minimaxai/minimax-m3",
    "meta/llama-3.1-8b-instruct"
  ]
}
```

Then test the paste-text analysis with one or two short slides before testing PDF/PPTX upload.

## Troubleshooting

- `configured: false`: `NVIDIA_API_KEY` is missing from AI Studio Secrets or the Cloud Run revision.
- HTTP 404 on `/api/health`: only the Vite frontend was deployed; deploy the full Node.js service.
- HTTP 502 before `/api/health` responds: the Node.js server failed to start. Review Cloud Run logs for build or startup errors.
- HTTP 413: the deck exceeds FundPilot's 4 MB application upload limit.
- Image-only PDF: export it with selectable text or upload PPTX/TXT instead.
