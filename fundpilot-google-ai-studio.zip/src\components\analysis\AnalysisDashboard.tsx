import React, { useState } from 'react';
import { 
  PitchDeckReport, 
  ReadinessLevel 
} from '../../types/index';
import { CategoryScoreGrid } from './CategoryScoreGrid';
import { SlideCard } from './SlideCard';
import { DeckStructureView } from './DeckStructureView';
import { 
  BarChart3, 
  AlertTriangle, 
  ThumbsUp, 
  HelpCircle, 
  XCircle, 
  Sparkles, 
  Search, 
  ArrowRight,
  FileText,
  Layers,
  ChevronRight,
  Edit2
} from 'lucide-react';

interface AnalysisDashboardProps {
  report: PitchDeckReport;
  onGoToInvestors: () => void;
  onEditProfile: () => void;
}

export const AnalysisDashboard: React.FC<AnalysisDashboardProps> = ({
  report,
  onGoToInvestors,
  onEditProfile
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'slides' | 'structure'>('overview');
  const { pitchScore, startupProfile, slides } = report;

  const getReadinessStyle = (readiness: ReadinessLevel) => {
    switch (readiness) {
      case 'fundraise_ready':
        return {
          bg: 'bg-emerald-50 text-emerald-900 border-emerald-300',
          badge: 'bg-emerald-600 text-white',
          label: 'Fundraise Ready'
        };
      case 'almost_ready':
        return {
          bg: 'bg-zinc-100 text-zinc-900 border-zinc-300',
          badge: 'bg-zinc-900 text-white',
          label: 'Almost Ready'
        };
      case 'major_improvements_needed':
        return {
          bg: 'bg-amber-50 text-amber-900 border-amber-300',
          badge: 'bg-amber-600 text-white',
          label: 'Major Improvements Needed'
        };
      case 'not_investor_ready':
      default:
        return {
          bg: 'bg-rose-50 text-rose-900 border-rose-300',
          badge: 'bg-rose-600 text-white',
          label: 'Not Investor Ready'
        };
    }
  };

  const readinessInfo = getReadinessStyle(pitchScore.readiness);

  return (
    <div className="max-w-5xl mx-auto py-8 px-6 space-y-8">
      {/* Top Banner / Startup Identity & Quick Actions */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-zinc-200">
        <div>
          <div className="flex items-center gap-2.5">
            <h2 className="text-xl font-bold text-zinc-900 tracking-tight">
              {startupProfile.startupName !== 'Not provided' ? startupProfile.startupName : report.fileName}
            </h2>
            <span className="text-xs font-mono px-2 py-0.5 rounded bg-zinc-100 text-zinc-700 font-medium">
              {startupProfile.stage} • {startupProfile.industry}
            </span>
          </div>
          <p className="text-xs text-zinc-500 mt-1 max-w-2xl truncate">
            {startupProfile.description !== 'Not provided' ? startupProfile.description : 'Pitch Deck VC Evaluation Report'}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onEditProfile}
            id="btn-edit-extracted-profile"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-md border border-zinc-300 text-xs font-medium text-zinc-700 bg-white hover:bg-zinc-50 transition-colors"
          >
            <Edit2 className="w-3.5 h-3.5" />
            <span>Edit Startup Data</span>
          </button>

          <button
            onClick={onGoToInvestors}
            id="btn-go-to-investors-from-analysis"
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-md bg-zinc-900 text-xs font-semibold text-white hover:bg-zinc-800 transition-colors shadow-xs"
          >
            <Search className="w-3.5 h-3.5" />
            <span>Find Matching VCs →</span>
          </button>
        </div>
      </div>

      {/* Section 4: Overall Pitch Score Header Card */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Score block */}
        <div className="p-6 rounded-xl border border-zinc-200 bg-white flex flex-col justify-between shadow-2xs">
          <span className="text-xs font-medium uppercase font-mono tracking-wider text-zinc-500">
            Overall Pitch Score
          </span>
          <div className="my-3 flex items-baseline gap-2">
            <span className="text-5xl font-black font-mono tracking-tight text-zinc-900">
              {pitchScore.overallScore}
            </span>
            <span className="text-xl font-mono text-zinc-400 font-bold">/ 100</span>
          </div>
          <div className="flex items-center gap-2">
            <span className={`text-xs font-semibold px-2.5 py-1 rounded-md ${readinessInfo.badge}`}>
              {readinessInfo.label}
            </span>
          </div>
        </div>

        {/* Top Dealbreaker Summary */}
        <div className="p-6 rounded-xl border border-zinc-200 bg-white flex flex-col justify-between shadow-2xs md:col-span-2">
          <span className="text-xs font-medium uppercase font-mono tracking-wider text-zinc-500">
            Primary Diligence Dealbreaker
          </span>
          <div className="my-2">
            <h4 className="text-base font-bold text-zinc-900">
              {pitchScore.topProblems[0]?.title || 'Traction & Unit Economics Proof'}
            </h4>
            <p className="text-xs text-zinc-600 mt-1 leading-relaxed">
              {pitchScore.topProblems[0]?.diagnosis || 'Deck needs stronger quantitative validation and cohort retention evidence.'}
            </p>
          </div>
          <div className="pt-2 border-t border-zinc-100 flex items-center justify-between text-xs text-zinc-500">
            <span>Action: {pitchScore.topProblems[0]?.howToFix?.slice(0, 80)}...</span>
            <span className="font-mono text-[11px] text-zinc-400">{slides.length} slides</span>
          </div>
        </div>
      </div>

      {/* Navigation Sub-Tabs: Overview vs Slide-by-Slide vs Deck Structure */}
      <div className="flex items-center gap-2 border-b border-zinc-200 pb-2">
        <button
          onClick={() => setActiveTab('overview')}
          id="tab-analysis-overview"
          className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-colors flex items-center gap-1.5 ${
            activeTab === 'overview'
              ? 'bg-zinc-900 text-white'
              : 'text-zinc-600 hover:text-zinc-900 hover:bg-zinc-100'
          }`}
        >
          <BarChart3 className="w-3.5 h-3.5" />
          <span>Executive Overview & Scores</span>
        </button>

        <button
          onClick={() => setActiveTab('slides')}
          id="tab-analysis-slides"
          className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-colors flex items-center gap-1.5 ${
            activeTab === 'slides'
              ? 'bg-zinc-900 text-white'
              : 'text-zinc-600 hover:text-zinc-900 hover:bg-zinc-100'
          }`}
        >
          <FileText className="w-3.5 h-3.5" />
          <span>Slide-by-Slide Analysis ({slides.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('structure')}
          id="tab-analysis-structure"
          className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-colors flex items-center gap-1.5 ${
            activeTab === 'structure'
              ? 'bg-zinc-900 text-white'
              : 'text-zinc-600 hover:text-zinc-900 hover:bg-zinc-100'
          }`}
        >
          <Layers className="w-3.5 h-3.5" />
          <span>Red Flags & Ideal Structure</span>
        </button>
      </div>

      {/* TAB 1: EXECUTIVE OVERVIEW */}
      {activeTab === 'overview' && (
        <div className="space-y-8">
          {/* Section 5: Category Scores */}
          <div className="bg-white rounded-xl border border-zinc-200 p-6 space-y-4 shadow-2xs">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-zinc-900 tracking-tight">
                Category Scores
              </h3>
              <span className="text-xs font-mono text-zinc-400">13 VC Dimensions</span>
            </div>
            <CategoryScoreGrid scores={pitchScore.categoryScores} />
          </div>

          {/* Section 6: Biggest Problems (Top Problems) */}
          <div className="bg-white rounded-xl border border-zinc-200 p-6 space-y-4 shadow-2xs">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-zinc-900" />
                <h3 className="text-base font-bold text-zinc-900 tracking-tight">
                  Biggest Problems
                </h3>
              </div>
              <span className="text-xs font-mono text-zinc-500">Ranked by VC Dealbreaker Severity</span>
            </div>

            <div className="space-y-4">
              {pitchScore.topProblems.map((prob, idx) => (
                <div
                  key={idx}
                  className="p-4 rounded-lg border border-zinc-200 bg-zinc-50/50 space-y-2 text-xs"
                >
                  <div className="flex items-start justify-between gap-2">
                    <h4 className="font-bold text-sm text-zinc-900 flex items-center gap-2">
                      <span className="w-5 h-5 rounded-full bg-zinc-900 text-white font-mono text-xs flex items-center justify-center shrink-0">
                        {idx + 1}
                      </span>
                      <span>{prob.title}</span>
                    </h4>
                    <span className="text-[10px] font-mono uppercase font-semibold px-2 py-0.5 rounded bg-zinc-200 text-zinc-700 shrink-0">
                      {prob.category}
                    </span>
                  </div>

                  <p className="text-zinc-600 pl-7 leading-relaxed">
                    {prob.diagnosis}
                  </p>

                  <div className="pl-7 pt-1">
                    <div className="p-2.5 rounded bg-white border border-zinc-200 space-y-1">
                      <span className="font-bold text-zinc-900 block text-[11px] uppercase tracking-wider">
                        How To Fix
                      </span>
                      <p className="text-zinc-700 font-medium leading-relaxed">
                        {prob.howToFix}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Section 7: What A VC May Think */}
          <div className="bg-white rounded-xl border border-zinc-200 p-6 space-y-4 shadow-2xs">
            <h3 className="text-base font-bold text-zinc-900 tracking-tight">
              What A VC May Think
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
              {/* Positive */}
              <div className="p-4 rounded-lg bg-emerald-50/50 border border-emerald-200 space-y-2">
                <div className="flex items-center gap-1.5 font-bold text-emerald-900 text-sm">
                  <ThumbsUp className="w-4 h-4 text-emerald-600" />
                  <span>Positive</span>
                </div>
                <p className="text-zinc-700 italic leading-relaxed">
                  "{pitchScore.investorPerspective.positive}"
                </p>
              </div>

              {/* Concern */}
              <div className="p-4 rounded-lg bg-amber-50/50 border border-amber-200 space-y-2">
                <div className="flex items-center gap-1.5 font-bold text-amber-900 text-sm">
                  <AlertTriangle className="w-4 h-4 text-amber-600" />
                  <span>Concern</span>
                </div>
                <p className="text-zinc-700 italic leading-relaxed">
                  "{pitchScore.investorPerspective.concern}"
                </p>
              </div>

              {/* Question */}
              <div className="p-4 rounded-lg bg-zinc-100 border border-zinc-200 space-y-2">
                <div className="flex items-center gap-1.5 font-bold text-zinc-900 text-sm">
                  <HelpCircle className="w-4 h-4 text-zinc-600" />
                  <span>Partner Question</span>
                </div>
                <p className="text-zinc-700 italic leading-relaxed">
                  "{pitchScore.investorPerspective.question}"
                </p>
              </div>
            </div>
          </div>

          {/* Section 8: Likely Reasons For Rejection */}
          <div className="bg-white rounded-xl border border-zinc-200 p-6 space-y-4 shadow-2xs">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <XCircle className="w-5 h-5 text-rose-600" />
                <h3 className="text-base font-bold text-zinc-900 tracking-tight">
                  Likely Reasons For Rejection
                </h3>
              </div>
              <span className="text-xs font-mono text-zinc-500">Partner IC Feedback</span>
            </div>

            <div className="space-y-2 text-xs">
              {pitchScore.rejectionReasons.map((reason, idx) => (
                <div
                  key={idx}
                  className="p-3 rounded-lg border border-zinc-200 bg-zinc-50 flex items-start gap-2.5"
                >
                  <span className="w-5 h-5 rounded bg-rose-100 text-rose-800 font-mono font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                    {idx + 1}
                  </span>
                  <p className="text-zinc-800 font-medium leading-relaxed">
                    {reason}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: SLIDE-BY-SLIDE ANALYSIS (Section 9) */}
      {activeTab === 'slides' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-zinc-900 tracking-tight">
                Slide-by-Slide Analysis
              </h3>
              <p className="text-xs text-zinc-500">
                Detailed critique, strengths, dealbreaker weaknesses, and suggested copy for each slide.
              </p>
            </div>
            <span className="text-xs font-mono px-2 py-1 rounded bg-zinc-100 text-zinc-700">
              {slides.length} Slides Processed
            </span>
          </div>

          <div className="space-y-4">
            {slides.map((slide) => (
              <SlideCard key={slide.slideNumber} slide={slide} />
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: DECK STRUCTURE & RED FLAGS (Sections 10, 11, 12, 13) */}
      {activeTab === 'structure' && (
        <DeckStructureView
          idealDeck={pitchScore.idealDeckStructure}
          improvementPlan={pitchScore.improvementPlan}
          missingSlides={pitchScore.missingSlides}
          redFlags={pitchScore.redFlags}
        />
      )}

      {/* Bottom CTA bar */}
      <div className="p-6 rounded-xl bg-zinc-900 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-sm">
        <div>
          <h4 className="font-bold text-base">Ready to connect with relevant VCs?</h4>
          <p className="text-xs text-zinc-400 mt-0.5">
            Match with Tier-1 investors actively investing in {startupProfile.stage} {startupProfile.industry} startups.
          </p>
        </div>

        <button
          onClick={onGoToInvestors}
          className="flex items-center gap-2 px-5 py-2.5 rounded-lg bg-white text-zinc-950 text-xs font-bold hover:bg-zinc-100 transition-colors shrink-0"
        >
          <span>Find Matching Investors</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
