import React from 'react';
import { 
  ArrowRight, 
  BarChart3, 
  Users, 
  ShieldAlert, 
  FileText, 
  Sparkles,
  CheckCircle2,
  UploadCloud
} from 'lucide-react';
import { PitchDeckReport } from '../../types/index';
import { SAMPLE_DECKS, SampleDeck } from '../../lib/pitch/sampleDecks';

interface LandingViewProps {
  onStartAnalysis?: () => void;
  onGetStarted?: () => void;
  onGoToInvestors?: () => void;
  onSelectSampleDeck?: (sampleId: string) => void;
  onLoadSample?: (sampleId: string) => void;
  currentReport?: PitchDeckReport | null;
  report?: PitchDeckReport | null;
  onViewReport?: () => void;
  isLoadingSample?: boolean;
  isAnalyzing?: boolean;
}

export const LandingView: React.FC<LandingViewProps> = ({
  onStartAnalysis,
  onGetStarted,
  onGoToInvestors,
  onSelectSampleDeck,
  onLoadSample,
  currentReport,
  report,
  onViewReport,
  isLoadingSample,
  isAnalyzing
}) => {
  const activeReport = currentReport || report || null;
  const isLoading = Boolean(isLoadingSample || isAnalyzing);

  const handleStartAnalysis = () => {
    if (onStartAnalysis) {
      onStartAnalysis();
    } else if (onGetStarted) {
      onGetStarted();
    }
  };

  const handleGoToInvestors = () => {
    if (onGoToInvestors) {
      onGoToInvestors();
    } else if (onGetStarted) {
      onGetStarted();
    }
  };

  const handleSelectSample = (id: string) => {
    if (onSelectSampleDeck) {
      onSelectSampleDeck(id);
    } else if (onLoadSample) {
      onLoadSample(id);
    }
  };

  return (
    <div className="max-w-4xl mx-auto py-12 px-6">
      {/* Existing Report Banner if available */}
      {activeReport && (
        <div className="mb-8 p-4 rounded-lg bg-zinc-900 text-zinc-100 flex items-center justify-between border border-zinc-800 shadow-xs">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-md bg-zinc-800 flex items-center justify-center font-mono font-bold text-sm text-emerald-400">
              {activeReport.pitchScore.overallScore}
            </div>
            <div>
              <div className="text-xs font-semibold text-zinc-100 flex items-center gap-2">
                <span>Active Deck: {activeReport.startupProfile.startupName || activeReport.fileName}</span>
                <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-zinc-800 text-zinc-300">
                  {activeReport.pitchScore.readinessLabel}
                </span>
              </div>
              <p className="text-[11px] text-zinc-400">
                {activeReport.slideCount} slides analyzed • Uploaded {new Date(activeReport.uploadedAt).toLocaleTimeString()}
              </p>
            </div>
          </div>
          {onViewReport && (
            <button
              onClick={onViewReport}
              id="btn-view-active-report"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-zinc-100 text-zinc-900 text-xs font-semibold hover:bg-white transition-colors cursor-pointer"
            >
              <span>View Full Analysis</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      )}

      {/* Main Hero Section */}
      <div className="text-center space-y-4 py-8">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-zinc-100 border border-zinc-200 text-xs font-medium text-zinc-700">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          <span>AI Pitch Deck & VC Readiness Analyst</span>
        </div>

        <h1 className="text-4xl md:text-5xl font-bold tracking-tight text-zinc-900">
          Raise Smarter.
        </h1>

        <p className="text-base md:text-lg text-zinc-600 max-w-2xl mx-auto leading-relaxed">
          Upload your pitch deck, discover what investors may dislike, and find the VCs most relevant to your startup.
        </p>

        {/* Primary Action Buttons */}
        <div className="pt-4 flex flex-wrap items-center justify-center gap-3">
          <button
            id="btn-hero-analyze-deck"
            type="button"
            onClick={handleStartAnalysis}
            className="flex items-center gap-2 px-6 py-3 rounded-lg bg-zinc-900 text-white font-semibold text-sm hover:bg-zinc-800 active:bg-zinc-950 transition-colors shadow-xs cursor-pointer"
          >
            <UploadCloud className="w-4 h-4" />
            <span>Analyze Pitch Deck</span>
          </button>

          <button
            id="btn-hero-find-investors"
            type="button"
            onClick={handleGoToInvestors}
            className="flex items-center gap-2 px-6 py-3 rounded-lg bg-white border border-zinc-300 text-zinc-800 font-semibold text-sm hover:bg-zinc-50 hover:border-zinc-400 active:bg-zinc-100 transition-colors shadow-2xs cursor-pointer"
          >
            <Users className="w-4 h-4" />
            <span>Find Investors</span>
          </button>
        </div>

        {/* Instant Demo / Sample Decks */}
        <div className="pt-6">
          <p className="text-xs text-zinc-500 mb-2.5 font-medium">Or test instantly with a verified sample deck:</p>
          <div className="flex flex-wrap items-center justify-center gap-2">
            {SAMPLE_DECKS.map((sample: SampleDeck) => (
              <button
                key={sample.id}
                id={`btn-sample-deck-${sample.id}`}
                type="button"
                disabled={isLoading}
                onClick={() => handleSelectSample(sample.id)}
                className="px-3.5 py-1.5 rounded-md border border-zinc-200 bg-white hover:bg-zinc-50 active:bg-zinc-100 text-xs text-zinc-800 font-medium transition-colors flex items-center gap-1.5 disabled:opacity-50 shadow-2xs cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5 text-zinc-600" />
                <span>{sample.name}</span>
                <span className="text-[10px] text-zinc-400 font-mono">({sample.stage})</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* 3 Core Minimal Feature Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5 pt-10 border-t border-zinc-200">
        <div 
          onClick={handleStartAnalysis}
          className="p-5 rounded-lg border border-zinc-200 bg-white shadow-2xs space-y-2 hover:border-zinc-300 transition-colors cursor-pointer"
        >
          <div className="w-8 h-8 rounded-md bg-zinc-100 flex items-center justify-center text-zinc-800">
            <BarChart3 className="w-4 h-4" />
          </div>
          <h3 className="font-semibold text-sm text-zinc-900">Pitch Deck Analysis</h3>
          <p className="text-xs text-zinc-500 leading-normal">
            Understand what works and what needs improvement across 13 core investor dimensions.
          </p>
        </div>

        <div 
          onClick={handleGoToInvestors}
          className="p-5 rounded-lg border border-zinc-200 bg-white shadow-2xs space-y-2 hover:border-zinc-300 transition-colors cursor-pointer"
        >
          <div className="w-8 h-8 rounded-md bg-zinc-100 flex items-center justify-center text-zinc-800">
            <Users className="w-4 h-4" />
          </div>
          <h3 className="font-semibold text-sm text-zinc-900">VC Matching</h3>
          <p className="text-xs text-zinc-500 leading-normal">
            Find investors based on sector, stage, geography, check size, and portfolio conflict analysis.
          </p>
        </div>

        <div 
          onClick={handleStartAnalysis}
          className="p-5 rounded-lg border border-zinc-200 bg-white shadow-2xs space-y-2 hover:border-zinc-300 transition-colors cursor-pointer"
        >
          <div className="w-8 h-8 rounded-md bg-zinc-100 flex items-center justify-center text-zinc-800">
            <ShieldAlert className="w-4 h-4" />
          </div>
          <h3 className="font-semibold text-sm text-zinc-900">Fundraising Readiness</h3>
          <p className="text-xs text-zinc-500 leading-normal">
            See whether your company appears ready to raise, with ranked dealbreaker mistakes and actionable fixes.
          </p>
        </div>
      </div>
    </div>
  );
};
