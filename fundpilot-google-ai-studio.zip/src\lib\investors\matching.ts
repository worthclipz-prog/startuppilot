import { Investor, InvestorMatchCategory, StartupProfile, InvestorCRMStatus, SavedInvestor } from '../../types/index';
import { VC_DATABASE, VCFirmRecord } from './database';

export interface MatchingCriteria {
  industry?: string;
  stage?: string;
  country?: string;
  amountRaising?: string;
  businessModel?: string;
  targetMarket?: string;
  leadInvestorNeeded?: boolean;
  minScore?: number;
}

/**
 * Parse numeric target raise from string e.g. "$2M" -> 2.0, "$750k" -> 0.75
 */
export function parseRaiseAmountToMillions(amountStr?: string): number {
  if (!amountStr || amountStr === 'Not provided') return 2.0; // default $2M seed benchmark
  const cleaned = amountStr.replace(/[^0-9.kmKMbB]/g, '').toLowerCase();
  
  if (cleaned.includes('b')) {
    const num = parseFloat(cleaned.replace('b', ''));
    return isNaN(num) ? 2.0 : num * 1000;
  }
  if (cleaned.includes('m')) {
    const num = parseFloat(cleaned.replace('m', ''));
    return isNaN(num) ? 2.0 : num;
  }
  if (cleaned.includes('k')) {
    const num = parseFloat(cleaned.replace('k', ''));
    return isNaN(num) ? 2.0 : num / 1000;
  }
  const num = parseFloat(cleaned);
  if (!isNaN(num)) {
    if (num > 10000) return num / 1000000; // raw dollars
    return num;
  }
  return 2.0;
}

/**
 * Compute multi-dimensional match score between a VC and a startup
 */
export function calculateInvestorMatch(
  vc: VCFirmRecord,
  startup: StartupProfile,
  criteria?: MatchingCriteria
): Investor {
  const targetStage = criteria?.stage || startup.stage || 'Seed';
  const targetIndustry = (criteria?.industry || startup.industry || 'B2B SaaS').toLowerCase();
  const targetGeography = (criteria?.country || startup.geography || 'Global').toLowerCase();
  const targetRaise = parseRaiseAmountToMillions(criteria?.amountRaising || startup.amountRaising);
  const targetModel = (criteria?.businessModel || startup.businessModel || 'B2B').toUpperCase();
  const leadNeeded = criteria?.leadInvestorNeeded ?? (startup.leadInvestorNeeded ?? true);

  // 1. Stage Fit (0 - 100)
  let stageFit = 50;
  const stageMatches = vc.stages.some(s => s.toLowerCase() === targetStage.toLowerCase());
  if (stageMatches) {
    stageFit = 95;
  } else if (
    (targetStage === 'Pre-Seed' && vc.stages.includes('Seed')) ||
    (targetStage === 'Seed' && vc.stages.includes('Series A')) ||
    (targetStage === 'Series A' && (vc.stages.includes('Seed') || vc.stages.includes('Series B')))
  ) {
    stageFit = 76;
  } else {
    stageFit = 40;
  }

  // 2. Sector Fit (0 - 100)
  let sectorFit = 60;
  const sectorMatchesExact = vc.sectors.some(sec => 
    sec.toLowerCase().includes(targetIndustry) || targetIndustry.includes(sec.toLowerCase())
  );
  if (sectorMatchesExact) {
    sectorFit = 96;
  } else {
    // Check related keywords
    const isTechGeneral = vc.sectors.some(s => ['Enterprise', 'B2B SaaS', 'Artificial Intelligence'].includes(s));
    if (isTechGeneral) {
      sectorFit = 82;
    } else {
      sectorFit = 55;
    }
  }

  // 3. Check Size Fit (0 - 100)
  let checkSizeFit = 80;
  if (targetRaise >= vc.typicalCheckMin && targetRaise <= vc.typicalCheckMax) {
    checkSizeFit = 96;
  } else if (targetRaise < vc.typicalCheckMin) {
    const diff = vc.typicalCheckMin - targetRaise;
    checkSizeFit = Math.max(50, Math.round(90 - diff * 12));
  } else {
    const diff = targetRaise - vc.typicalCheckMax;
    checkSizeFit = Math.max(50, Math.round(90 - diff * 8));
  }

  // 4. Geography Fit (0 - 100)
  let geographyFit = 85;
  const locLower = vc.location.toLowerCase();
  if (
    targetGeography.includes('global') ||
    (targetGeography.includes('us') && locLower.includes('ca')) ||
    (targetGeography.includes('us') && locLower.includes('ny')) ||
    (targetGeography.includes('europe') && (locLower.includes('uk') || locLower.includes('germany') || locLower.includes('europe') || locLower.includes('france') || locLower.includes('sweden'))) ||
    (targetGeography.includes('uk') && locLower.includes('london'))
  ) {
    geographyFit = 94;
  } else {
    geographyFit = 75;
  }

  // 5. Portfolio & Thesis Fit (0 - 100)
  let portfolioFit = 86;
  if (vc.relevantInvestments.length > 4) portfolioFit = 92;

  // 6. Lead Investor adjustment
  let leadPenalty = 0;
  if (leadNeeded && vc.leadPreference === 'Follow') {
    leadPenalty = 15;
  }

  // Weighted total match score
  const weightedScore = Math.round(
    stageFit * 0.30 +
    sectorFit * 0.30 +
    checkSizeFit * 0.20 +
    geographyFit * 0.10 +
    portfolioFit * 0.10 -
    leadPenalty
  );

  const finalMatchScore = Math.min(Math.max(weightedScore, 45), 98);

  let matchCategory: InvestorMatchCategory = 'possible';
  if (finalMatchScore >= 90) {
    matchCategory = 'best';
  } else if (finalMatchScore >= 80) {
    matchCategory = 'strong';
  } else {
    matchCategory = 'possible';
  }

  // Generate specific Why They Match narrative
  const whyTheyMatch = `${vc.name} exhibits exceptional ${targetStage} stage alignment with standard check sizes ($${vc.typicalCheckMin}M–$${vc.typicalCheckMax}M) fitting your target ${startup.amountRaising || `$${targetRaise}M`} raise. Their portfolio demonstrates strong conviction in ${vc.sectors.slice(0, 2).join(' and ')}.`;

  // Generate potential problems / objections
  let potentialProblem = `High investment bar on gross margins and repeatable sales pipeline velocity.`;
  if (vc.potentialPortfolioConflict && vc.potentialPortfolioConflict.length > 0) {
    potentialProblem = `Potential portfolio overlap or conflict with existing backing in ${vc.potentialPortfolioConflict[0]}.`;
  } else if (vc.leadPreference === 'Lead' && targetRaise < 1.0) {
    potentialProblem = `Firm typically prefers to lead rounds with at least $1.5M+ check sizes.`;
  }

  // Generate structured outreach
  const startupTitle = startup.startupName && startup.startupName !== 'Not provided' ? startup.startupName : 'Our Company';
  const tractionSummary = startup.mrr !== 'Not provided' ? `${startup.mrr} (${startup.growth || '25% MoM'})` : (startup.revenue !== 'Not provided' ? startup.revenue : 'early commercial traction');
  const partnerName = vc.keyPartners[0] || 'Partner';

  const outreach = {
    angle: `Highlight category positioning against ${vc.relevantInvestments[0] || 'legacy players'} and emphasize recent ${tractionSummary} velocity.`,
    coldEmail: {
      subject: `${startupTitle} (${startup.industry || 'B2B'}) — Seed Round / ${vc.name}`,
      body: `Hi ${partnerName.split(' ')[0]},\n\nI’ve followed ${vc.name}’s investments in ${vc.relevantInvestments.slice(0, 2).join(' and ')} and noticed your thesis in ${startup.industry || 'the space'}.\n\nAt ${startupTitle}, we built ${startup.solution || 'software'} for ${startup.targetCustomer || 'enterprise teams'}. Over the past quarters we reached ${tractionSummary} with ${startup.numberOfCustomers || 'enterprise contracts'}.\n\nWe are opening our ${targetStage} round (${startup.amountRaising || `$${targetRaise}M`}) and would value a brief conversation on whether this aligns with your current focus. Would you have 15 minutes next week?`
    },
    linkedIn: `Hi ${partnerName.split(' ')[0]}, saw your thesis on ${startup.industry || 'B2B infrastructure'}. We're scaling ${startupTitle} (${tractionSummary}) and raising our ${targetStage} round. Would love to share our deck.`,
    warmIntro: {
      requestSubject: `Intro request: ${startupTitle} <> ${vc.name}`,
      blurb: `Hey [Mutual Contact], could you make an intro to ${partnerName} at ${vc.name}? Given their focus on ${vc.relevantInvestments[0] || startup.industry}, ${startupTitle} is directly in their wheelhouse. We're growing ${tractionSummary} and raising ${startup.amountRaising || `$${targetRaise}M`} for our ${targetStage}.`
    }
  };

  return {
    id: vc.id,
    name: vc.name,
    website: vc.website,
    location: vc.location,
    stages: vc.stages,
    sectors: vc.sectors,
    checkSizeRange: vc.checkSizeRange,
    typicalCheckMin: vc.typicalCheckMin,
    typicalCheckMax: vc.typicalCheckMax,
    leadPreference: vc.leadPreference,
    targetB2B_B2C: vc.targetB2B_B2C,
    matchScore: finalMatchScore,
    breakdown: {
      stageFit,
      sectorFit,
      checkSizeFit,
      geographyFit,
      portfolioFit
    },
    matchCategory,
    whyTheyMatch,
    relevantInvestments: vc.relevantInvestments,
    potentialProblem,
    thesisSummary: vc.thesisSummary,
    keyPartners: vc.keyPartners,
    recentActivity: vc.recentActivity,
    outreach
  };
}

/**
 * Match all VCs against a startup profile and optional filter criteria
 */
export function matchInvestors(
  startup: StartupProfile,
  criteria?: MatchingCriteria
): Investor[] {
  let matched = VC_DATABASE.map(vc => calculateInvestorMatch(vc, startup, criteria));

  // Filter if criteria present
  if (criteria?.minScore) {
    matched = matched.filter(inv => inv.matchScore >= criteria.minScore!);
  }

  // Sort descending by match score
  matched.sort((a, b) => b.matchScore - a.matchScore);

  return matched;
}

/**
 * Local Storage CRM Manager for Saved Investors
 */
const SAVED_INVESTORS_KEY = 'fundpilot_saved_investors_v1';

export function getSavedInvestors(): SavedInvestor[] {
  try {
    const raw = localStorage.getItem(SAVED_INVESTORS_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch (err) {
    console.error('Error reading saved investors from localStorage:', err);
    return [];
  }
}

export function saveInvestor(
  investor: Investor,
  status: InvestorCRMStatus = 'Researching',
  notes = ''
): SavedInvestor[] {
  try {
    const current = getSavedInvestors();
    const existingIndex = current.findIndex(s => s.investorId === investor.id);
    
    const now = new Date().toISOString();
    if (existingIndex >= 0) {
      current[existingIndex].status = status;
      current[existingIndex].notes = notes || current[existingIndex].notes;
      current[existingIndex].lastUpdated = now;
      current[existingIndex].investor = investor;
    } else {
      current.push({
        investorId: investor.id,
        investor,
        status,
        notes,
        savedAt: now,
        lastUpdated: now
      });
    }

    localStorage.setItem(SAVED_INVESTORS_KEY, JSON.stringify(current));
    return current;
  } catch (err) {
    console.error('Error saving investor to localStorage:', err);
    return [];
  }
}

export function removeSavedInvestor(investorId: string): SavedInvestor[] {
  try {
    const current = getSavedInvestors().filter(s => s.investorId !== investorId);
    localStorage.setItem(SAVED_INVESTORS_KEY, JSON.stringify(current));
    return current;
  } catch (err) {
    console.error('Error removing saved investor:', err);
    return [];
  }
}

export function updateSavedInvestorStatus(
  investorId: string,
  status: InvestorCRMStatus,
  notes?: string
): SavedInvestor[] {
  try {
    const current = getSavedInvestors();
    const item = current.find(s => s.investorId === investorId);
    if (item) {
      item.status = status;
      if (notes !== undefined) item.notes = notes;
      item.lastUpdated = new Date().toISOString();
      localStorage.setItem(SAVED_INVESTORS_KEY, JSON.stringify(current));
    }
    return current;
  } catch (err) {
    console.error('Error updating saved investor status:', err);
    return [];
  }
}
