import React, { useState } from 'react';
import { 
  SavedInvestor, 
  InvestorCRMStatus, 
  StartupProfile, 
  Investor 
} from '../../types/index';
import { InvestorDetailModal } from './InvestorDetailModal';
import { 
  Bookmark, 
  Trash2, 
  ExternalLink, 
  MessageSquare, 
  Mail, 
  FileSpreadsheet, 
  ArrowRight, 
  Check, 
  Edit3,
  Calendar,
  Sparkles,
  Building
} from 'lucide-react';

interface SavedInvestorsViewProps {
  savedInvestors: SavedInvestor[];
  startupProfile: StartupProfile | null;
  onUpdateStatus: (investorId: string, status: InvestorCRMStatus) => void;
  onUpdateNotes: (investorId: string, notes: string) => void;
  onRemoveSaved: (investorId: string) => void;
  onFindMore: () => void;
}

const CRM_STATUSES: InvestorCRMStatus[] = [
  'Researching',
  'Planning Outreach',
  'Contacted',
  'Meeting',
  'Interested',
  'Passed'
];

export const SavedInvestorsView: React.FC<SavedInvestorsViewProps> = ({
  savedInvestors,
  startupProfile,
  onUpdateStatus,
  onUpdateNotes,
  onRemoveSaved,
  onFindMore
}) => {
  const [editingNotesId, setEditingNotesId] = useState<string | null>(null);
  const [tempNotes, setTempNotes] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [selectedInvestorForModal, setSelectedInvestorForModal] = useState<Investor | null>(null);

  const filteredList = savedInvestors.filter(item => {
    if (statusFilter === 'all') return true;
    return item.status === statusFilter;
  });

  const getStatusBadge = (status: InvestorCRMStatus) => {
    switch (status) {
      case 'Meeting':
      case 'Interested':
        return 'bg-emerald-50 text-emerald-800 border-emerald-300 font-bold';
      case 'Contacted':
        return 'bg-zinc-900 text-white font-bold';
      case 'Planning Outreach':
        return 'bg-zinc-100 text-zinc-900 border-zinc-300 font-semibold';
      case 'Passed':
        return 'bg-rose-50 text-rose-800 border-rose-200';
      case 'Researching':
      default:
        return 'bg-zinc-100 text-zinc-700 border-zinc-200';
    }
  };

  const handleStartEditingNotes = (item: SavedInvestor) => {
    setEditingNotesId(item.investorId);
    setTempNotes(item.notes || '');
  };

  const handleSaveNotes = (investorId: string) => {
    onUpdateNotes(investorId, tempNotes);
    setEditingNotesId(null);
  };

  const exportCSV = () => {
    const headers = ['Investor Name', 'Match Score', 'Status', 'Location', 'Check Size', 'Saved Date', 'Notes'];
    const rows = savedInvestors.map(s => [
      `"${s.investor.name}"`,
      `"${s.investor.matchScore}%"`,
      `"${s.status}"`,
      `"${s.investor.location}"`,
      `"${s.investor.checkSizeRange}"`,
      `"${new Date(s.savedAt).toLocaleDateString()}"`,
      `"${(s.notes || '').replace(/"/g, '""')}"`
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `fundpilot-investor-pipeline-${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="max-w-5xl mx-auto py-8 px-6 space-y-8">
      {/* Header & Export Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-zinc-200">
        <div>
          <div className="flex items-center gap-2.5">
            <h2 className="text-xl font-bold text-zinc-900 tracking-tight">
              Investor Pipeline CRM
            </h2>
            <span className="text-xs font-mono px-2 py-0.5 rounded bg-zinc-100 text-zinc-800 font-bold">
              {savedInvestors.length} Tracked
            </span>
          </div>
          <p className="text-xs text-zinc-500 mt-1">
            Track founder outreach, partner meetings, custom notes, and generate tailored cold intro blurbs.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {savedInvestors.length > 0 && (
            <button
              onClick={exportCSV}
              id="btn-export-pipeline-csv"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-md border border-zinc-300 bg-white text-xs font-semibold text-zinc-700 hover:bg-zinc-50 transition-colors shadow-2xs"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span>Export CSV</span>
            </button>
          )}

          <button
            onClick={onFindMore}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-md bg-zinc-900 text-white text-xs font-semibold hover:bg-zinc-800 transition-colors shadow-2xs"
          >
            <span>+ Find More VCs</span>
          </button>
        </div>
      </div>

      {/* Filter by Status Pill Bar */}
      {savedInvestors.length > 0 && (
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
          <button
            onClick={() => setStatusFilter('all')}
            className={`px-3 py-1 rounded-full font-medium transition-colors ${
              statusFilter === 'all'
                ? 'bg-zinc-900 text-white'
                : 'bg-zinc-100 text-zinc-600 hover:bg-zinc-200'
            }`}
          >
            All ({savedInvestors.length})
          </button>

          {CRM_STATUSES.map(status => {
            const count = savedInvestors.filter(s => s.status === status).length;
            if (count === 0) return null;
            return (
              <button
                key={status}
                onClick={() => setStatusFilter(status)}
                className={`px-3 py-1 rounded-full font-medium transition-colors ${
                  statusFilter === status
                    ? 'bg-zinc-900 text-white'
                    : 'bg-zinc-100 text-zinc-600 hover:bg-zinc-200'
                }`}
              >
                {status} ({count})
              </button>
            );
          })}
        </div>
      )}

      {/* Pipeline List */}
      {filteredList.length > 0 ? (
        <div className="space-y-4">
          {filteredList.map((item) => (
            <div
              key={item.investorId}
              className="bg-white rounded-xl border border-zinc-200 p-5 shadow-2xs space-y-4 hover:border-zinc-300 transition-all"
            >
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                {/* VC details */}
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <h3 className="text-base font-bold text-zinc-900">
                      {item.investor.name}
                    </h3>
                    <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-zinc-100 text-zinc-800">
                      {item.investor.matchScore}% Fit
                    </span>
                    <a
                      href={item.investor.website}
                      target="_blank"
                      rel="noreferrer"
                      className="text-zinc-400 hover:text-zinc-700"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  </div>

                  <p className="text-xs text-zinc-500 font-mono">
                    {item.investor.location} • Check: {item.investor.checkSizeRange} • Stages: {item.investor.stages.join(', ')}
                  </p>
                </div>

                {/* Pipeline Status Selector & Actions */}
                <div className="flex items-center gap-2">
                  <select
                    value={item.status}
                    onChange={(e) => onUpdateStatus(item.investorId, e.target.value as InvestorCRMStatus)}
                    className={`text-xs px-2.5 py-1 rounded border font-semibold focus:outline-hidden ${getStatusBadge(item.status)}`}
                  >
                    {CRM_STATUSES.map(st => (
                      <option key={st} value={st}>{st}</option>
                    ))}
                  </select>

                  <button
                    onClick={() => setSelectedInvestorForModal(item.investor)}
                    className="p-1.5 rounded-md text-zinc-500 hover:text-zinc-900 hover:bg-zinc-100"
                    title="Generate Outreach Message"
                  >
                    <Mail className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => onRemoveSaved(item.investorId)}
                    className="p-1.5 rounded-md text-zinc-400 hover:text-rose-600 hover:bg-rose-50"
                    title="Remove from pipeline"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Angle & Why Matched */}
              <div className="p-3 rounded-lg bg-zinc-50 border border-zinc-100 text-xs space-y-1">
                <span className="font-semibold text-zinc-900 block">Outreach Thesis & Angle:</span>
                <p className="text-zinc-700">
                  {item.investor.outreach.angle}
                </p>
              </div>

              {/* Notes Area */}
              <div className="text-xs pt-1 border-t border-zinc-100 space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-zinc-600 flex items-center gap-1.5">
                    <Edit3 className="w-3.5 h-3.5 text-zinc-400" />
                    <span>Founder Notes</span>
                  </span>
                  {editingNotesId !== item.investorId && (
                    <button
                      onClick={() => handleStartEditingNotes(item)}
                      className="text-[11px] text-zinc-500 hover:text-zinc-900 underline"
                    >
                      {item.notes ? 'Edit Notes' : '+ Add Notes'}
                    </button>
                  )}
                </div>

                {editingNotesId === item.investorId ? (
                  <div className="space-y-2">
                    <textarea
                      rows={2}
                      value={tempNotes}
                      onChange={(e) => setTempNotes(e.target.value)}
                      placeholder="e.g. Sent cold intro on Tuesday; partner responded asking for cohort retention data..."
                      className="w-full p-2.5 rounded-md border border-zinc-300 text-xs bg-white focus:outline-hidden"
                    />
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleSaveNotes(item.investorId)}
                        className="px-3 py-1 rounded bg-zinc-900 text-white text-[11px] font-semibold flex items-center gap-1"
                      >
                        <Check className="w-3 h-3" />
                        <span>Save Notes</span>
                      </button>
                      <button
                        onClick={() => setEditingNotesId(null)}
                        className="px-3 py-1 rounded border border-zinc-300 text-zinc-700 text-[11px]"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                ) : (
                  <p className="text-zinc-600 italic bg-white p-2 rounded border border-zinc-100">
                    {item.notes || 'No notes added yet.'}
                  </p>
                )}
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="p-12 text-center bg-white rounded-xl border border-zinc-200 space-y-4">
          <Bookmark className="w-8 h-8 text-zinc-400 mx-auto" />
          <div className="space-y-1">
            <h4 className="font-bold text-zinc-900">No Saved Investors Yet</h4>
            <p className="text-xs text-zinc-500 max-w-sm mx-auto">
              Browse matching VCs and save target funds to build your round pipeline.
            </p>
          </div>
          <button
            onClick={onFindMore}
            className="px-4 py-2 rounded-md bg-zinc-900 text-white text-xs font-semibold hover:bg-zinc-800"
          >
            Explore Matching Investors →
          </button>
        </div>
      )}

      {/* Outreach Modal Trigger */}
      {selectedInvestorForModal && (
        <InvestorDetailModal
          investor={selectedInvestorForModal}
          startupProfile={startupProfile || {
            startupName: 'Company',
            description: '',
            industry: 'Technology',
            subIndustry: '',
            stage: 'Seed',
            geography: 'US',
            targetCustomer: '',
            businessModel: 'B2B',
            product: '',
            problem: '',
            solution: '',
            revenue: '',
            arr: '',
            mrr: '',
            growth: '',
            numberOfUsers: '',
            numberOfCustomers: '',
            amountRaising: '$2M',
            previousFunding: '',
            marketSize: '',
            team: '',
            competitors: '',
            useOfFunds: '',
            whyNow: '',
            leadInvestorNeeded: true
          }}
          isSaved={true}
          onClose={() => setSelectedInvestorForModal(null)}
          onSave={() => setSelectedInvestorForModal(null)}
        />
      )}
    </div>
  );
};
