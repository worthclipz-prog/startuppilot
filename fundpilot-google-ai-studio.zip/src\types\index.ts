export type ReadinessLevel = 
  | 'fundraise_ready'
  | 'almost_ready'
  | 'major_improvements_needed'
  | 'not_investor_ready';

export type RiskLevel = 'high' | 'medium' | 'low';
export type MissingSeverity = 'critical' | 'important' | 'optional';

export interface StartupProfile {
  startupName: string;
  description: string;
  industry: string;
  subIndustry: string;
  stage: string;
  geography: string;
  targetCustomer: string;
  businessModel: string;
  product: string;
  problem: string;
  solution: string;
  revenue: string;
  arr: string;
  mrr: string;
  growth: string;
  numberOfUsers: string;
  numberOfCustomers: string;
  amountRaising: string;
  previousFunding: string;
  marketSize: string;
  team: string;
  competitors: string;
  useOfFunds: string;
  whyNow: string;
  leadInvestorNeeded: boolean;
}

export interface CategoryScores {
  problem: number;
  solution: number;
  product: number;
  market: number;
  traction: number;
  businessModel: number;
  gtm: number;
  competition: number;
  defensibility: number;
  team: number;
  storytelling: number;
  designClarity: number;
  fundingAsk: number;
}

export interface TopProblem {
  rank: number;
  title: string;
  diagnosis: string;
  howToFix: string;
  category: string;
}

export interface InvestorPerspective {
  positive: string;
  concern: string;
  question: string;
}

export interface MissingSlideInfo {
  category: MissingSeverity;
  title: string;
  explanation: string;
}

export interface RedFlag {
  risk: RiskLevel;
  title: string;
  description: string;
  impact: string;
}

export interface ImprovementStep {
  step: number;
  action: string;
  priority: 'High' | 'Medium' | 'Low';
  targetSlide?: number;
  rationale: string;
}

export interface RecommendedSlide {
  slideNumber: number;
  title: string;
  purpose: string;
  keyElements: string[];
}

export interface SlideAnalysis {
  slideNumber: number;
  title: string;
  score: number;
  rawText?: string;
  whatsGood: string[];
  problems: string[];
  investorReaction: string;
  howToImprove: string;
  suggestedContent: {
    headline: string;
    bulletPoints: string[];
    visualOrDataAdvice: string;
  };
}

export interface PitchScore {
  overallScore: number;
  readiness: ReadinessLevel;
  readinessLabel: string;
  categoryScores: CategoryScores;
  topProblems: TopProblem[];
  investorPerspective: InvestorPerspective;
  rejectionReasons: string[];
  missingSlides: MissingSlideInfo[];
  redFlags: RedFlag[];
  improvementPlan: ImprovementStep[];
  idealDeckStructure: RecommendedSlide[];
}

export interface PitchDeckReport {
  id: string;
  fileName: string;
  uploadedAt: string;
  fileSize?: number;
  slideCount: number;
  startupProfile: StartupProfile;
  pitchScore: PitchScore;
  slides: SlideAnalysis[];
}

export type InvestorMatchCategory = 'best' | 'strong' | 'possible';

export interface InvestorBreakdown {
  stageFit: number;
  sectorFit: number;
  checkSizeFit: number;
  geographyFit: number;
  portfolioFit: number;
}

export interface OutreachAngle {
  angle: string;
  coldEmail: {
    subject: string;
    body: string;
  };
  linkedIn: string;
  warmIntro: {
    requestSubject: string;
    blurb: string;
  };
}

export interface Investor {
  id: string;
  name: string;
  website: string;
  location: string;
  stages: string[];
  sectors: string[];
  checkSizeRange: string;
  typicalCheckMin: number; // in USD millions e.g. 0.5
  typicalCheckMax: number; // in USD millions e.g. 3
  leadPreference: 'Lead' | 'Follow' | 'Both';
  targetB2B_B2C: 'B2B' | 'B2C' | 'Both';
  matchScore: number;
  breakdown: InvestorBreakdown;
  matchCategory: InvestorMatchCategory;
  whyTheyMatch: string;
  relevantInvestments: string[];
  potentialProblem: string;
  thesisSummary: string;
  keyPartners: string[];
  recentActivity: string;
  outreach: OutreachAngle;
}

export type InvestorCRMStatus = 
  | 'Researching'
  | 'Planning Outreach'
  | 'Contacted'
  | 'Meeting'
  | 'Passed'
  | 'Interested';

export interface SavedInvestor {
  investorId: string;
  investor: Investor;
  status: InvestorCRMStatus;
  notes: string;
  savedAt: string;
  lastUpdated: string;
}

export interface MatchingCriteria {
  industry?: string;
  stage?: string;
  country?: string;
  amountRaising?: string;
  businessModel?: string;
  targetMarket?: string;
  leadInvestorNeeded?: boolean;
  minScore?: number;
}

export type NavigationTab = 
  | 'landing'
  | 'upload'
  | 'analysis'
  | 'profile'
  | 'investors'
  | 'saved';
