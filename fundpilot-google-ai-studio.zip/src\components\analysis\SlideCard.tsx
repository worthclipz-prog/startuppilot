import React, { useState } from 'react';
import { 
  CheckCircle2, 
  AlertTriangle, 
  Eye, 
  Lightbulb, 
  MessageSquareQuote,
  Sparkles,
  ChevronDown,
  ChevronUp,
  FileText
} from 'lucide-react';
import { SlideAnalysis } from '../../types/index';

interface SlideCardProps {
  slide: SlideAnalysis;
}

export const SlideCard: React.FC<SlideCardProps> = ({ slide }) => {
  const [isOpen, setIsOpen] = useState(true);
  const [showRawText, setShowRawText] = useState(false);

  const getScoreBadge = (score: number) => {
    if (score >= 85) return 'bg-emerald-50 text-emerald-800 border-emerald-200';
    if (score >= 70) return 'bg-zinc-100 text-zinc-800 border-zinc-200';
    if (score >= 50) return 'bg-amber-50 text-amber-800 border-amber-200';
    return 'bg-rose-50 text-rose-800 border-rose-200';
  };

  return (
    <div className="bg-white rounded-xl border border-zinc-200 overflow-hidden shadow-2xs transition-all">
      {/* Header */}
      <div 
        onClick={() => setIsOpen(!isOpen)}
        className="p-4 bg-zinc-50/70 border-b border-zinc-200 flex items-center justify-between cursor-pointer hover:bg-zinc-100/50 select-none"
      >
        <div className="flex items-center gap-3">
          <span className="w-6 h-6 rounded bg-zinc-200 text-zinc-700 text-xs font-mono font-bold flex items-center justify-center">
            {slide.slideNumber}
          </span>
          <div>
            <h4 className="text-sm font-semibold text-zinc-900 tracking-tight">
              {slide.title}
            </h4>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <span className={`text-xs font-mono font-bold px-2 py-0.5 rounded border ${getScoreBadge(slide.score)}`}>
            {slide.score} / 100
          </span>
          <button className="text-zinc-400 hover:text-zinc-600">
            {isOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {isOpen && (
        <div className="p-5 space-y-4 text-xs">
          {/* Top 2-Column: What's Good vs Problems */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* What's Good */}
            <div className="p-3.5 rounded-lg bg-emerald-50/40 border border-emerald-100 space-y-2">
              <div className="flex items-center gap-1.5 font-semibold text-emerald-900">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                <span>What's Good</span>
              </div>
              <ul className="space-y-1 text-zinc-700 list-disc list-inside">
                {slide.whatsGood.map((good, idx) => (
                  <li key={idx} className="leading-relaxed">{good}</li>
                ))}
              </ul>
            </div>

            {/* Problems */}
            <div className="p-3.5 rounded-lg bg-rose-50/40 border border-rose-100 space-y-2">
              <div className="flex items-center gap-1.5 font-semibold text-rose-900">
                <AlertTriangle className="w-3.5 h-3.5 text-rose-600" />
                <span>Problems & Weaknesses</span>
              </div>
              <ul className="space-y-1 text-zinc-700 list-disc list-inside">
                {slide.problems.map((prob, idx) => (
                  <li key={idx} className="leading-relaxed">{prob}</li>
                ))}
              </ul>
            </div>
          </div>

          {/* Investor Reaction Quote */}
          {slide.investorReaction && (
            <div className="p-3 rounded-lg bg-zinc-50 border border-zinc-200 flex items-start gap-2.5">
              <MessageSquareQuote className="w-4 h-4 text-zinc-500 shrink-0 mt-0.5" />
              <div>
                <span className="font-semibold text-zinc-900 block mb-0.5">
                  Investor Reaction
                </span>
                <p className="text-zinc-600 italic leading-relaxed">
                  "{slide.investorReaction}"
                </p>
              </div>
            </div>
          )}

          {/* How to Improve */}
          <div className="p-3 rounded-lg bg-zinc-900 text-zinc-100 space-y-1.5">
            <div className="flex items-center gap-1.5 font-semibold text-zinc-100">
              <Lightbulb className="w-3.5 h-3.5 text-amber-400" />
              <span>How To Improve</span>
            </div>
            <p className="text-zinc-300 leading-relaxed font-normal">
              {slide.howToImprove}
            </p>
          </div>

          {/* Suggested Content Blueprint */}
          {slide.suggestedContent && (
            <div className="p-3.5 rounded-lg border border-dashed border-zinc-300 bg-zinc-50/60 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-zinc-800 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-zinc-500" />
                  Suggested Copy & Layout Blueprint
                </span>
                <span className="text-[10px] font-mono text-zinc-400">AI VC Recommendation</span>
              </div>

              {slide.suggestedContent.headline && (
                <div className="text-zinc-900 font-semibold bg-white p-2 rounded border border-zinc-200">
                  Headline: "{slide.suggestedContent.headline}"
                </div>
              )}

              {slide.suggestedContent.bulletPoints && slide.suggestedContent.bulletPoints.length > 0 && (
                <ul className="space-y-1 text-zinc-600 list-disc list-inside">
                  {slide.suggestedContent.bulletPoints.map((bp, i) => (
                    <li key={i}>{bp}</li>
                  ))}
                </ul>
              )}

              {slide.suggestedContent.visualOrDataAdvice && (
                <p className="text-[11px] text-zinc-500 font-mono pt-1">
                  Visual Layout: {slide.suggestedContent.visualOrDataAdvice}
                </p>
              )}
            </div>
          )}

          {/* Optional Raw Text view */}
          {slide.rawText && (
            <div className="pt-1">
              <button
                type="button"
                onClick={() => setShowRawText(!showRawText)}
                className="text-[11px] font-medium text-zinc-500 hover:text-zinc-800 flex items-center gap-1"
              >
                <FileText className="w-3 h-3" />
                <span>{showRawText ? 'Hide Original Slide Text' : 'View Extracted Slide Text'}</span>
              </button>

              {showRawText && (
                <pre className="mt-2 p-2.5 rounded bg-zinc-100 border border-zinc-200 text-[11px] font-mono text-zinc-700 whitespace-pre-wrap">
                  {slide.rawText}
                </pre>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
