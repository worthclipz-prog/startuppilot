import React, { useState } from 'react';
import { 
  Check, 
  Save, 
  Search, 
  BarChart3, 
  Building2, 
  DollarSign, 
  Users, 
  Target, 
  Globe,
  Sparkles,
  HelpCircle
} from 'lucide-react';
import { StartupProfile } from '../../types/index';

interface StartupProfileEditorProps {
  profile: StartupProfile;
  onSaveProfile: (updatedProfile: StartupProfile) => void;
  onProceedToInvestors: () => void;
  onProceedToAnalysis: () => void;
}

export const StartupProfileEditor: React.FC<StartupProfileEditorProps> = ({
  profile,
  onSaveProfile,
  onProceedToInvestors,
  onProceedToAnalysis
}) => {
  const [formData, setFormData] = useState<StartupProfile>({ ...profile });
  const [isSaved, setIsSaved] = useState(false);

  const handleChange = (field: keyof StartupProfile, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    setIsSaved(false);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveProfile(formData);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2500);
  };

  return (
    <div className="max-w-4xl mx-auto py-8 px-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-zinc-200">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold text-zinc-900 tracking-tight">
              Extracted Startup Profile
            </h2>
            <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-zinc-100 text-zinc-700 font-medium">
              Editable
            </span>
          </div>
          <p className="text-xs text-zinc-500 mt-1">
            Information extracted from your slides. Correct any missing or inaccurate metrics before VC matching.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onProceedToAnalysis}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-md border border-zinc-300 text-xs font-medium text-zinc-700 bg-white hover:bg-zinc-50 transition-colors"
          >
            <BarChart3 className="w-3.5 h-3.5" />
            <span>Deck Analysis</span>
          </button>

          <button
            type="button"
            onClick={onProceedToInvestors}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-md bg-zinc-900 text-xs font-medium text-white hover:bg-zinc-800 transition-colors shadow-xs"
          >
            <Search className="w-3.5 h-3.5" />
            <span>Find Matching VCs →</span>
          </button>
        </div>
      </div>

      <form onSubmit={handleSave} className="space-y-6">
        {/* Core Identity */}
        <div className="bg-white p-5 rounded-xl border border-zinc-200 space-y-4">
          <div className="flex items-center gap-2 text-xs font-semibold text-zinc-900 uppercase tracking-wider">
            <Building2 className="w-4 h-4 text-zinc-500" />
            <span>Company Core Identity</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="block font-medium text-zinc-700 mb-1">Startup Name</label>
              <input
                type="text"
                value={formData.startupName}
                onChange={(e) => handleChange('startupName', e.target.value)}
                className="w-full px-3 py-2 rounded-md border border-zinc-300 text-zinc-900 focus:outline-hidden focus:border-zinc-900 font-medium"
              />
            </div>

            <div>
              <label className="block font-medium text-zinc-700 mb-1">Funding Stage</label>
              <select
                value={formData.stage}
                onChange={(e) => handleChange('stage', e.target.value)}
                className="w-full px-3 py-2 rounded-md border border-zinc-300 text-zinc-900 focus:outline-hidden focus:border-zinc-900"
              >
                <option value="Pre-Seed">Pre-Seed</option>
                <option value="Seed">Seed</option>
                <option value="Series A">Series A</option>
                <option value="Series B">Series B</option>
                <option value="Growth">Growth</option>
              </select>
            </div>

            <div className="md:col-span-2">
              <label className="block font-medium text-zinc-700 mb-1">One-Sentence Elevator Pitch / Description</label>
              <input
                type="text"
                value={formData.description}
                onChange={(e) => handleChange('description', e.target.value)}
                className="w-full px-3 py-2 rounded-md border border-zinc-300 text-zinc-900 focus:outline-hidden focus:border-zinc-900"
              />
            </div>

            <div>
              <label className="block font-medium text-zinc-700 mb-1">Industry</label>
              <input
                type="text"
                value={formData.industry}
                onChange={(e) => handleChange('industry', e.target.value)}
                className="w-full px-3 py-2 rounded-md border border-zinc-300 text-zinc-900 focus:outline-hidden focus:border-zinc-900"
              />
            </div>

            <div>
              <label className="block font-medium text-zinc-700 mb-1">Sub-Industry / Focus Area</label>
              <input
                type="text"
                value={formData.subIndustry}
                onChange={(e) => handleChange('subIndustry', e.target.value)}
                className="w-full px-3 py-2 rounded-md border border-zinc-300 text-zinc-900 focus:outline-hidden focus:border-zinc-900"
              />
            </div>

            <div>
              <label className="block font-medium text-zinc-700 mb-1">Geography / HQ Location</label>
              <input
                type="text"
                value={formData.geography}
                onChange={(e) => handleChange('geography', e.target.value)}
                className="w-full px-3 py-2 rounded-md border border-zinc-300 text-zinc-900 focus:outline-hidden focus:border-zinc-900"
              />
            </div>

            <div>
              <label className="block font-medium text-zinc-700 mb-1">Business Model</label>
              <input
                type="text"
                value={formData.businessModel}
                onChange={(e) => handleChange('businessModel', e.target.value)}
                className="w-full px-3 py-2 rounded-md border border-zinc-300 text-zinc-900 focus:outline-hidden focus:border-zinc-900"
              />
            </div>
          </div>
        </div>

        {/* Financials & Round Target */}
        <div className="bg-white p-5 rounded-xl border border-zinc-200 space-y-4">
          <div className="flex items-center gap-2 text-xs font-semibold text-zinc-900 uppercase tracking-wider">
            <DollarSign className="w-4 h-4 text-zinc-500" />
            <span>Fundraise Target & Financial Metrics</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
            <div>
              <label className="block font-medium text-zinc-700 mb-1">Amount Being Raised</label>
              <input
                type="text"
                placeholder="e.g. $2.0M"
                value={formData.amountRaising}
                onChange={(e) => handleChange('amountRaising', e.target.value)}
                className="w-full px-3 py-2 rounded-md border border-zinc-300 text-zinc-900 focus:outline-hidden focus:border-zinc-900 font-mono font-medium"
              />
            </div>

            <div>
              <label className="block font-medium text-zinc-700 mb-1">Annual Recurring Revenue (ARR)</label>
              <input
                type="text"
                placeholder="e.g. $600k ARR or Not provided"
                value={formData.arr}
                onChange={(e) => handleChange('arr', e.target.value)}
                className="w-full px-3 py-2 rounded-md border border-zinc-300 text-zinc-900 focus:outline-hidden focus:border-zinc-900 font-mono"
              />
            </div>

            <div>
              <label className="block font-medium text-zinc-700 mb-1">Monthly Recurring Revenue (MRR)</label>
              <input
                type="text"
                placeholder="e.g. $45k MRR"
                value={formData.mrr}
                onChange={(e) => handleChange('mrr', e.target.value)}
                className="w-full px-3 py-2 rounded-md border border-zinc-300 text-zinc-900 focus:outline-hidden focus:border-zinc-900 font-mono"
              />
            </div>

            <div>
              <label className="block font-medium text-zinc-700 mb-1">MoM / YoY Growth Rate</label>
              <input
                type="text"
                placeholder="e.g. 25% MoM"
                value={formData.growth}
                onChange={(e) => handleChange('growth', e.target.value)}
                className="w-full px-3 py-2 rounded-md border border-zinc-300 text-zinc-900 focus:outline-hidden focus:border-zinc-900"
              />
            </div>

            <div>
              <label className="block font-medium text-zinc-700 mb-1">Paying Customers</label>
              <input
                type="text"
                placeholder="e.g. 18 enterprise contracts"
                value={formData.numberOfCustomers}
                onChange={(e) => handleChange('numberOfCustomers', e.target.value)}
                className="w-full px-3 py-2 rounded-md border border-zinc-300 text-zinc-900 focus:outline-hidden focus:border-zinc-900"
              />
            </div>

            <div>
              <label className="block font-medium text-zinc-700 mb-1">Total Users / Signups</label>
              <input
                type="text"
                placeholder="e.g. 24,000 users"
                value={formData.numberOfUsers}
                onChange={(e) => handleChange('numberOfUsers', e.target.value)}
                className="w-full px-3 py-2 rounded-md border border-zinc-300 text-zinc-900 focus:outline-hidden focus:border-zinc-900"
              />
            </div>

            <div>
              <label className="block font-medium text-zinc-700 mb-1">Market Size (TAM/SAM)</label>
              <input
                type="text"
                placeholder="e.g. $48B TAM"
                value={formData.marketSize}
                onChange={(e) => handleChange('marketSize', e.target.value)}
                className="w-full px-3 py-2 rounded-md border border-zinc-300 text-zinc-900 focus:outline-hidden focus:border-zinc-900"
              />
            </div>

            <div>
              <label className="block font-medium text-zinc-700 mb-1">Previous Funding</label>
              <input
                type="text"
                placeholder="e.g. $500k Pre-Seed / Bootstrapped"
                value={formData.previousFunding}
                onChange={(e) => handleChange('previousFunding', e.target.value)}
                className="w-full px-3 py-2 rounded-md border border-zinc-300 text-zinc-900 focus:outline-hidden focus:border-zinc-900"
              />
            </div>

            <div className="flex items-center pt-5">
              <label className="flex items-center gap-2 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={formData.leadInvestorNeeded}
                  onChange={(e) => handleChange('leadInvestorNeeded', e.target.checked)}
                  className="rounded border-zinc-300 text-zinc-900 focus:ring-zinc-900 w-4 h-4"
                />
                <span className="font-medium text-zinc-800">Lead Investor Needed?</span>
              </label>
            </div>
          </div>
        </div>

        {/* Narrative & Market Positioning */}
        <div className="bg-white p-5 rounded-xl border border-zinc-200 space-y-4">
          <div className="flex items-center gap-2 text-xs font-semibold text-zinc-900 uppercase tracking-wider">
            <Target className="w-4 h-4 text-zinc-500" />
            <span>Market Positioning & Story</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="block font-medium text-zinc-700 mb-1">Problem Statement</label>
              <textarea
                rows={3}
                value={formData.problem}
                onChange={(e) => handleChange('problem', e.target.value)}
                className="w-full px-3 py-2 rounded-md border border-zinc-300 text-zinc-900 focus:outline-hidden focus:border-zinc-900"
              />
            </div>

            <div>
              <label className="block font-medium text-zinc-700 mb-1">Solution & Unfair Value</label>
              <textarea
                rows={3}
                value={formData.solution}
                onChange={(e) => handleChange('solution', e.target.value)}
                className="w-full px-3 py-2 rounded-md border border-zinc-300 text-zinc-900 focus:outline-hidden focus:border-zinc-900"
              />
            </div>

            <div>
              <label className="block font-medium text-zinc-700 mb-1">Target Customer / ICP</label>
              <input
                type="text"
                value={formData.targetCustomer}
                onChange={(e) => handleChange('targetCustomer', e.target.value)}
                className="w-full px-3 py-2 rounded-md border border-zinc-300 text-zinc-900 focus:outline-hidden focus:border-zinc-900"
              />
            </div>

            <div>
              <label className="block font-medium text-zinc-700 mb-1">Competitors / Incumbents</label>
              <input
                type="text"
                value={formData.competitors}
                onChange={(e) => handleChange('competitors', e.target.value)}
                className="w-full px-3 py-2 rounded-md border border-zinc-300 text-zinc-900 focus:outline-hidden focus:border-zinc-900"
              />
            </div>

            <div className="md:col-span-2">
              <label className="block font-medium text-zinc-700 mb-1">Founders & Key Team Background</label>
              <input
                type="text"
                value={formData.team}
                onChange={(e) => handleChange('team', e.target.value)}
                className="w-full px-3 py-2 rounded-md border border-zinc-300 text-zinc-900 focus:outline-hidden focus:border-zinc-900"
              />
            </div>
          </div>
        </div>

        {/* Save Bar */}
        <div className="flex items-center justify-end gap-3 pt-2">
          <button
            type="submit"
            id="btn-save-startup-profile"
            className="flex items-center gap-2 px-5 py-2 rounded-md bg-zinc-900 text-white text-xs font-semibold hover:bg-zinc-800 transition-colors shadow-xs"
          >
            {isSaved ? (
              <>
                <Check className="w-4 h-4 text-emerald-400" />
                <span>Profile Saved!</span>
              </>
            ) : (
              <>
                <Save className="w-4 h-4" />
                <span>Save Profile Changes</span>
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};
