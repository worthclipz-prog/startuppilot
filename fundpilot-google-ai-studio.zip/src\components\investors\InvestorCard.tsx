import React from 'react';
import { 
  Investor, 
  InvestorCRMStatus 
} from '../../types/index';
import { 
  ExternalLink, 
  Bookmark, 
  BookmarkCheck, 
  ArrowRight, 
  DollarSign, 
  MapPin, 
  Tag, 
  ShieldCheck,
  Building2
} from 'lucide-react';

interface InvestorCardProps {
  investor: Investor;
  isSaved: boolean;
  onViewDetails: (investor: Investor) => void;
  onToggleSave: (investor: Investor) => void;
}

export const InvestorCard: React.FC<InvestorCardProps> = ({
  investor,
  isSaved,
  onViewDetails,
  onToggleSave
}) => {
  const getScoreBadge = (score: number) => {
    if (score >= 90) return 'bg-emerald-50 text-emerald-800 border-emerald-300 font-bold';
    if (score >= 80) return 'bg-zinc-900 text-white font-bold';
    return 'bg-zinc-100 text-zinc-800 border-zinc-200';
  };

  return (
    <div className="bg-white rounded-xl border border-zinc-200 p-5 shadow-2xs hover:border-zinc-300 transition-all flex flex-col justify-between space-y-4">
      <div className="space-y-3">
        {/* Top Header: VC Name, Location, Match Score */}
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <h4 className="text-base font-bold text-zinc-900 tracking-tight">
                {investor.name}
              </h4>
              <a
                href={investor.website}
                target="_blank"
                rel="noreferrer"
                className="text-zinc-400 hover:text-zinc-700"
              >
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
            <p className="text-xs text-zinc-500 flex items-center gap-1 mt-0.5 font-mono">
              <MapPin className="w-3 h-3 text-zinc-400" />
              <span>{investor.location}</span>
            </p>
          </div>

          <div className="flex flex-col items-end">
            <span className={`text-xs font-mono px-2 py-1 rounded border ${getScoreBadge(investor.matchScore)}`}>
              {investor.matchScore}% Match
            </span>
            <span className="text-[10px] text-zinc-400 font-mono mt-0.5 capitalize">
              {investor.matchCategory} Fit
            </span>
          </div>
        </div>

        {/* Stages, Check Size, & Focus Tags */}
        <div className="grid grid-cols-2 gap-2 text-xs pt-1">
          <div className="p-2 rounded bg-zinc-50 border border-zinc-100">
            <span className="text-[10px] text-zinc-400 font-mono block">Stage Focus</span>
            <span className="font-semibold text-zinc-800">{investor.stages.join(', ')}</span>
          </div>

          <div className="p-2 rounded bg-zinc-50 border border-zinc-100">
            <span className="text-[10px] text-zinc-400 font-mono block">Typical Check Size</span>
            <span className="font-semibold text-zinc-800">{investor.checkSizeRange}</span>
          </div>
        </div>

        {/* Sectors */}
        <div className="space-y-1">
          <span className="text-[10px] font-mono uppercase text-zinc-400 block">Sectors</span>
          <div className="flex flex-wrap gap-1">
            {investor.sectors.map((sec, idx) => (
              <span
                key={idx}
                className="text-[10px] px-1.5 py-0.5 rounded bg-zinc-100 text-zinc-700 font-mono"
              >
                {sec}
              </span>
            ))}
          </div>
        </div>

        {/* Why They Match (1-2 sentences) */}
        <div className="p-2.5 rounded-lg bg-zinc-50/80 border border-zinc-200 text-xs text-zinc-700 leading-relaxed">
          <span className="font-semibold text-zinc-900 block mb-0.5">
            Why They Match
          </span>
          <p className="line-clamp-2">
            {investor.whyTheyMatch}
          </p>
        </div>

        {/* Relevant Portfolio Highlights */}
        {investor.relevantInvestments && investor.relevantInvestments.length > 0 && (
          <div className="text-[11px] text-zinc-500">
            <span className="font-medium text-zinc-700">Portfolio: </span>
            <span>{investor.relevantInvestments.slice(0, 4).join(', ')}</span>
          </div>
        )}
      </div>

      {/* Action Buttons: View Details & Save */}
      <div className="pt-2 border-t border-zinc-100 flex items-center justify-between gap-2">
        <button
          onClick={() => onToggleSave(investor)}
          id={`btn-save-investor-${investor.id}`}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-semibold transition-colors ${
            isSaved
              ? 'bg-zinc-900 text-white'
              : 'border border-zinc-300 text-zinc-700 bg-white hover:bg-zinc-50'
          }`}
        >
          {isSaved ? (
            <>
              <BookmarkCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>Saved</span>
            </>
          ) : (
            <>
              <Bookmark className="w-3.5 h-3.5" />
              <span>Save</span>
            </>
          )}
        </button>

        <button
          onClick={() => onViewDetails(investor)}
          id={`btn-details-investor-${investor.id}`}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-zinc-100 hover:bg-zinc-200 text-zinc-900 text-xs font-semibold transition-colors"
        >
          <span>View Details & Outreach</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
