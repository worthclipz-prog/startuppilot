import { config } from 'dotenv';

// dotenv does not load .env.local automatically. Load it first so local-only
// secrets override the optional shared .env file.
config({ path: '.env.local' });
config();
