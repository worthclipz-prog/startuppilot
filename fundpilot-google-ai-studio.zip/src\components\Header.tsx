import React from 'react';
import { FileUp, Sparkles } from 'lucide-react';
import { NavigationTab, PitchDeckReport } from '../types/index';

interface HeaderProps {
  activeTab: NavigationTab;
  onNavigate: (tab: NavigationTab) => void;
  savedCount: number;
  hasReport: boolean;
  report?: PitchDeckReport | null;
  onUploadNew?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  onNavigate,
  savedCount,
  hasReport,
  report,
  onUploadNew
}) => {
  const getTitle = () => {
    switch (activeTab) {
      case 'landing':
        return 'Fundraising Copilot';
      case 'upload':
        return 'Upload & Analyze Pitch Deck';
      case 'analysis':
        return 'Pitch Deck Score & VC Critique';
      case 'profile':
        return 'Startup Profile Data';
      case 'investors':
        return 'Investor Matching';
      case 'saved':
        return 'Investor Pipeline CRM';
      default:
        return 'FundPilot';
    }
  };

  return (
    <header className="h-14 border-b border-zinc-200 bg-white/90 backdrop-blur-xs sticky top-0 z-20 px-6 flex items-center justify-between">
      <div className="flex items-center gap-3">
        <h1 className="text-sm font-bold text-zinc-900 tracking-tight">
          {getTitle()}
        </h1>
        {report && (
          <div className="flex items-center gap-2 border-l border-zinc-200 pl-3">
            <span className="text-xs text-zinc-500 font-mono">
              {report.fileName}
            </span>
            <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-zinc-100 text-zinc-600 font-medium">
              {report.slideCount} slides
            </span>
          </div>
        )}
      </div>

      <div className="flex items-center gap-3">
        <button
          onClick={() => (onUploadNew ? onUploadNew() : onNavigate('upload'))}
          id="btn-header-upload-deck"
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-semibold text-zinc-700 bg-zinc-100 hover:bg-zinc-200 transition-colors"
        >
          <FileUp className="w-3.5 h-3.5" />
          <span>Upload Deck</span>
        </button>
      </div>
    </header>
  );
};
