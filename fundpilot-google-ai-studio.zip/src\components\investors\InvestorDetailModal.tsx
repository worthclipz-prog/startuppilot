import React, { useState } from 'react';
import { 
  X, 
  ExternalLink, 
  Copy, 
  Check, 
  Send, 
  Linkedin, 
  Mail, 
  Users, 
  AlertTriangle, 
  Bookmark, 
  BookmarkCheck,
  Building, 
  Globe, 
  DollarSign, 
  ShieldCheck,
  Sparkles
} from 'lucide-react';
import { Investor, StartupProfile, InvestorCRMStatus } from '../../types/index';

interface InvestorDetailModalProps {
  investor: Investor;
  startupProfile: StartupProfile;
  isSaved: boolean;
  onClose: () => void;
  onSave: (investor: Investor, status?: InvestorCRMStatus, notes?: string) => void;
}

export const InvestorDetailModal: React.FC<InvestorDetailModalProps> = ({
  investor,
  startupProfile,
  isSaved,
  onClose,
  onSave
}) => {
  const [activeOutreachTab, setActiveOutreachTab] = useState<'coldEmail' | 'linkedIn' | 'warmIntro'>('coldEmail');
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [crmStatus, setCrmStatus] = useState<InvestorCRMStatus>('Researching');
  const [notes, setNotes] = useState('');

  const copyToClipboard = (text: string, field: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(field);
    setTimeout(() => setCopiedField(null), 2000);
  };

  const handleSaveWithStatus = () => {
    onSave(investor, crmStatus, notes);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-xl border border-zinc-200 max-w-3xl w-full shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
        {/* Modal Header */}
        <div className="p-6 bg-zinc-900 text-white flex items-start justify-between border-b border-zinc-800">
          <div className="space-y-1">
            <div className="flex items-center gap-3">
              <h2 className="text-xl font-bold tracking-tight">
                {investor.name}
              </h2>
              <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                {investor.matchScore}% Match
              </span>
            </div>

            <div className="flex flex-wrap items-center gap-3 text-xs text-zinc-400 font-mono pt-1">
              <span className="flex items-center gap-1">
                <Globe className="w-3.5 h-3.5" />
                {investor.location}
              </span>
              <span>•</span>
              <span className="flex items-center gap-1">
                <DollarSign className="w-3.5 h-3.5" />
                Check: {investor.checkSizeRange}
              </span>
              <span>•</span>
              <a
                href={investor.website}
                target="_blank"
                rel="noreferrer"
                className="text-zinc-300 hover:text-white inline-flex items-center gap-1 underline"
              >
                Website <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1 rounded-md text-zinc-400 hover:text-white hover:bg-zinc-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6 text-xs text-zinc-800">
          {/* Fit Breakdown Matrix */}
          <div className="p-4 rounded-lg bg-zinc-50 border border-zinc-200 space-y-3">
            <h4 className="font-semibold text-zinc-900 text-xs uppercase tracking-wider">
              Match Fit Breakdown
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 text-center">
              <div className="p-2 bg-white rounded border border-zinc-200">
                <span className="text-[10px] text-zinc-400 uppercase font-mono block">Stage Fit</span>
                <span className="text-sm font-bold font-mono text-zinc-900">{investor.breakdown.stageFit}%</span>
              </div>
              <div className="p-2 bg-white rounded border border-zinc-200">
                <span className="text-[10px] text-zinc-400 uppercase font-mono block">Sector Fit</span>
                <span className="text-sm font-bold font-mono text-zinc-900">{investor.breakdown.sectorFit}%</span>
              </div>
              <div className="p-2 bg-white rounded border border-zinc-200">
                <span className="text-[10px] text-zinc-400 uppercase font-mono block">Check Size</span>
                <span className="text-sm font-bold font-mono text-zinc-900">{investor.breakdown.checkSizeFit}%</span>
              </div>
              <div className="p-2 bg-white rounded border border-zinc-200">
                <span className="text-[10px] text-zinc-400 uppercase font-mono block">Geography</span>
                <span className="text-sm font-bold font-mono text-zinc-900">{investor.breakdown.geographyFit}%</span>
              </div>
              <div className="p-2 bg-white rounded border border-zinc-200 col-span-2 sm:col-span-1">
                <span className="text-[10px] text-zinc-400 uppercase font-mono block">Portfolio</span>
                <span className="text-sm font-bold font-mono text-zinc-900">{investor.breakdown.portfolioFit}%</span>
              </div>
            </div>
          </div>

          {/* Why They Match */}
          <div className="space-y-1.5">
            <h4 className="font-bold text-zinc-900 text-xs uppercase tracking-wider flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>Why They Match</span>
            </h4>
            <p className="p-3 rounded-lg bg-emerald-50/40 border border-emerald-100 text-zinc-800 leading-relaxed font-medium">
              {investor.whyTheyMatch}
            </p>
          </div>

          {/* Potential Objections / Conflicts */}
          <div className="space-y-1.5">
            <h4 className="font-bold text-zinc-900 text-xs uppercase tracking-wider flex items-center gap-1.5">
              <AlertTriangle className="w-4 h-4 text-amber-600" />
              <span>Potential Problem / Partner Objections</span>
            </h4>
            <p className="p-3 rounded-lg bg-amber-50/40 border border-amber-100 text-zinc-800 leading-relaxed">
              {investor.potentialProblem}
            </p>
          </div>

          {/* Relevant Investments & Partners */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-3.5 rounded-lg border border-zinc-200 space-y-2">
              <h5 className="font-semibold text-zinc-900">Relevant Portfolio Investments</h5>
              <div className="flex flex-wrap gap-1.5">
                {investor.relevantInvestments.map((inv, idx) => (
                  <span
                    key={idx}
                    className="px-2 py-0.5 rounded bg-zinc-100 border border-zinc-200 font-mono text-[11px] text-zinc-700"
                  >
                    {inv}
                  </span>
                ))}
              </div>
            </div>

            <div className="p-3.5 rounded-lg border border-zinc-200 space-y-2">
              <h5 className="font-semibold text-zinc-900">Key Partners</h5>
              <div className="flex flex-wrap gap-1.5">
                {investor.keyPartners.map((partner, idx) => (
                  <span
                    key={idx}
                    className="px-2 py-0.5 rounded bg-zinc-100 border border-zinc-200 text-[11px] text-zinc-800 font-medium"
                  >
                    {partner}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Section 22: Fundraising Outreach Angle & Message Generator */}
          <div className="border-t border-zinc-200 pt-5 space-y-4">
            <div className="space-y-1">
              <h4 className="text-sm font-bold text-zinc-900 tracking-tight flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-zinc-700" />
                <span>Fundraising Outreach Angle</span>
              </h4>
              <p className="text-zinc-600">
                {investor.outreach.angle}
              </p>
            </div>

            {/* Outreach Sub-Tabs */}
            <div className="flex items-center gap-2 border-b border-zinc-200 pb-2">
              <button
                onClick={() => setActiveOutreachTab('coldEmail')}
                className={`px-3 py-1.5 rounded-md font-semibold transition-colors flex items-center gap-1.5 ${
                  activeOutreachTab === 'coldEmail'
                    ? 'bg-zinc-900 text-white'
                    : 'text-zinc-600 hover:bg-zinc-100'
                }`}
              >
                <Mail className="w-3.5 h-3.5" />
                <span>Cold Email</span>
              </button>

              <button
                onClick={() => setActiveOutreachTab('linkedIn')}
                className={`px-3 py-1.5 rounded-md font-semibold transition-colors flex items-center gap-1.5 ${
                  activeOutreachTab === 'linkedIn'
                    ? 'bg-zinc-900 text-white'
                    : 'text-zinc-600 hover:bg-zinc-100'
                }`}
              >
                <Linkedin className="w-3.5 h-3.5" />
                <span>LinkedIn Message</span>
              </button>

              <button
                onClick={() => setActiveOutreachTab('warmIntro')}
                className={`px-3 py-1.5 rounded-md font-semibold transition-colors flex items-center gap-1.5 ${
                  activeOutreachTab === 'warmIntro'
                    ? 'bg-zinc-900 text-white'
                    : 'text-zinc-600 hover:bg-zinc-100'
                }`}
              >
                <Users className="w-3.5 h-3.5" />
                <span>Warm Intro Blurb</span>
              </button>
            </div>

            {/* Message Box */}
            <div className="bg-zinc-50 border border-zinc-200 rounded-lg p-4 space-y-3 relative">
              {activeOutreachTab === 'coldEmail' && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between pb-2 border-b border-zinc-200">
                    <span className="font-mono text-[11px] text-zinc-500 font-semibold">
                      Subject: {investor.outreach.coldEmail.subject}
                    </span>
                    <button
                      onClick={() => copyToClipboard(`Subject: ${investor.outreach.coldEmail.subject}\n\n${investor.outreach.coldEmail.body}`, 'coldEmail')}
                      className="inline-flex items-center gap-1 px-2 py-1 rounded bg-white border border-zinc-300 text-zinc-700 hover:bg-zinc-50 font-medium"
                    >
                      {copiedField === 'coldEmail' ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                      <span>{copiedField === 'coldEmail' ? 'Copied' : 'Copy Email'}</span>
                    </button>
                  </div>
                  <pre className="font-sans text-xs text-zinc-800 whitespace-pre-wrap leading-relaxed">
                    {investor.outreach.coldEmail.body}
                  </pre>
                </div>
              )}

              {activeOutreachTab === 'linkedIn' && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between pb-2 border-b border-zinc-200">
                    <span className="text-[11px] font-mono text-zinc-500">
                      Under 280 characters • High-signal connection note
                    </span>
                    <button
                      onClick={() => copyToClipboard(investor.outreach.linkedIn, 'linkedIn')}
                      className="inline-flex items-center gap-1 px-2 py-1 rounded bg-white border border-zinc-300 text-zinc-700 hover:bg-zinc-50 font-medium"
                    >
                      {copiedField === 'linkedIn' ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                      <span>{copiedField === 'linkedIn' ? 'Copied' : 'Copy'}</span>
                    </button>
                  </div>
                  <p className="text-xs text-zinc-800 leading-relaxed font-sans">
                    {investor.outreach.linkedIn}
                  </p>
                </div>
              )}

              {activeOutreachTab === 'warmIntro' && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between pb-2 border-b border-zinc-200">
                    <span className="text-[11px] font-mono text-zinc-500">
                      Forwardable blurb for mutual connections
                    </span>
                    <button
                      onClick={() => copyToClipboard(`${investor.outreach.warmIntro.requestSubject}\n\n${investor.outreach.warmIntro.blurb}`, 'warmIntro')}
                      className="inline-flex items-center gap-1 px-2 py-1 rounded bg-white border border-zinc-300 text-zinc-700 hover:bg-zinc-50 font-medium"
                    >
                      {copiedField === 'warmIntro' ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                      <span>{copiedField === 'warmIntro' ? 'Copied' : 'Copy Blurb'}</span>
                    </button>
                  </div>
                  <p className="text-xs text-zinc-800 leading-relaxed font-sans">
                    {investor.outreach.warmIntro.blurb}
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Modal Footer / Save to CRM */}
        <div className="p-4 bg-zinc-50 border-t border-zinc-200 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-zinc-700">Pipeline Status:</span>
            <select
              value={crmStatus}
              onChange={(e) => setCrmStatus(e.target.value as InvestorCRMStatus)}
              className="text-xs px-2.5 py-1.5 rounded border border-zinc-300 bg-white font-medium focus:outline-hidden"
            >
              <option value="Researching">Researching</option>
              <option value="Planning Outreach">Planning Outreach</option>
              <option value="Contacted">Contacted</option>
              <option value="Meeting">Meeting</option>
              <option value="Passed">Passed</option>
              <option value="Interested">Interested</option>
            </select>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-3.5 py-1.5 rounded-md border border-zinc-300 text-xs font-medium text-zinc-700 bg-white hover:bg-zinc-100"
            >
              Close
            </button>

            <button
              onClick={handleSaveWithStatus}
              id="btn-modal-save-investor"
              className="flex items-center gap-1.5 px-4 py-1.5 rounded-md bg-zinc-900 text-xs font-semibold text-white hover:bg-zinc-800 shadow-xs"
            >
              {isSaved ? <BookmarkCheck className="w-4 h-4 text-emerald-400" /> : <Bookmark className="w-4 h-4" />}
              <span>{isSaved ? 'Saved to Pipeline' : 'Save Investor'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
