import React, { useState, useEffect } from 'react';
import { 
  PitchDeckReport, 
  StartupProfile, 
  SavedInvestor, 
  Investor, 
  InvestorCRMStatus,
  NavigationTab
} from './types/index';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { LandingView } from './components/landing/LandingView';
import { UploadDeckView } from './components/pitch/UploadDeckView';
import { StartupProfileEditor } from './components/pitch/StartupProfileEditor';
import { AnalysisDashboard } from './components/analysis/AnalysisDashboard';
import { FindInvestorsView } from './components/investors/FindInvestorsView';
import { SavedInvestorsView } from './components/investors/SavedInvestorsView';

const SAVED_INVESTORS_KEY = 'fundpilot_saved_investors_v1';
const REPORT_STORAGE_KEY = 'fundpilot_current_report_v1';

export default function App() {
  const [activeTab, setActiveTab] = useState<NavigationTab>('landing');
  const [report, setReport] = useState<PitchDeckReport | null>(null);
  const [startupProfile, setStartupProfile] = useState<StartupProfile | null>(null);
  const [savedInvestors, setSavedInvestors] = useState<SavedInvestor[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [analysisProgress, setAnalysisProgress] = useState<number>(0);
  const [analysisStatusText, setAnalysisStatusText] = useState<string>('');
  const [error, setError] = useState<string | null>(null);

  // Load saved state on mount
  useEffect(() => {
    try {
      const storedSaved = localStorage.getItem(SAVED_INVESTORS_KEY);
      if (storedSaved) {
        setSavedInvestors(JSON.parse(storedSaved));
      }

      const storedReport = localStorage.getItem(REPORT_STORAGE_KEY);
      if (storedReport) {
        const parsed = JSON.parse(storedReport) as PitchDeckReport;
        setReport(parsed);
        setStartupProfile(parsed.startupProfile);
      }
    } catch (e) {
      console.warn('Error loading localStorage state:', e);
    }
  }, []);

  // Sync saved investors to localStorage
  const saveSavedInvestorsToStorage = (updated: SavedInvestor[]) => {
    setSavedInvestors(updated);
    try {
      localStorage.setItem(SAVED_INVESTORS_KEY, JSON.stringify(updated));
    } catch (e) {
      console.warn('Error persisting saved investors:', e);
    }
  };

  const handleUploadFile = async (file: File) => {
    if (file.size > 4 * 1024 * 1024) {
      setError('Please choose a file smaller than 4 MB (application upload limit).');
      return;
    }

    setIsAnalyzing(true);
    setError(null);
    setAnalysisProgress(15);
    setAnalysisStatusText('Extracting deck text & slide structure...');

    try {
      const formData = new FormData();
      formData.append('deck', file);

      setAnalysisProgress(40);
      setAnalysisStatusText('Analyzing slides with NVIDIA NIM AI...');

      const res = await fetch('/api/deck/upload', {
        method: 'POST',
        body: formData
      });

      setAnalysisProgress(75);
      setAnalysisStatusText('Evaluating VC readiness, red flags & investment thesis...');

      if (!res.ok) {
        const errJson = await res.json().catch(() => ({}));
        throw new Error(errJson.error || `Server returned error ${res.status}`);
      }

      const reportData: PitchDeckReport = await res.json();
      setAnalysisProgress(100);
      setAnalysisStatusText('Analysis complete!');

      setReport(reportData);
      setStartupProfile(reportData.startupProfile);
      try {
        localStorage.setItem(REPORT_STORAGE_KEY, JSON.stringify(reportData));
      } catch (e) {
        console.warn('Failed to cache report:', e);
      }

      setTimeout(() => {
        setIsAnalyzing(false);
        setActiveTab('analysis');
      }, 500);
    } catch (err: any) {
      console.error('Deck upload error:', err);
      setIsAnalyzing(false);
      setError(err.message || 'Failed to analyze deck. Please try again.');
    }
  };

  const handleAnalyzeRawText = async (slideTexts: string[], fileName: string) => {
    setIsAnalyzing(true);
    setError(null);
    setAnalysisProgress(20);
    setAnalysisStatusText('Processing slide content...');

    try {
      setAnalysisProgress(50);
      setAnalysisStatusText('Running AI valuation and slide analysis...');

      const res = await fetch('/api/deck/analyze-text', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ slides: slideTexts, fileName })
      });

      if (!res.ok) {
        const errJson = await res.json().catch(() => ({}));
        throw new Error(errJson.error || `Server returned status ${res.status}`);
      }

      const reportData: PitchDeckReport = await res.json();
      setAnalysisProgress(100);
      setAnalysisStatusText('Analysis ready!');

      setReport(reportData);
      setStartupProfile(reportData.startupProfile);
      try {
        localStorage.setItem(REPORT_STORAGE_KEY, JSON.stringify(reportData));
      } catch (e) {}

      setTimeout(() => {
        setIsAnalyzing(false);
        setActiveTab('analysis');
      }, 400);
    } catch (err: any) {
      console.error('Raw text analysis error:', err);
      setIsAnalyzing(false);
      setError(err.message || 'Failed to analyze text. Please try again.');
    }
  };

  const handleSelectSampleDeck = async (deckId: string) => {
    setIsAnalyzing(true);
    setError(null);
    setAnalysisProgress(25);
    setAnalysisStatusText('Loading sample pitch deck...');

    try {
      setAnalysisProgress(60);
      setAnalysisStatusText('Evaluating slide scores & VC criteria...');

      const res = await fetch(`/api/deck/sample/${deckId}`);
      if (!res.ok) {
        throw new Error('Failed to load sample deck analysis');
      }

      const reportData: PitchDeckReport = await res.json();
      setAnalysisProgress(100);
      setAnalysisStatusText('Ready!');

      setReport(reportData);
      setStartupProfile(reportData.startupProfile);
      try {
        localStorage.setItem(REPORT_STORAGE_KEY, JSON.stringify(reportData));
      } catch (e) {
        console.warn('Failed to cache report:', e);
      }

      setTimeout(() => {
        setIsAnalyzing(false);
        setActiveTab('analysis');
      }, 400);
    } catch (err: any) {
      console.error('Sample deck load error:', err);
      setIsAnalyzing(false);
      setError(err.message || 'Failed to load sample deck');
    }
  };

  const handleSaveInvestor = (investor: Investor, status: InvestorCRMStatus = 'Researching', notes = '') => {
    const existingIdx = savedInvestors.findIndex(s => s.investorId === investor.id);
    let updated: SavedInvestor[];
    const now = new Date().toISOString();

    if (existingIdx !== -1) {
      updated = [...savedInvestors];
      updated[existingIdx] = {
        ...updated[existingIdx],
        status,
        notes: notes || updated[existingIdx].notes,
        lastUpdated: now,
        investor
      };
    } else {
      updated = [
        ...savedInvestors,
        {
          investorId: investor.id,
          savedAt: now,
          lastUpdated: now,
          status,
          notes,
          investor
        }
      ];
    }

    saveSavedInvestorsToStorage(updated);
  };

  const handleRemoveSavedInvestor = (investorId: string) => {
    const updated = savedInvestors.filter(s => s.investorId !== investorId);
    saveSavedInvestorsToStorage(updated);
  };

  const handleUpdateStatus = (investorId: string, status: InvestorCRMStatus) => {
    const updated = savedInvestors.map(s => 
      s.investorId === investorId ? { ...s, status, lastUpdated: new Date().toISOString() } : s
    );
    saveSavedInvestorsToStorage(updated);
  };

  const handleUpdateNotes = (investorId: string, notes: string) => {
    const updated = savedInvestors.map(s => 
      s.investorId === investorId ? { ...s, notes, lastUpdated: new Date().toISOString() } : s
    );
    saveSavedInvestorsToStorage(updated);
  };

  const handleSaveProfile = (updatedProfile: StartupProfile) => {
    setStartupProfile(updatedProfile);
    if (report) {
      const updatedReport = { ...report, startupProfile: updatedProfile };
      setReport(updatedReport);
      try {
        localStorage.setItem(REPORT_STORAGE_KEY, JSON.stringify(updatedReport));
      } catch (e) {}
    }
    setActiveTab('investors');
  };

  return (
    <div className="min-h-screen bg-zinc-50 flex flex-col text-zinc-900 font-sans antialiased">
      {/* Top Application Header */}
      <Header
        activeTab={activeTab}
        onNavigate={setActiveTab}
        savedCount={savedInvestors.length}
        hasReport={Boolean(report)}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex">
        {/* Persistent Side Navigation for fast workflow */}
        <Sidebar
          activeTab={activeTab}
          onNavigate={setActiveTab}
          savedCount={savedInvestors.length}
          hasReport={Boolean(report)}
        />

        <main className="flex-1 overflow-y-auto pb-16">
          {error && (
            <div className="max-w-5xl mx-auto mt-6 px-6">
              <div className="p-4 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-900 flex items-center justify-between">
                <span>{error}</span>
                <button
                  onClick={() => setError(null)}
                  className="font-bold underline text-rose-700 hover:text-rose-950"
                >
                  Dismiss
                </button>
              </div>
            </div>
          )}

          {/* VIEW ROUTING */}
          {activeTab === 'landing' && (
            <LandingView
              onGetStarted={() => setActiveTab('upload')}
              onStartAnalysis={() => setActiveTab('upload')}
              onGoToInvestors={() => setActiveTab('investors')}
              onSelectSampleDeck={handleSelectSampleDeck}
              onLoadSample={handleSelectSampleDeck}
              currentReport={report}
              report={report}
              onViewReport={() => setActiveTab('analysis')}
              isAnalyzing={isAnalyzing}
              isLoadingSample={isAnalyzing}
            />
          )}

          {activeTab === 'upload' && (
            <UploadDeckView
              onUpload={handleUploadFile}
              onFileUpload={handleUploadFile}
              onAnalyzeRawText={handleAnalyzeRawText}
              onSelectSample={handleSelectSampleDeck}
              onLoadSample={handleSelectSampleDeck}
              isAnalyzing={isAnalyzing}
              isLoading={isAnalyzing}
              progress={analysisProgress}
              statusText={analysisStatusText}
              error={error}
              onClearError={() => setError(null)}
            />
          )}

          {activeTab === 'analysis' && report && (
            <AnalysisDashboard
              report={report}
              onGoToInvestors={() => setActiveTab('investors')}
              onEditProfile={() => setActiveTab('profile')}
            />
          )}

          {activeTab === 'profile' && startupProfile && (
            <StartupProfileEditor
              profile={startupProfile}
              onSave={handleSaveProfile}
              onCancel={() => setActiveTab(report ? 'analysis' : 'landing')}
            />
          )}

          {activeTab === 'investors' && (
            <FindInvestorsView
              startupProfile={startupProfile}
              savedInvestors={savedInvestors}
              onSaveInvestor={handleSaveInvestor}
              onRemoveSaved={handleRemoveSavedInvestor}
              onStartPitchDeck={() => setActiveTab('upload')}
            />
          )}

          {activeTab === 'saved' && (
            <SavedInvestorsView
              savedInvestors={savedInvestors}
              startupProfile={startupProfile}
              onUpdateStatus={handleUpdateStatus}
              onUpdateNotes={handleUpdateNotes}
              onRemoveSaved={handleRemoveSavedInvestor}
              onFindMore={() => setActiveTab('investors')}
            />
          )}
        </main>
      </div>
    </div>
  );
}
