import React, { useState, useMemo } from 'react';
import { 
  Investor, 
  StartupProfile, 
  MatchingCriteria, 
  SavedInvestor, 
  InvestorCRMStatus 
} from '../../types/index';
import { InvestorCard } from './InvestorCard';
import { InvestorDetailModal } from './InvestorDetailModal';
import { matchInvestors } from '../../lib/investors/matching';
import { 
  Search, 
  Filter, 
  SlidersHorizontal, 
  Users, 
  Sparkles, 
  CheckCircle2, 
  ArrowRight,
  RefreshCw,
  Edit2
} from 'lucide-react';

interface FindInvestorsViewProps {
  startupProfile: StartupProfile | null;
  savedInvestors: SavedInvestor[];
  onSaveInvestor: (investor: Investor, status?: InvestorCRMStatus, notes?: string) => void;
  onRemoveSaved: (investorId: string) => void;
  onStartPitchDeck: () => void;
}

export const FindInvestorsView: React.FC<FindInvestorsViewProps> = ({
  startupProfile,
  savedInvestors,
  onSaveInvestor,
  onRemoveSaved,
  onStartPitchDeck
}) => {
  // Fallback editable startup profile for manual search
  const [profileForm, setProfileForm] = useState<StartupProfile>(
    startupProfile || {
      startupName: 'NovaAI',
      description: 'Autonomous Enterprise Workflow Automation',
      industry: 'Artificial Intelligence',
      subIndustry: 'Enterprise AI & Workflow Automation',
      stage: 'Seed',
      geography: 'United States',
      targetCustomer: 'Enterprise Operations & IT',
      businessModel: 'B2B SaaS',
      product: 'AI Orchestration Platform',
      problem: 'Enterprises waste $2M+ on manual reconciliation',
      solution: 'Goal-directed self-healing AI agents',
      revenue: '$580k ARR',
      arr: '$580k ARR',
      mrr: '$48k MRR',
      growth: '28% MoM',
      numberOfUsers: '24,000 users',
      numberOfCustomers: '19 enterprise accounts',
      amountRaising: '$2.5M',
      previousFunding: '$500k Pre-Seed',
      marketSize: '$68B TAM',
      team: 'Ex-Palantir & Databricks engineers',
      competitors: 'UiPath, Zapier',
      useOfFunds: '65% ML engineering, 25% enterprise sales',
      whyNow: 'LLM reasoning breakthroughs & RPA consolidation',
      leadInvestorNeeded: true
    }
  );

  const [selectedStage, setSelectedStage] = useState<string>('all');
  const [selectedIndustry, setSelectedIndustry] = useState<string>('all');
  const [minScore, setMinScore] = useState<number>(70);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedInvestorForModal, setSelectedInvestorForModal] = useState<Investor | null>(null);
  const [isCriteriaOpen, setIsCriteriaOpen] = useState(false);

  // Compute matched investors based on profile and criteria
  const matchedInvestors = useMemo(() => {
    const criteria: MatchingCriteria = {
      industry: profileForm.industry,
      stage: profileForm.stage,
      country: profileForm.geography,
      amountRaising: profileForm.amountRaising,
      businessModel: profileForm.businessModel,
      leadInvestorNeeded: profileForm.leadInvestorNeeded,
      minScore: 50 // get full set for category grouping
    };

    let list = matchInvestors(profileForm, criteria);

    if (selectedStage !== 'all') {
      list = list.filter(inv => inv.stages.includes(selectedStage));
    }

    if (selectedIndustry !== 'all') {
      list = list.filter(inv => inv.sectors.some(s => s.toLowerCase().includes(selectedIndustry.toLowerCase())));
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      list = list.filter(inv => 
        inv.name.toLowerCase().includes(q) ||
        inv.location.toLowerCase().includes(q) ||
        inv.sectors.some(s => s.toLowerCase().includes(q)) ||
        inv.relevantInvestments.some(i => i.toLowerCase().includes(q))
      );
    }

    return list;
  }, [profileForm, selectedStage, selectedIndustry, searchQuery]);

  // Group into Best (90-100), Strong (80-89), Possible (70-79)
  const bestMatches = matchedInvestors.filter(inv => inv.matchScore >= 90);
  const strongMatches = matchedInvestors.filter(inv => inv.matchScore >= 80 && inv.matchScore < 90);
  const possibleMatches = matchedInvestors.filter(inv => inv.matchScore >= 70 && inv.matchScore < 80);
  const lowMatches = matchedInvestors.filter(inv => inv.matchScore < 70);

  const savedInvestorIds = new Set(savedInvestors.map(s => s.investorId));

  const handleToggleSave = (inv: Investor) => {
    if (savedInvestorIds.has(inv.id)) {
      onRemoveSaved(inv.id);
    } else {
      onSaveInvestor(inv, 'Researching');
    }
  };

  return (
    <div className="max-w-5xl mx-auto py-8 px-6 space-y-8">
      {/* Top Title & Pitch Deck Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-zinc-200">
        <div>
          <h2 className="text-xl font-bold text-zinc-900 tracking-tight">
            Find Matching Investors
          </h2>
          <p className="text-xs text-zinc-500 mt-1">
            VCs scored by stage thesis, check size bandwidth, sector focus, and portfolio conflict analysis.
          </p>
        </div>

        <button
          onClick={() => setIsCriteriaOpen(!isCriteriaOpen)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-md border border-zinc-300 bg-white text-xs font-semibold text-zinc-700 hover:bg-zinc-50 transition-colors"
        >
          <SlidersHorizontal className="w-3.5 h-3.5" />
          <span>{isCriteriaOpen ? 'Hide Search Criteria' : 'Adjust Startup Criteria'}</span>
        </button>
      </div>

      {/* Expandable Startup Matching Criteria Panel (Section 14) */}
      {isCriteriaOpen && (
        <div className="bg-white p-5 rounded-xl border border-zinc-200 space-y-4 shadow-xs">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold uppercase tracking-wider text-zinc-900 flex items-center gap-1.5">
              <Edit2 className="w-3.5 h-3.5 text-zinc-500" />
              <span>Matching Inputs</span>
            </h4>
            <span className="text-[11px] text-zinc-400 font-mono">Updates results dynamically</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 text-xs">
            <div>
              <label className="block font-medium text-zinc-700 mb-1">Startup Stage</label>
              <select
                value={profileForm.stage}
                onChange={(e) => setProfileForm({ ...profileForm, stage: e.target.value })}
                className="w-full px-2.5 py-1.5 rounded border border-zinc-300 text-xs font-medium focus:outline-hidden"
              >
                <option value="Pre-Seed">Pre-Seed</option>
                <option value="Seed">Seed</option>
                <option value="Series A">Series A</option>
                <option value="Series B">Series B</option>
              </select>
            </div>

            <div>
              <label className="block font-medium text-zinc-700 mb-1">Industry / Sector</label>
              <input
                type="text"
                value={profileForm.industry}
                onChange={(e) => setProfileForm({ ...profileForm, industry: e.target.value })}
                className="w-full px-2.5 py-1.5 rounded border border-zinc-300 text-xs focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block font-medium text-zinc-700 mb-1">Amount Raising</label>
              <input
                type="text"
                value={profileForm.amountRaising}
                onChange={(e) => setProfileForm({ ...profileForm, amountRaising: e.target.value })}
                className="w-full px-2.5 py-1.5 rounded border border-zinc-300 text-xs font-mono focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block font-medium text-zinc-700 mb-1">Geography / HQ</label>
              <input
                type="text"
                value={profileForm.geography}
                onChange={(e) => setProfileForm({ ...profileForm, geography: e.target.value })}
                className="w-full px-2.5 py-1.5 rounded border border-zinc-300 text-xs focus:outline-hidden"
              />
            </div>
          </div>

          <div className="flex items-center justify-between pt-2 border-t border-zinc-100 text-xs">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={profileForm.leadInvestorNeeded}
                onChange={(e) => setProfileForm({ ...profileForm, leadInvestorNeeded: e.target.checked })}
                className="rounded border-zinc-300 text-zinc-900 w-3.5 h-3.5"
              />
              <span className="text-zinc-700 font-medium">Require Lead Investor Capacity</span>
            </label>

            <span className="text-zinc-500 font-mono text-[11px]">
              Matching against {profileForm.startupName || 'Startup'}
            </span>
          </div>
        </div>
      )}

      {/* Filter Bar (Section 19) */}
      <div className="bg-zinc-50 p-4 rounded-xl border border-zinc-200 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2 flex-1 min-w-[220px]">
          <Search className="w-4 h-4 text-zinc-400 shrink-0" />
          <input
            type="text"
            placeholder="Search VC name, portfolio co (e.g. Stripe, Figma), or city..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-white px-3 py-1.5 rounded-md border border-zinc-300 text-xs focus:outline-hidden"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <select
            value={selectedStage}
            onChange={(e) => setSelectedStage(e.target.value)}
            className="px-2.5 py-1.5 rounded-md border border-zinc-300 bg-white font-medium text-xs focus:outline-hidden"
          >
            <option value="all">All Stages</option>
            <option value="Pre-Seed">Pre-Seed</option>
            <option value="Seed">Seed</option>
            <option value="Series A">Series A</option>
            <option value="Series B">Series B</option>
          </select>

          <select
            value={selectedIndustry}
            onChange={(e) => setSelectedIndustry(e.target.value)}
            className="px-2.5 py-1.5 rounded-md border border-zinc-300 bg-white font-medium text-xs focus:outline-hidden"
          >
            <option value="all">All Sectors</option>
            <option value="AI">AI & Machine Learning</option>
            <option value="SaaS">B2B SaaS</option>
            <option value="Fintech">Fintech</option>
            <option value="Healthcare">Healthcare & Bio</option>
            <option value="Climate">ClimateTech</option>
            <option value="Security">Cybersecurity</option>
          </select>
        </div>
      </div>

      {/* Section 18: Grouped Investor Categories */}
      <div className="space-y-8">
        {/* BEST MATCHES (90-100%) */}
        {bestMatches.length > 0 && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                <h3 className="text-base font-bold text-zinc-900 tracking-tight">
                  Best Matches (90–100%)
                </h3>
              </div>
              <span className="text-xs font-mono font-semibold px-2 py-0.5 rounded bg-emerald-50 text-emerald-800 border border-emerald-200">
                {bestMatches.length} High Conviction VCs
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {bestMatches.map((inv) => (
                <InvestorCard
                  key={inv.id}
                  investor={inv}
                  isSaved={savedInvestorIds.has(inv.id)}
                  onViewDetails={setSelectedInvestorForModal}
                  onToggleSave={handleToggleSave}
                />
              ))}
            </div>
          </div>
        )}

        {/* STRONG MATCHES (80-89%) */}
        {strongMatches.length > 0 && (
          <div className="space-y-4 pt-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-zinc-800" />
                <h3 className="text-base font-bold text-zinc-900 tracking-tight">
                  Strong Matches (80–89%)
                </h3>
              </div>
              <span className="text-xs font-mono font-semibold px-2 py-0.5 rounded bg-zinc-100 text-zinc-800 border border-zinc-200">
                {strongMatches.length} Funds
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {strongMatches.map((inv) => (
                <InvestorCard
                  key={inv.id}
                  investor={inv}
                  isSaved={savedInvestorIds.has(inv.id)}
                  onViewDetails={setSelectedInvestorForModal}
                  onToggleSave={handleToggleSave}
                />
              ))}
            </div>
          </div>
        )}

        {/* POSSIBLE MATCHES (70-79%) */}
        {possibleMatches.length > 0 && (
          <div className="space-y-4 pt-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                <h3 className="text-base font-bold text-zinc-900 tracking-tight">
                  Possible Matches (70–79%)
                </h3>
              </div>
              <span className="text-xs font-mono font-semibold px-2 py-0.5 rounded bg-amber-50 text-amber-800 border border-amber-200">
                {possibleMatches.length} Potential Fits
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {possibleMatches.map((inv) => (
                <InvestorCard
                  key={inv.id}
                  investor={inv}
                  isSaved={savedInvestorIds.has(inv.id)}
                  onViewDetails={setSelectedInvestorForModal}
                  onToggleSave={handleToggleSave}
                />
              ))}
            </div>
          </div>
        )}

        {/* Empty Search Result */}
        {matchedInvestors.length === 0 && (
          <div className="p-12 text-center bg-white rounded-xl border border-zinc-200 space-y-3">
            <Users className="w-8 h-8 text-zinc-400 mx-auto" />
            <h4 className="font-bold text-zinc-900">No Investors Found</h4>
            <p className="text-xs text-zinc-500 max-w-sm mx-auto">
              Try loosening your filters or adjusting your stage / sector criteria.
            </p>
          </div>
        )}
      </div>

      {/* Modal for Details & Outreach */}
      {selectedInvestorForModal && (
        <InvestorDetailModal
          investor={selectedInvestorForModal}
          startupProfile={profileForm}
          isSaved={savedInvestorIds.has(selectedInvestorForModal.id)}
          onClose={() => setSelectedInvestorForModal(null)}
          onSave={(inv, status, notes) => {
            onSaveInvestor(inv, status, notes);
            setSelectedInvestorForModal(null);
          }}
        />
      )}
    </div>
  );
};
