import './server/env';
import express from 'express';
import path from 'path';
import multer from 'multer';
import { parsePDFBuffer, parsePPTXBuffer } from './server/parser';
import { 
  analyzePitchDeck, 
  generateDeckScore,
  generateOutreachMessage
} from './src/lib/ai/minimax';
import { matchInvestors } from './src/lib/investors/matching';
import { SAMPLE_DECKS } from './src/lib/pitch/sampleDecks';
import { VC_DATABASE } from './src/lib/investors/database';

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 4 * 1024 * 1024 }
});

async function startServer() {
  const app = express();
  const PORT = Number(process.env.PORT) || 3000;
  const isProduction = process.env.NODE_ENV === 'production' || Boolean(process.env.K_SERVICE);
  const runtime = process.env.K_SERVICE
    ? 'Google Cloud Run'
    : process.env.NETLIFY === 'true'
      ? 'Netlify'
      : 'Node.js';

  app.use(express.json({ limit: '20mb' }));
  app.use(express.urlencoded({ extended: true, limit: '20mb' }));

  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok', service: 'FundPilot', runtime });
  });

  // API Config Status
  app.get('/api/config', (req, res) => {
    res.json({
      status: 'ok',
      aiEngine: 'NVIDIA NIM',
      configured: Boolean(
        process.env.NVIDIA_API_KEY?.trim() || process.env.NVIDIA_FALLBACK_API_KEY?.trim()
      ),
      models: [
        process.env.NVIDIA_PRIMARY_MODEL || 'minimaxai/minimax-m3',
        process.env.NVIDIA_FALLBACK_MODEL || 'meta/llama-3.1-8b-instruct'
      ],
      runtime
    });
  });

  // Upload pitch deck file (PDF / PPT / PPTX)
  app.post('/api/deck/upload', upload.single('deck'), async (req, res) => {
    try {
      const file = req.file;
      if (!file) {
        return res.status(400).json({ error: 'No pitch deck file provided.' });
      }

      const fileName = file.originalname || 'pitch-deck.pdf';
      const ext = path.extname(fileName).toLowerCase();
      let slideTexts: string[] = [];

      if (ext === '.pdf') {
        const parsed = await parsePDFBuffer(file.buffer);
        slideTexts = parsed.map(s => s.text);
      } else if (ext === '.pptx') {
        const parsed = await parsePPTXBuffer(file.buffer);
        slideTexts = parsed.map(s => s.text);
      } else if (ext === '.txt' || ext === '.md') {
        const raw = file.buffer.toString('utf-8');
        const split = raw.split(/\n{3,}|---/);
        slideTexts = split.filter(s => s.trim().length > 10);
        if (slideTexts.length === 0) slideTexts = [raw];
      } else {
        return res.status(415).json({ error: 'Unsupported file type. Upload a PDF, PPTX, TXT, or Markdown file.' });
      }

      if (slideTexts.length === 0) {
        return res.status(422).json({
          error: 'No readable slide text was found. If the deck is image-only, export it with selectable text or upload a PPTX.'
        });
      }

      console.log(`[FundPilot] Analyzing deck "${fileName}" with ${slideTexts.length} slides...`);
      const report = await analyzePitchDeck(slideTexts, fileName);
      res.json(report);
    } catch (err: any) {
      console.error('[FundPilot] Upload error:', err);
      res.status(500).json({
        error: "We couldn't finish the analysis. Please check your file and retry.",
        details: err?.message
      });
    }
  });

  // Load and analyze sample deck (supports both GET and POST)
  const handleSampleDeck = async (req: express.Request, res: express.Response) => {
    try {
      const sample = SAMPLE_DECKS.find(s => s.id === req.params.id) || SAMPLE_DECKS[0];
      const slideTexts = sample.slides.map(s => `${s.title}\n${s.text}`);
      
      console.log(`[FundPilot] Analyzing sample deck "${sample.name}"...`);
      const report = await analyzePitchDeck(slideTexts, `${sample.id}-deck.pdf`);
      res.json(report);
    } catch (err: any) {
      console.error('[FundPilot] Sample deck error:', err);
      res.status(500).json({ error: "Failed to process sample deck.", details: err?.message });
    }
  };

  app.get('/api/deck/sample/:id', handleSampleDeck);
  app.post('/api/deck/sample/:id', handleSampleDeck);

  // Analyze raw slide texts
  app.post('/api/deck/analyze-text', async (req, res) => {
    try {
      const { slides, fileName } = req.body;
      if (!Array.isArray(slides) || slides.length === 0 || !slides.every(slide => typeof slide === 'string')) {
        return res.status(400).json({ error: 'Slide texts array required.' });
      }
      if (slides.length > 100 || slides.some(slide => slide.length > 50_000)) {
        return res.status(413).json({ error: 'Deck text is too large (maximum 100 slides and 50,000 characters per slide).' });
      }

      const normalizedSlides = slides.map(slide => slide.trim()).filter(Boolean);
      if (normalizedSlides.length === 0) {
        return res.status(400).json({ error: 'At least one slide must contain text.' });
      }

      const safeFileName = typeof fileName === 'string' && fileName.trim()
        ? path.basename(fileName.trim()).slice(0, 255)
        : 'custom-deck.txt';
      const report = await analyzePitchDeck(normalizedSlides, safeFileName);
      res.json(report);
    } catch (err: any) {
      console.error('[FundPilot] Text analysis error:', err);
      res.status(500).json({ error: "We couldn't finish the analysis.", details: err?.message });
    }
  });

  // Re-calculate scores when founder edits startup profile or slides
  app.post('/api/deck/recalculate', async (req, res) => {
    try {
      const { startupProfile, slides } = req.body;
      if (!startupProfile || !slides) {
        return res.status(400).json({ error: 'startupProfile and slides required' });
      }

      const pitchScore = await generateDeckScore(startupProfile, slides);
      res.json({ pitchScore });
    } catch (err: any) {
      console.error('[FundPilot] Recalculate error:', err);
      res.status(500).json({ error: 'Failed to recalculate score.' });
    }
  });

  // Match investors against startup profile and criteria
  app.post('/api/investors/match', async (req, res) => {
    try {
      const { startupProfile, criteria } = req.body;
      if (!startupProfile) {
        return res.status(400).json({ error: 'startupProfile required for investor matching.' });
      }

      const matched = matchInvestors(startupProfile, criteria);
      res.json({ investors: matched, total: matched.length });
    } catch (err: any) {
      console.error('[FundPilot] Match error:', err);
      res.status(500).json({ error: 'Failed to match investors.' });
    }
  });

  // Generate tailored outreach email / LinkedIn / warm intro blurb
  app.post('/api/investors/outreach', async (req, res) => {
    try {
      const { investor, startupProfile, format } = req.body;
      if (!investor || !startupProfile || !format) {
        return res.status(400).json({ error: 'Missing investor, startupProfile, or format parameter.' });
      }

      const message = await generateOutreachMessage(investor, startupProfile, format);
      res.json({ format, message });
    } catch (err: any) {
      console.error('[FundPilot] Outreach generation error:', err);
      res.status(500).json({ error: 'Failed to generate outreach message.' });
    }
  });

  // Get single investor details & database list
  app.get('/api/investors', (req, res) => {
    res.json({ database: VC_DATABASE });
  });

  app.use((err: unknown, _req: express.Request, res: express.Response, next: express.NextFunction) => {
    if (err instanceof multer.MulterError) {
      const status = err.code === 'LIMIT_FILE_SIZE' ? 413 : 400;
      const message = err.code === 'LIMIT_FILE_SIZE'
        ? 'The uploaded file exceeds the 4 MB limit.'
        : `Upload failed: ${err.message}`;
      return res.status(status).json({ error: message });
    }
    next(err);
  });

  // Vite middleware for development vs static serve for production
  if (!isProduction) {
    // Keep Vite out of the production startup dependency graph. Cloud Run
    // installs production dependencies only after the build step.
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[FundPilot] Server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
